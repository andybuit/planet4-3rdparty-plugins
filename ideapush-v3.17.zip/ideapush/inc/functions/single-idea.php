<?php


//add content at the top of the post
function idea_push_add_content_after_title( $content ) {
    if ( is_single() && 'idea' == get_post_type()) {
        
        //declare variables
        
        $ideaId = get_the_ID();
        
        
        $getBoard = get_the_terms($ideaId,'boards');

        $getBoardId = $getBoard[0]->term_id;

        $getBoardSettings = idea_push_get_board_settings($getBoardId);
        
        $showBoardTo = $getBoardSettings[14];
        
        $currentUserId = idea_push_check_if_non_logged_in_user_is_guest();
        
        $currentUserObject = get_user_by( 'id', $currentUserId);
        $currentUserRole = $currentUserObject->roles;
        
        if(in_array($showBoardTo, $currentUserRole) || $showBoardTo == "Everyone"){
        
        
            $custom_content = '<div style="margin-bottom: 20px;" class="ideapush-container" data="'.$ideaId.'">';

                $custom_content .= idea_push_single_page_below_title($ideaId);

            $custom_content .= '</div>';


            //get dialog text
            //login to vote title
            $custom_content .= '<div style="display: none;" id="dialog-login-to-vote" data="'.__( 'Please enter your name and email to vote', 'ideapush' ).'"></div>';

            //login to vote required fields
            $custom_content .= '<div style="display: none;" id="dialog-login-to-vote-required" data="'.__( 'Please ensure all fields are completed and a valid email is entered.', 'ideapush' ).'"></div>';

            //delete idea dialog
            $custom_content .= '<div style="display: none;" id="dialog-idea-delete" data="'.__( 'Are you sure you want to delete this idea?', 'ideapush' ).'"></div>';

            //idea deleted dialog
            $custom_content .= '<div style="display: none;" id="dialog-idea-deleted" data="'.__( 'The post has been added to the trash but not permanently deleted.', 'ideapush' ).'"></div>';

            //vote limit dialog
            $custom_content .= '<div style="display: none;" id="dialog-no-vote" data="'.__( 'You have reached your daily vote limit or voting has been disabled on this board.', 'ideapush' ).'"></div>';



            $custom_content .= $content;


            return $custom_content;
        
        } else {
            
            
            #comments
            $html = '<style>#comments{display: none!important}</style>';

            $html .= '<div id="remove-comments"></div>';
            $html .= __( 'Sorry you do not have permission to view this idea.', 'ideapush' );

            return $html; 
        }
        
        
    } else {
        return $content;
    }
}
add_filter( 'the_content', 'idea_push_add_content_after_title' );








function idea_push_single_page_below_title($ideaId){
    
    
    //get options
    $options = get_option('idea_push_settings');
    
    $primaryColor = esc_html($options['idea_push_primary_link_colour']);
    
    $custom_content = '<style>

            .ideapush-container i, .ideapush-container a, .ideapush-container .idea-item-tag:hover, .ideapush-container .idea-item-file:hover, .single-idea .close-button
            {color: '.$primaryColor.';}

            .submit-new-idea,.submit-new-idea:hover,.submit-new-idea:focus, .single-idea .ui-button, .single-idea .ui-button:hover, .single-idea .ui-button:focus, .admin-star-outer
            {background: '.$primaryColor.';}

            .ideapush-container .idea-item-tag:hover, .ideapush-container .idea-item-file:hover, .single-idea .ui-button, .single-idea .ui-button:hover, .single-idea .ui-button:focus, .single-idea .close-button
            {border-color: '.$primaryColor.';}

            .alertify .cancel
            {color: '.$primaryColor.' !important;}

            .alertify .ok, .alertify .cancel
            {border-color: '.$primaryColor.' !important;}

            .alertify .ok
            {background-color: '.$primaryColor.' !important;}


        </style>';
    
    
    
    //do breadcrumbs
    $pageLinkOfPageThatHasShortcode = idea_push_what_page_has_shortcode($ideaId);
    
    if($pageLinkOfPageThatHasShortcode !== false){
        
        //get the boardId
        $boardId = idea_push_get_board_id_from_post_id($ideaId);
        
        //get the board settings
        $individualBoardSetting = idea_push_get_board_settings($boardId);
        
        //get the board name
        $boardName = $individualBoardSetting[1];
        
        //get the idea title
        $ideaTitle = get_the_title($ideaId);
        
        
        
        
        $custom_content .= '<div class="idea-item-breadcrumbs">';

            $custom_content .= '<a href="'.$pageLinkOfPageThatHasShortcode.'">'.$boardName.'</a> <i class="fa fa-angle-right breadcrumb-divider" aria-hidden="true"></i>

 <a href="#">'.$ideaTitle.'</a>';        

        $custom_content .= '</div>';    
        
    }
    
    
        
    
    
    $getStatus = get_the_terms($ideaId,'status');

    $getBoard = get_the_terms($ideaId,'boards');

    $getBoardId = $getBoard[0]->term_id;

    $getBoardSettings = idea_push_get_board_settings($getBoardId);
    
    
    
    
    //left side
    $custom_content .= '<div class="idea-item-left">';

        $custom_content .= idea_push_vote_part($ideaId,$getStatus[0]->slug,$getBoardSettings);        

    $custom_content .= '</div>';




    //right side
    $custom_content .= '<div class="idea-item-right">';
        $custom_content .= '<div class="idea-item-right-inner">';
        
            $custom_content .= idea_push_get_idea_meta(get_post($ideaId),$getStatus[0]->slug,$getBoardSettings);
    
            $custom_content .= idea_push_get_tags_and_attachments($ideaId);
            
        $custom_content .= '</div>';
    $custom_content .= '</div>';


    //admin section below
    if(current_user_can('administrator')){
        $custom_content .= '<div class="idea-item-admin-functions">';
            //add admin stuff here
            $custom_content .= '<div class="idea-item-admin-functions-title-area">';
                $custom_content .= '<h3 class="admin-functions-heading">'.__( 'Admin Functions', 'ideapush' ).'</h3>';

                $custom_content .= '<span class="admin-functions-disclaimer">'.__( 'These quick admin functions are only available to admin users.', 'ideapush' ).'</span>';
            $custom_content .= '</div>';
            
            
            $custom_content .= '<div class="idea-statuses-listing">';
                $custom_content .= __( 'Change status:', 'ideapush' ).' <span class="status-listing-container">'.idea_push_render_status($getStatus[0]->slug,"EXCEPT");
            $custom_content .= '</span></div>';    


            $custom_content .= '<a class="idea-item-edit" href="'.get_edit_post_link().'">';
                $custom_content .= '<i class="fa fa-pencil-square-o edit-idea-icon" aria-hidden="true"></i> '.__( 'Edit', 'ideapush' );
            $custom_content .= '</a>';

            $custom_content .= '<a href="#" data="'.$ideaId.'" class="idea-item-delete">';
                $custom_content .= '<i class="fa fa-trash-o delete-idea-icon" aria-hidden="true"></i> '.__( 'Delete', 'ideapush' );
            $custom_content .= '</a>';



        $custom_content .= '</div>';    

    }
    
    return $custom_content;
    
}


function idea_push_single_page_below_title_get(){
    
    $ideaId = idea_push_sanitization_validation($_POST['ideaId'],'id');
    
    if($ideaId == false){
        wp_die();    
    }
    
    echo idea_push_single_page_below_title($ideaId);
    
    wp_die();
    
}
add_action( 'wp_ajax_below_title_header', 'idea_push_single_page_below_title_get' );
add_action( 'wp_ajax_nopriv_below_title_header', 'idea_push_single_page_below_title_get' );




//helps to add breadcrumbs to single page
function idea_push_what_page_has_shortcode($ideaId) {
    
    $boardId = idea_push_get_board_id_from_post_id($ideaId);
    
    $shortcode = '[ideapush board="'.$boardId.'"]';
    
    
    $pages = get_pages();
    foreach($pages as $page) {
        
        $pageId = $page->ID;    
        $pageContent = $page->post_content;
        $pageLink = get_permalink($pageId);
        
        if(strpos($pageContent, $shortcode) !== false){
            return $pageLink;
            break;
        }
    }
    
    return false;

}


?>