<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 

//define all the settings in the plugin
function idea_push_settings_init() { 
    
    //start authorisation section
	register_setting( 'notifications', 'idea_push_settings' );
    
    //notification settings
	add_settings_section(
		'idea_push_notifications','', 
		'idea_push_notifications_callback', 
		'notifications'
	);
    
    add_settings_field( 
		'idea_push_tab_memory','', 
		'idea_push_tab_memory_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_hide_admin_notice','', 
		'idea_push_hide_admin_notice_render', 
		'notifications', 
		'idea_push_notifications' 
	);

	add_settings_field( 
		'idea_push_notification_email','', 
		'idea_push_notification_email_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    
    
    //admin notification when idea is submitted
    add_settings_field( 
		'idea_push_notification_idea_submitted','', 
		'idea_push_notification_idea_submitted_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_idea_submitted_subject','', 
		'idea_push_notification_idea_submitted_subject_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_idea_submitted_content','', 
		'idea_push_notification_idea_submitted_content_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    
    
    //admin notification when idea is ready for review
    add_settings_field( 
		'idea_push_notification_idea_review','', 
		'idea_push_notification_idea_review_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_idea_review_subject','', 
		'idea_push_notification_idea_review_subject_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_idea_review_content','', 
		'idea_push_notification_idea_review_content_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    
    
    //author idea created published
    add_settings_field( 
		'idea_push_notification_author_idea_created_published_enable','', 
		'idea_push_notification_author_idea_created_published_enable_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_author_idea_created_published_subject','', 
		'idea_push_notification_author_idea_created_published_subject_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_author_idea_created_published_content','', 
		'idea_push_notification_author_idea_created_published_content_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    
    
    //author idea created reviewed
    add_settings_field( 
		'idea_push_notification_author_idea_created_reviewed_enable','', 
		'idea_push_notification_author_idea_created_reviewed_enable_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_author_idea_created_reviewed_subject','', 
		'idea_push_notification_author_idea_created_reviewed_subject_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_author_idea_created_reviewed_content','', 
		'idea_push_notification_author_idea_created_reviewed_content_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    
    
    
    //author review
    add_settings_field( 
		'idea_push_notification_author_idea_change_review_enable','', 
		'idea_push_notification_author_idea_change_review_enable_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_author_idea_change_review_subject','', 
		'idea_push_notification_author_idea_change_review_subject_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_author_idea_change_review_content','', 
		'idea_push_notification_author_idea_change_review_content_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    
    //author approved
    add_settings_field( 
		'idea_push_notification_author_idea_change_approved_enable','', 
		'idea_push_notification_author_idea_change_approved_enable_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_author_idea_change_approved_subject','', 
		'idea_push_notification_author_idea_change_approved_subject_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_author_idea_change_approved_content','', 
		'idea_push_notification_author_idea_change_approved_content_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    
    //author declined
    add_settings_field( 
		'idea_push_notification_author_idea_change_declined_enable','', 
		'idea_push_notification_author_idea_change_declined_enable_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_author_idea_change_declined_subject','', 
		'idea_push_notification_author_idea_change_declined_subject_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_author_idea_change_declined_content','', 
		'idea_push_notification_author_idea_change_declined_content_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    
    //author in progress
    add_settings_field( 
		'idea_push_notification_author_idea_change_in_progress_enable','', 
		'idea_push_notification_author_idea_change_in_progress_enable_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_author_idea_change_in_progress_subject','', 
		'idea_push_notification_author_idea_change_in_progress_subject_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_author_idea_change_in_progress_content','', 
		'idea_push_notification_author_idea_change_in_progress_content_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    //author completed
    add_settings_field( 
		'idea_push_notification_author_idea_change_completed_enable','', 
		'idea_push_notification_author_idea_change_completed_enable_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_author_idea_change_completed_subject','', 
		'idea_push_notification_author_idea_change_completed_subject_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_author_idea_change_completed_content','', 
		'idea_push_notification_author_idea_change_completed_content_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    
    //author notification someone voted
    add_settings_field( 
		'idea_push_notification_author_voter_voted_enable','', 
		'idea_push_notification_author_voter_voted_enable_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_author_voter_voted_subject','', 
		'idea_push_notification_author_voter_voted_subject_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_author_voter_voted_content','', 
		'idea_push_notification_author_voter_voted_content_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    
    
    //voter review
    add_settings_field( 
		'idea_push_notification_voter_idea_change_review_enable','', 
		'idea_push_notification_voter_idea_change_review_enable_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_voter_idea_change_review_subject','', 
		'idea_push_notification_voter_idea_change_review_subject_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_voter_idea_change_review_content','', 
		'idea_push_notification_voter_idea_change_review_content_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    
    //voter approved
    add_settings_field( 
		'idea_push_notification_voter_idea_change_approved_enable','', 
		'idea_push_notification_voter_idea_change_approved_enable_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_voter_idea_change_approved_subject','', 
		'idea_push_notification_voter_idea_change_approved_subject_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_voter_idea_change_approved_content','', 
		'idea_push_notification_voter_idea_change_approved_content_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    
    //voter declined
    add_settings_field( 
		'idea_push_notification_voter_idea_change_declined_enable','', 
		'idea_push_notification_voter_idea_change_declined_enable_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_voter_idea_change_declined_subject','', 
		'idea_push_notification_voter_idea_change_declined_subject_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_voter_idea_change_declined_content','', 
		'idea_push_notification_voter_idea_change_declined_content_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    
    //voter in progress
    add_settings_field( 
		'idea_push_notification_voter_idea_change_in_progress_enable','', 
		'idea_push_notification_voter_idea_change_in_progress_enable_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_voter_idea_change_in_progress_subject','', 
		'idea_push_notification_voter_idea_change_in_progress_subject_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_voter_idea_change_in_progress_content','', 
		'idea_push_notification_voter_idea_change_in_progress_content_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    //voter completed
    add_settings_field( 
		'idea_push_notification_voter_idea_change_completed_enable','', 
		'idea_push_notification_voter_idea_change_completed_enable_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_voter_idea_change_completed_subject','', 
		'idea_push_notification_voter_idea_change_completed_subject_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    add_settings_field( 
		'idea_push_notification_voter_idea_change_completed_content','', 
		'idea_push_notification_voter_idea_change_completed_content_render', 
		'notifications', 
		'idea_push_notifications' 
	);
    
    
    
    //status settings
    register_setting( 'statuses', 'idea_push_settings' );
    
	add_settings_section(
		'idea_push_statuses','', 
		'idea_push_statuses_callback', 
		'statuses'
	);

    //translate statuses
	add_settings_field( 
		'idea_push_change_open_status','', 
		'idea_push_change_open_status_render', 
		'statuses', 
		'idea_push_statuses' 
	);
    
    add_settings_field( 
		'idea_push_change_reviewed_status','', 
		'idea_push_change_reviewed_status_render', 
		'statuses', 
		'idea_push_statuses' 
	);
    add_settings_field( 
		'idea_push_change_approved_status','', 
		'idea_push_change_approved_status_render', 
		'statuses', 
		'idea_push_statuses' 
	);
    
    add_settings_field( 
		'idea_push_change_declined_status','', 
		'idea_push_change_declined_status_render', 
		'statuses', 
		'idea_push_statuses' 
	);
    
    add_settings_field( 
		'idea_push_change_in_progress_status','', 
		'idea_push_change_in_progress_status_render', 
		'statuses', 
		'idea_push_statuses' 
	);
    
    add_settings_field( 
		'idea_push_change_completed_status','', 
		'idea_push_change_completed_status_render', 
		'statuses', 
		'idea_push_statuses' 
    );

    add_settings_field( 
		'idea_push_change_all_statuses_status','', 
		'idea_push_change_all_statuses_status_render', 
		'statuses', 
		'idea_push_statuses' 
    );
    


    //diable statuses
    add_settings_field( 
		'idea_push_disable_approved_status','', 
		'idea_push_disable_approved_status_render', 
		'statuses', 
		'idea_push_statuses' 
	);
    
    add_settings_field( 
		'idea_push_disable_declined_status','', 
		'idea_push_disable_declined_status_render', 
		'statuses', 
		'idea_push_statuses' 
	);
    
    add_settings_field( 
		'idea_push_disable_in_progress_status','', 
		'idea_push_disable_in_progress_status_render', 
		'statuses', 
		'idea_push_statuses' 
	);
    
    add_settings_field( 
		'idea_push_disable_completed_status','', 
		'idea_push_disable_completed_status_render', 
		'statuses', 
		'idea_push_statuses' 
    );
    
    add_settings_field( 
		'idea_push_disable_all_statuses_status','', 
		'idea_push_disable_all_statuses_status_render', 
		'statuses', 
		'idea_push_statuses' 
	);
    
    
    //design settings
    register_setting( 'design', 'idea_push_settings' );
    
	add_settings_section(
		'idea_push_design','', 
		'idea_push_design_callback', 
		'design'
	);

	add_settings_field( 
		'idea_push_primary_link_colour','', 
		'idea_push_primary_link_colour_render', 
		'design', 
		'idea_push_design' 
	);
    
    add_settings_field( 
		'idea_push_custom_css','', 
		'idea_push_custom_css_render', 
		'design', 
		'idea_push_design' 
	);
    
    
    //idea form settings
    register_setting( 'idea_form', 'idea_push_settings' );
    
	add_settings_section(
		'idea_push_idea_form','', 
		'idea_push_idea_form_callback', 
		'idea_form'
	);

	add_settings_field( 
		'idea_push_form_title','', 
		'idea_push_form_title_render', 
		'idea_form', 
		'idea_push_idea_form' 
	);
    
    add_settings_field( 
		'idea_push_idea_title','', 
		'idea_push_idea_title_render', 
		'idea_form', 
		'idea_push_idea_form' 
	);
    
    add_settings_field( 
		'idea_push_idea_description','', 
		'idea_push_idea_description_render', 
		'idea_form', 
		'idea_push_idea_form' 
	);
    
    add_settings_field( 
		'idea_push_idea_tags','', 
		'idea_push_idea_tags_render', 
		'idea_form', 
		'idea_push_idea_form' 
	);
    
    add_settings_field( 
		'idea_push_attachment_text','', 
		'idea_push_attachment_text_render', 
		'idea_form', 
		'idea_push_idea_form' 
	);
    
    add_settings_field( 
		'idea_push_submit_button','', 
		'idea_push_submit_button_render', 
		'idea_form', 
		'idea_push_idea_form' 
    );
    
    add_settings_field( 
		'idea_push_submit_idea_button','', 
		'idea_push_submit_idea_button_render', 
		'idea_form', 
		'idea_push_idea_form' 
    );
    
    add_settings_field( 
		'idea_push_form_settings','', 
		'idea_push_form_settings_render', 
		'idea_form', 
		'idea_push_idea_form' 
	);
    
//    add_settings_field( 
//		'idea_push_recaptcha_site_key','', 
//		'idea_push_recaptcha_site_key_render', 
//		'idea_form', 
//		'idea_push_idea_form' 
//	);
    
    add_settings_field( 
		'idea_push_enable_bot_protection','', 
		'idea_push_enable_bot_protection_render', 
		'idea_form', 
		'idea_push_idea_form' 
	);
    

    
    
    
    
    //board settings
    register_setting( 'boards', 'idea_push_settings' );
    
	add_settings_section(
		'idea_push_boards','', 
		'idea_push_boards_callback', 
		'boards'
	);

	add_settings_field( 
		'idea_push_board_configuration','', 
		'idea_push_board_configuration_render', 
		'boards', 
		'idea_push_boards' 
	);
    

    //locked
    register_setting( 'licence', 'idea_push_settings' );
    
	add_settings_section(
		'idea_push_locked','', 
		'idea_push_locked_callback', 
		'licence'
	);
    
    //support
    register_setting( 'ideapush_support', 'idea_push_settings' );
    
	add_settings_section(
		'idea_push_ideapush_support','', 
		'idea_push_ideapush_support_callback', 
		'ideapush_support'
	);
    
 
 
}

/**
* 
*
*
* The following functions output the callback of the sections
*/
function idea_push_notifications_callback(){}
function idea_push_design_callback(){}
function idea_push_statuses_callback(){
    ?>
    <tr class="ideapush_settings_row" valign="top">
        <td scope="row" colspan="2">
            <div class="inside">
                
                
                <div style="font-weight: 600;" class="notice notice-info inline">
                    <p><?php _e( 'These settings update the status names - this only changes the status names in the front end of idea board and not in the admin area. You can also remove some of the default statuses.', 'ideapush' ); ?></p>
                </div>
            </div>
        </td>
    </tr>
    <?php
    
}

function idea_push_ideapush_support_callback(){
    ?>
    <tr class="ideapush_settings_row" valign="top">
        <td scope="row" colspan="2">
            <div class="inside">
                
                
                
                
                
                <h2><?php _e( 'Frequently Asked Questions', 'ideapush' ); ?></h2>
                
                <iframe style="margin-top: 20px; margin-bottom: 20px;" width="560" height="315" src="https://www.youtube-nocookie.com/embed/yFaGNbYUiIw?rel=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                
                
                <div id="accordion">
                    <h3><i class="fa fa-question-circle-o" aria-hidden="true"></i> <?php _e( 'Why do you recommend putting the shortcode onto a page and not a post?', 'ideapush' ); ?></h3>
                    <div>
                        <?php _e( 'You can definitely put the board shortcode onto a post without any issues, however if you put it onto a page, on the single post we will show a back button/breadcrumb so people can go back to the main board page.', 'ideapush' ); ?>
                    </div>
                    
                    
                    <h3><i class="fa fa-question-circle-o" aria-hidden="true"></i> <?php _e( 'I am a developer, can I hook into some of the events created by the plugin?', 'ideapush' ); ?></h3>
                    <div>
                        <?php _e( 'Yes we have developed a variety of action hooks so you can hook into some of the events created by IdeaPush. Please use the below table to see the action details:', 'ideapush' ); ?>
                        
                        <br></br>
                        <h3>Admin Notification Actions</h3>
                        
                        <table class="action-reference-table">
                            <colgroup>
                                <col class="action-hook-column">
                                <col class="action-name-column">
                                <col class="action-parameters-column">
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th>Action Hook Purpose</th>
                                    <th>Action Name</th>
                                    <th>Action Parameters</th>
                                </tr>
                                
                                <tr class="action-item">
                                    <td class="action-purpose">Admin notification when idea is created</td>
                                    <td class="action-name">idea_push_idea_created_admin_notification</td>
                                    <td class="action-parameters">$newIdeaId, $content</td>
                                </tr>
                                
                                <tr class="action-item">
                                    <td class="action-purpose">Admin notification when vote threshold is reached</td>
                                    <td class="action-name">idea_push_idea_review_admin_notification</td>
                                    <td class="action-parameters">$ideaId, $content</td>
                                </tr>

                            </tbody>
                        </table>
                        
                        <br></br>
                        <h3>Author Notification Actions</h3>
                        
                        <table class="action-reference-table">
                            <colgroup>
                                <col class="action-hook-column">
                                <col class="action-name-column">
                                <col class="action-parameters-column">
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th>Action Hook Purpose</th>
                                    <th>Action Name</th>
                                    <th>Action Parameters</th>
                                </tr>
                                
                                <tr class="action-item">
                                    <td class="action-purpose">Author notification when an idea is published</td>
                                    <td class="action-name">idea_push_idea_created_published_author_notification</td>
                                    <td class="action-parameters">$newIdeaId, $content</td>
                                </tr>
                                
                                <tr class="action-item">
                                    <td class="action-purpose">Author notification when an idea is pending review for admin approval</td>
                                    <td class="action-name">idea_push_idea_created_reviewed_author_notification</td>
                                    <td class="action-parameters">$newIdeaId, $content</td>
                                </tr>
                                
                                
                                <tr class="action-item">
                                    <td class="action-purpose">Author notification when an idea has been voted on</td>
                                    <td class="action-name">idea_push_idea_vote_author_notification</td>
                                    <td class="action-parameters">$ideaId, $content</td>
                                </tr>
                                
                                
                                <tr class="action-item">
                                    <td class="action-purpose">Author notification when a vote has been cast and it has now changed the status from open to reviewed</td>
                                    <td class="action-name">idea_push_idea_vote_author_notification_review</td>
                                    <td class="action-parameters">$ideaId, $content</td>
                                </tr>
                                
                                <tr class="action-item">
                                    <td class="action-purpose">Author notification when a status has changed</td>
                                    <td class="action-name">idea_push_idea_status_change_author_notification</td>
                                    <td class="action-parameters">$ideaId, $content</td>
                                </tr>
                                
                            </tbody>
                        </table>
                
                
                
                
                        <br></br>
                        <h3>Voter Notification Actions</h3>
                        
                        <table class="action-reference-table">
                            <colgroup>
                                <col class="action-hook-column">
                                <col class="action-name-column">
                                <col class="action-parameters-column">
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th>Action Hook Purpose</th>
                                    <th>Action Name</th>
                                    <th>Action Parameters</th>
                                </tr>
                                
                                <tr class="action-item">
                                    <td class="action-purpose">Voter notification when they cast a vote for something that has reached the review stage</td>
                                    <td class="action-name">idea_push_idea_vote_voter_notification</td>
                                    <td class="action-parameters">$ideaId, $content</td>
                                </tr>
                                
                                <tr class="action-item">
                                    <td class="action-purpose">Voter notification when the idea they voted on changes status</td>
                                    <td class="action-name">idea_push_idea_status_change_voter_notification</td>
                                    <td class="action-parameters">$ideaId, $content</td>
                                </tr>

     
                            </tbody>
                        </table>
            
            
                        <br></br>
                        <h3>Other Actions</h3>
                        
                        <table class="action-reference-table">
                            <colgroup>
                                <col class="action-hook-column">
                                <col class="action-name-column">
                                <col class="action-parameters-column">
                            </colgroup>
                            
                            <tbody>
                                <tr>
                                    <th>Action Hook Purpose</th>
                                    <th>Action Name</th>
                                    <th>Action Parameters</th>
                                </tr>
                                
                                <tr class="action-item">
                                    <td class="action-purpose">When status has changed</td>
                                    <td class="action-name">idea_push_idea_status_change</td>
                                    <td class="action-parameters">$ideaId, $currentUser, $content</td>
                                </tr>
                                
                                <tr class="action-item">
                                    <td class="action-purpose">When vote threshold has been achieved</td>
                                    <td class="action-name">idea_push_idea_vote_threshold</td>
                                    <td class="action-parameters">$ideaId, $content</td>
                                </tr>
                                
                                <tr class="action-item">
                                    <td class="action-purpose">When a vote has been cast</td>
                                    <td class="action-name">idea_push_vote_cast</td>
                                    <td class="action-parameters">$ideaId, $userId, $voteIntent, $ideaScoreNow, $voteThreshold</td>
                                </tr>
                                
                                <tr class="action-item">
                                    <td class="action-purpose">When an idea has been published</td>
                                    <td class="action-name">idea_push_after_idea_created</td>
                                    <td class="action-parameters">$newIdeaId, $userId, $title, $description</td>
                                </tr>
                                
                            
                                
                                

     
                            </tbody>
                        </table>
                        <br></br>
                        <?php _e( 'This specification is still being worked on so please expect changes to occur. Your feedback on this specification is welcome.', 'ideapush' ); ?>
            
 
                        
                        
                    </div>
                    
                    <h3><i class="fa fa-question-circle-o" aria-hidden="true"></i> <?php _e( 'Things don\'t look great, how I can change that?', 'ideapush' ); ?></h3>
                    <div>
                        <?php _e( 'Because the plugin has quite a lot of frontend design your existing theme or other plugins may change the style of IdeaPush. The plugin tries to strike a balance between respecting your existing styles whilst trying to make things look and work ok. Whilst it\'s possible to have settings for every possible thing on the frontend, the plugin would turn into settings overload which can be quite overwhelming to new users of the plugin who may just want to get things up and running quickly. To best resolve styling issues it requires you or someone you know to have <a href="https://www.w3schools.com/css/css_intro.asp" target="_blank">CSS knowledge</a>. You can then enter in custom CSS code into the Custom CSS field on the <a class="open-tab" href="#design">Design</a> tab. To help you with some common CSS changes I have put some quick buttons which implement the CSS code for you beside this field. If you upgrade to IdeaPush Pro I promise I will give you around 15 minutes of my time to implement custom styles to make things look just right.', 'ideapush' ); ?> 
                    </div>

                    <h3><i class="fa fa-question-circle-o" aria-hidden="true"></i> <?php _e( 'Can I have a board show in a fixed height container?', 'ideapush' ); ?></h3>
                    <div>
                        <?php _e( 'Whilst it is recommended to have a dedicated page for the board page it is possible to put the board in the middle of other content on your page. To achieve this we need to put the board shortcode inside a div container. For example: <xmp><div class="ideapush-scrollable-container" style="height: 800px;">[ideapush board="###"]</div></xmp></br>You can replace the 800px with whatever height you want.', 'ideapush' ); ?> 
                    </div>

                    <h3><i class="fa fa-question-circle-o" aria-hidden="true"></i> <?php _e( 'How can I change the status or filter shown on the board by default?', 'ideapush' ); ?></h3>
                    <div>
                        <?php _e( 'It is possible to change this by adding a query string to your URL. For example: <strong>https://yourwebsites.com/yourpage/?showing=popular&status=reviewed&tag=All</strong>. Just replace "reviewed" with your desired status name or "popular" with your desired filter and obviously change the domain and page to your actual domain and board page. You can now put this URL into your WordPress menu if you wanted to by adding a custom URL to the menu or you can update your page slug to this URL. Also to get this customised URL more easily when you change any of the filters on your board display you will notice the URL will change so you can simply copy and paste this value into your menu or page slug.', 'ideapush' ); ?> 
                    </div>

                    <h3><i class="fa fa-question-circle-o" aria-hidden="true"></i> <?php _e( 'Links appear to be broken for some reason, how can I fix this?', 'ideapush' ); ?></h3>
                    <div>
                        <?php _e( 'This could happen for a couple of reasons. The first thing you should do is resave the <a href="'.get_admin_url(null, 'options-permalink.php' ).'">permalinks</a> of your site - this can fix most issues. It is possible you might have accidently deleted a board and recreated it again and this dissociates ideas with the board. If this occurs ideas need to be manually re-assigned to their respective board from the <a href="'.get_admin_url(null, 'edit.php?post_type=idea' ).'">ideas</a> page. It is possible to bulk reassign ideas using the WordPress bulk select and edit functionality.', 'ideapush' ); ?> 
                    </div>


                    <h3><i class="fa fa-question-circle-o" aria-hidden="true"></i> <?php _e( 'How does guest voting work?', 'ideapush' ); ?></h3>
                    <div>
                        <?php _e( 'When someone creates an idea and isn\'t logged in, IdeaPush creates a user account in WordPress for them that is tied to their IP address. It is important we do this because it prevents people gaming the voting. Because otherwise a guest could create 50 different guest accounts and vote up their idea 50 times! 

The downside of this though is that if you have enabled guest voting and then someone who has already created a vote goes to a computer with a different IP address and tries to create an idea with the same email they won\'t be able to create a new idea as the email has already been associated to another IP address.

If this doesn\'t work for you, have no fear, because we can get around this by just using the built-in WordPress user registration system. So firstly in the board settings in the plugin settings you want to turn: GUEST VOTES/IDEAS to No. This will prevent guests creating ideas. Now you need to provide an outlet for users to create an account on your site - this can be done in many many different ways, it depends on what works for you. But you could have some text like, "What to create an idea, click here to create an account on our site first", and this goes to a user registration form - there are hundreds of plugins that can do this kind of thing, check out this page <a target="_blank" href="https://wordpress.org/plugins/tags/user-registration/">here</a> for just some of them. 

Now once someone is registered with your site they will be able to log in and out of your site and create ideas on the idea board without being impeded by their IP address. ', 'ideapush' ); ?> 
                    </div>










                    
                    
                </div>  
                <br></br>
                <h2><?php _e( 'Support', 'ideapush' ); ?></h2>
                
                <p style="font-weight: 900; color: red;"><?php _e( 'Before making a support request please read the above frequently asked questions. When submitting a request on the WordPress forum please include the following information otherwise I may not respond:', 'ideapush' ); ?></p>
                
        

                <p><code><?php echo 'PHP Version: <strong>'.phpversion().'</strong>'; ?></br>
                <?php echo 'Wordpress Version: <strong>'.get_bloginfo('version').'</strong>'; ?></br>
                Plugin Version: <strong><?php echo idea_push_plugin_get_version(); ?></strong></br>
                Current Theme: <strong><?php 
                $user_theme = wp_get_theme();    
                echo esc_html( $user_theme->get( 'Name' ) );
                ?></strong></br></code></p>
                
                <p><?php _e( 'URL\'s and Screenshots of issues can also be extremely helpful in diagnosing things so please include this where possible. We typically reply to support requests within 48 hours. To show your appreciation of our support we would be grateful if you could give us a <a target="_blank" href="https://wordpress.org/support/plugin/ideapush/reviews/?rate=5#new-post">positive review <i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i></a>.', 'ideapush' ); ?></p>

                <a class="button-secondary" target="_blank" href="https://wordpress.org/support/plugin/ideapush" >Create a support request on the forum</a>

                <p>For priority support please <a target="_blank" href="https://northernbeacheswebsites.com.au/ideapush-pro/">upgrade to the pro version of the plugin</a>.</p>
                
                
            </div>
        </td>
    </tr>
    <?php
    
}


function idea_push_idea_form_callback(){
    
    ?>
    <tr class="ideapush_settings_row" valign="top">
        <td scope="row" colspan="2">
            <div class="inside">
                
                
                <div style="font-weight: 600;" class="notice notice-info inline">


                    <p><?php 
                    
                    //we will customise this message depending if they are using the pro version or not
                    global $ideapush_is_pro;

                    if($ideapush_is_pro == "YES"){
                        $message = 'These options change the settings of the idea submission form used in the front end area of the idea board. You can create multiple form settings and assign them to different boards on the <a class="open-tab" href="#boards">Boards</a> tab under the "Field Setting" option for the board.';

                    } else {
                        $message = 'These options change the settings of the idea submission form used in the front end area of the idea board.';   
                    }
                    
                    _e($message, 'ideapush' ); 
                    

                    ?></p>
                </div>
            </div>
        </td>
    </tr>
    <?php
    
}




function idea_push_boards_callback(){
    
    global $ideapush_is_pro;

    //get user roles and put them into a hidden div
    $editable_roles = get_editable_roles();
    
    $roleData = '';
    
    foreach ($editable_roles as $role => $details) {
        $roleData .= $role.'|';
        $roleData .= $details['name'].'||';
    }
    
    
    echo '<div id="idea-push-user-roles" style="display: none;" data="'.$roleData.'"></div>';


    
    $formSettingData = '';

    //get options
    $options = get_option('idea_push_settings');

    //get current option
    $currentOption = $options['idea_push_form_settings'];

 
    //get the options and split it into chunks
    if(strpos($currentOption, '^^^^') !== false){
        $explodedOptions = explode('^^^^',$currentOption);
    } else {
        $explodedOptions = explode('||||',$currentOption);   
    }


    foreach($explodedOptions as $formSetting){

        $explodedSubOptions = explode('|||',$formSetting);

        $settingName = $explodedSubOptions[0];

        $formSettingData .= $settingName.'|';

    }   


    echo '<div id="idea-push-form-settings" style="display: none;" data="'.$formSettingData .'"></div>';
    
    
    ?>




<tr class="ideapush_settings_row" valign="top">
        <td scope="row" colspan="2">
            <div class="inside">
    <label for="idea_push_create_board">Create Board</label>
        
    <input type="text" class="regular-text" style="margin-left:10px;" id="idea_push_create_board">
                
    <button class="button-secondary" style="margin-left:5px;" id="idea_push_create_board_button">Add</button>
                
                <br></br>
            
            <ul id="board-settings"></ul>

            <br></br>     
            <h3><?php _e( 'Board Setting Information', 'ideapush' ) ?></h3>
            <ul style="list-style: disc; margin-left: 20px;">
                <li><strong><?php _e( 'Board Name', 'ideapush' ) ?></strong><?php _e( ' - is simply the name of your board and also acts as the title shown at the top of the idea board.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Vote threshold', 'ideapush' ) ?></strong><?php _e( ' - is the amount of votes required for an idea to go from open to \'Reviewed\' status.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Hold Ideas', 'ideapush' ) ?></strong><?php _e( ' - by default when people create new ideas it creates a new idea with a \'Pending Review\' status. This enables you to check over the idea before it is published. If you turn this to \'No\' ideas will be published immidiately.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Show Comments', 'ideapush' ) ?></strong><?php _e( ' - whether people will be able to comment on ideas and show comments on the idea board listing.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Show Tags', 'ideapush' ) ?></strong><?php _e( ' - whether people will be able to add tags to an idea and whether tags will be visible on the idea board listing.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Show Attachments', 'ideapush' ) ?></strong><?php _e( ' - whether to enable people to attach an image when creating a new idea from the idea form.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Show Board Title', 'ideapush' ) ?></strong><?php _e( ' - whether to show the board title above the idea board listing.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Show Vote Target', 'ideapush' ) ?></strong><?php _e( ' - whether to show the target vote score for the board which is displayed just below the board title.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Guest Votes/Ideas', 'ideapush' ) ?></strong><?php _e( ' - whether to enable guests to be able to vote and also publish new ideas. For a guest to vote or create a new idea they must enter in a name and email address so it\'s not fully anonymous. Although guests from their perspective will appear to be guests, what actually is happening is a user account will be created for them in WordPress with the user role \'IdeaPush Guest\' which is assigned to the visitors IP Address. This does mean that using a proxy server is a method for someone to vote multiple times but this is not an easy process for most and it is a drawback to any guest system.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Enable Down Voting', 'ideapush' ) ?></strong><?php _e( ' - enables someone to vote positively or negatively for an idea.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Max Votes/Ideas Per Day', 'ideapush' ) ?></strong><?php _e( ' - these settings set the limit of the maximum amount of times a user can create an idea or cast a vote. Admin users are excluded from this limit and can create as many ideas or cast as many votes as they would like. A day starts from the first idea created or first vote cast and then spans for 24 hours. A value of minus one or blank means unlimited, a value of zero essentially blocks further idea creation and voting and a positive value sets the upper limit. Any vote contributes to the users vote count, this includes negative votes and votes that are for the same idea or rescinded votes.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Hide From Search', 'ideapush' ) ?></strong><?php _e( ' - whether to hide ideas associated with this board from WordPress\'s search.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Show Board To', 'ideapush' ) ?></strong><?php _e( ' - elect to show the board to only a certain WordPress user role. Please leave on the default "Everyone" option to show to everyone (logged in and logged out visitors).', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Pagination Number', 'ideapush' ) ?></strong><?php _e( ' - Choose how many ideas to show per a page. Please set to -1 or 0 if you want to show all ideas in an endless scroll.', 'ideapush' ) ?></li>
                
                <?php if($ideapush_is_pro == "YES"){  ?>
                
                <li><strong><?php _e( 'Enable Challenge', 'ideapush' ) ?></strong><?php _e( ' - By enabling challenges you can set a time and date which will be the end time/date of your challenge and at this time users won\'t be able to create any more ideas or cast votes. You can also set a victory condition of your challenge. Challenges can be used to incentivise good ideas, voting and idea creation and to work within project deadlines.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Challenge Victory', 'ideapush' ) ?></strong><?php _e( ' - "Most Votes" is the person who created ideas that received the most votes (it\'s not the person who voted the most), "Most Ideas" is the person who created the most ideas (if creating a large amount of ideas is your goal make sure your "Max idea per day" option is set to -1), "Popular Idea" is the person who created the idea with the most votes.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Challenge Date', 'ideapush' ) ?></strong><?php _e( ' - The date the challenge expires.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Challenge Time', 'ideapush' ) ?></strong><?php _e( ' - The time of the day on the chosen date the challenge will expire.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Challenge Message', 'ideapush' ) ?></strong><?php _e( ' - A message that shows above the board describing the challenge. Use the shortcodes [expiry] and [expiry-countdown] to display the date and/or a countdown in your challenge description. This message is hidden once the challenge has expired.', 'ideapush' ) ?></li>
                
                <li><strong><?php _e( 'Challenge Vic. Message', 'ideapush' ) ?></strong><?php _e( ' - (Challenge Victory Message) A message that shows once the challenge has expired above the board. Use the shortcodes [winner-name] and [win-number] to display the victor name(s) and the number that they achieved (this could be the amount of aggregated votes, the amount of ideas created or the amount of votes for the winning idea).', 'ideapush' ) ?></li>
                
                <?php }  ?>


                <li><strong><?php _e( 'Tag Scope', 'ideapush' ) ?></strong><?php _e( ' - If the tag scope is set to "Global" all tags created will be added to the global pool of tags and all suggested tags will come from this global pool of tags (this means that ideas from different boards can belong to the same tag). If the tag scope is set to "board" all tags created will be specific to the board which means suggested tags will also only come from the board. This can be handy if you want the same tag on different boards but they mean different things or having the tag archive page specific to the board topic is important. Please note if the tag scope is set to "Board" all tags created will have the prefix "BoardTag-#-" and this will show in the archive page of the tag.', 'ideapush' ) ?></li>

                <?php if($ideapush_is_pro == "YES"){  ?>

                <li><strong><?php _e( 'Field Setting', 'ideapush' ) ?></strong><?php _e( ' - In the <a class="open-tab" href="#idea_form">Idea Form</a> tab you can create multiple forms which are used to create new ideas. You can select what form to use for your board.', 'ideapush' ) ?></li>

                <li><strong><?php _e( 'Idea Scope', 'ideapush' ) ?></strong><?php _e( ' - If you have enabled idea suggestions in the <a class="open-tab" href="#ideapush_pro">IdeaPush Pro</a> tab then this setting enables you to choose whether suggested ideas are only retrieved from the current board (Board), or whether they are retrieved from all boards (Global).', 'ideapush' ) ?></li>


                <?php }  ?>

            </ul>
            
                </div>
        </td>
    </tr>        
            
    <?php
    
}

function idea_push_locked_callback(){
    ?>
    <tr class="ideapush_settings_row" valign="top">
        <td scope="row" colspan="2">
            <div class="inside">
                You need to purchase the pro version of the plugin to be able to enter in your purchase information which will enable automatic updates.
            </div>
        </td>
    </tr>
    <?php
    
}


//notification settings
function idea_push_notification_email_render(){ 
    
    echo '<tr class="ideapush_settings_row" valign="top">
            <td scope="row" colspan="2">
            <div class="inside">
                <div >
                    <h3>'.__( 'Admin Notifications', 'ideapush' ).'</h3>
                </div>
            </div>
        </td>
    </tr>';
    
    idea_push_settings_code_generator('idea_push_notification_email','Admin Notification Email','','text','','','','');  
}

function idea_push_tab_memory_render() {                                     idea_push_settings_code_generator('idea_push_tab_memory','Tab Memory','Remembers the last settings tab','text','','','','hidden-row');   
}













//administrator notification idea submitted

function idea_push_notification_idea_submitted_render() {                                     idea_push_settings_code_generator('idea_push_notification_idea_submitted','Receive admin notifications when any idea is submitted','','checkbox','','','','enable-email-notification-checkbox');   
}

   
function idea_push_notification_idea_submitted_subject_render() { 
    
    $values = array('Idea Title','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_idea_submitted_subject','Email subject','','shortcode','A new idea has been created: [Idea Title]',$values,'','email-subject');  
}

function idea_push_notification_idea_submitted_content_render() { 
    
    $values = array('Idea Title','Idea Content','Idea Link','Author First Name','Author Last Name','Board Name','Idea Edit Link');
    
    idea_push_settings_code_generator('idea_push_notification_idea_submitted_content','Email content','','textarea-advanced','A new idea has been created by [Author First Name] [Author Last Name]: [Idea Title] and can be edited here: [Idea Edit Link]. Thank you',$values,'','email-content');  
}

    
    
    
    

//administrator notification idea ready for review

function idea_push_notification_idea_review_render() {                                     idea_push_settings_code_generator('idea_push_notification_idea_review','Receive admin notifications when an idea is ready for review','','checkbox','','','','enable-email-notification-checkbox');   
}


function idea_push_notification_idea_review_subject_render() { 
    
    $values = array('Idea Title','Author First Name','Author Last Name','Vote Count','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_idea_review_subject','Email subject','','shortcode','[Idea Title] has reached the vote threshold',$values,'','email-subject');  
}

function idea_push_notification_idea_review_content_render() { 
    
    $values = array('Idea Title','Idea Content','Idea Link','Author First Name','Author Last Name','Vote Count','Board Name','Idea Edit Link');
    
    idea_push_settings_code_generator('idea_push_notification_idea_review_content','Email content','','textarea-advanced','The idea [Idea Title] submitted by [Author First Name] [Author Last Name] has reached [Vote Count] so it\'s now ready to be reviewed: [Idea Edit Link]',$values,'','email-content');  
}








//author notifications
//author idea created published
function idea_push_notification_author_idea_created_published_enable_render() {  
    
    //($id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass)
    echo '<tr class="ideapush_settings_row" valign="top">
            <td scope="row" colspan="2">
            <div class="inside">
                <div >
                    <h3>'.__( 'Author Notifications', 'ideapush' ).'</h3>
                </div>
            </div>
        </td>
    </tr>';
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_created_published_enable','Author notification when idea is created and published','','checkbox','','','','enable-email-notification-checkbox');   
}



function idea_push_notification_author_idea_created_published_subject_render() { 
    
    $values = array('Idea Title','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_created_published_subject','Email subject','','shortcode','Your idea - [Idea Title] - has been published',$values,'','email-subject');  
}

function idea_push_notification_author_idea_created_published_content_render() { 
    
    $values = array('Idea Title','Idea Content','Idea Link','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_created_published_content','Email content','','textarea-advanced','Hi [Author First Name], your idea: [Idea Title] has been published and is accessible here: [Idea Link]. Thank you',$values,'','email-content');  
}



//author idea created ready for review
function idea_push_notification_author_idea_created_reviewed_enable_render() {  
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_created_reviewed_enable','Author notification when idea is created and under review','','checkbox','','','','enable-email-notification-checkbox');   
}



function idea_push_notification_author_idea_created_reviewed_subject_render() { 
    
    $values = array('Idea Title','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_created_reviewed_subject','Email subject','','shortcode','Your idea - [Idea Title] - has been received and is currently undergoing review',$values,'','email-subject');  
}

function idea_push_notification_author_idea_created_reviewed_content_render() { 
    
    $values = array('Idea Title','Idea Content','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_created_reviewed_content','Email content','','textarea-advanced','Hi [Author First Name], your idea: [Idea Title] has been received and is currently undergoing review. Thank you',$values,'','email-content');  
}







//author review
function idea_push_notification_author_idea_change_review_enable_render() {  
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_change_review_enable','Author notification when status changed to review','','checkbox','','','','enable-email-notification-checkbox');   
}


function idea_push_notification_author_idea_change_review_subject_render() { 
    
    $values = array('Idea Title','Author First Name','Author Last Name','Vote Count','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_change_review_subject','Email subject','','shortcode','Your idea is now undergoing review as it has now reached [Vote Count] votes',$values,'','email-subject');  
}

function idea_push_notification_author_idea_change_review_content_render() { 
    
    $values = array('Idea Title','Idea Content','Idea Link','Author First Name','Author Last Name','Vote Count','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_change_review_content','Email content','','textarea-advanced','Hi [Author First Name], your idea: [Idea Title] has now reached [Vote Count] votes so it will now be reviewed. Thank you',$values,'','email-content');  
}



//author approved
function idea_push_notification_author_idea_change_approved_enable_render() {  
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_change_approved_enable','Author notification when status changed to approved','','checkbox','','','','enable-email-notification-checkbox');   
}


function idea_push_notification_author_idea_change_approved_subject_render() { 
    
    $values = array('Idea Title','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_change_approved_subject','Email subject','','shortcode','Your idea - [Idea Title] - has been approved',$values,'','email-subject');  
}

function idea_push_notification_author_idea_change_approved_content_render() { 
    
    $values = array('Idea Title','Idea Content','Idea Link','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_change_approved_content','Email content','','textarea-advanced','Hi [Author First Name], your idea: [Idea Title] has been approved. Thank you',$values,'','email-content');  
}





//author declined
function idea_push_notification_author_idea_change_declined_enable_render() {  
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_change_declined_enable','Author notification when status changed to declined','','checkbox','','','','enable-email-notification-checkbox');   
}


function idea_push_notification_author_idea_change_declined_subject_render() { 
    
    $values = array('Idea Title','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_change_declined_subject','Email subject','','shortcode','Your idea - [Idea Title] - has been declined',$values,'','email-subject');  
}

function idea_push_notification_author_idea_change_declined_content_render() { 
    
    $values = array('Idea Title','Idea Content','Idea Link','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_change_declined_content','Email content','','textarea-advanced','Hi [Author First Name], your idea: [Idea Title] has been declined. Thank you',$values,'','email-content');  
}


//author inprogress
function idea_push_notification_author_idea_change_in_progress_enable_render() {  
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_change_in_progress_enable','Author notification when status changed to in progress','','checkbox','','','','enable-email-notification-checkbox');   
}


function idea_push_notification_author_idea_change_in_progress_subject_render() { 
    
    $values = array('Idea Title','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_change_in_progress_subject','Email subject','','shortcode','Your idea - [Idea Title] - is currently being worked on',$values,'','email-subject');  
}

function idea_push_notification_author_idea_change_in_progress_content_render() { 
    
    $values = array('Idea Title','Idea Content','Idea Link','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_change_in_progress_content','Email content','','textarea-advanced','Hi [Author First Name], your idea: [Idea Title] is currently being worked on. Thank you',$values,'','email-content');  
}



//author completed
function idea_push_notification_author_idea_change_completed_enable_render() {  
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_change_completed_enable','Author notification when status changed to completed','','checkbox','','','','enable-email-notification-checkbox');   
}


function idea_push_notification_author_idea_change_completed_subject_render() { 
    
    $values = array('Idea Title','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_change_completed_subject','Email subject','','shortcode','Your idea - [Idea Title] - has been completed',$values,'','email-subject');  
}

function idea_push_notification_author_idea_change_completed_content_render() { 
    
    $values = array('Idea Title','Idea Content','Idea Link','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_author_idea_change_completed_content','Email content','','textarea-advanced','Hi [Author First Name], your idea: [Idea Title] has been completed. Thank you',$values,'','email-content');  
}




//author notification when voter voted on their idea
function idea_push_notification_author_voter_voted_enable_render() {  
    
    idea_push_settings_code_generator('idea_push_notification_author_voter_voted_enable','Author notification when someone votes on their idea','This notification is only sent upon a positive vote.','checkbox','','','','enable-email-notification-checkbox');   
}


function idea_push_notification_author_voter_voted_subject_render() { 
    
    $values = array('Idea Title','Author First Name','Author Last Name','Board Name','Voter First Name','Voter Last Name');
    
    idea_push_settings_code_generator('idea_push_notification_author_voter_voted_subject','Email subject','','shortcode','Someone just voted on your idea - [Idea Title]',$values,'','email-subject');  
}

function idea_push_notification_author_voter_voted_content_render() { 
    
    $values = array('Idea Title','Idea Content','Idea Link','Author First Name','Author Last Name','Board Name','Voter First Name','Voter Last Name');
    
    idea_push_settings_code_generator('idea_push_notification_author_voter_voted_content','Email content','','textarea-advanced','Hi [Author First Name], [Voter First Name] just voted on your idea: [Idea Title]. Thank you',$values,'','email-content');  
}








   












//voter review
function idea_push_notification_voter_idea_change_review_enable_render() {  
    
    echo '<tr class="ideapush_settings_row" valign="top">
            <td scope="row" colspan="2">
            <div class="inside">
                <div >
                    <h3>'.__( 'Positive Voter Notifications', 'ideapush' ).'</h3>
                </div>
            </div>
        </td>
    </tr>';
    
    idea_push_settings_code_generator('idea_push_notification_voter_idea_change_review_enable','Voter notification when status changed to review','','checkbox','','','','enable-email-notification-checkbox');   
}


function idea_push_notification_voter_idea_change_review_subject_render() { 
    
    $values = array('Idea Title','Voter First Name','Voter Last Name','Vote Count','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_voter_idea_change_review_subject','Email subject','','shortcode','An idea you voted on is now being reviewed',$values,'','email-subject');  
}

function idea_push_notification_voter_idea_change_review_content_render() { 
    
    $values = array('Idea Title','Idea Content','Idea Link','Voter First Name','Voter Last Name','Author First Name','Author Last Name','Vote Count','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_voter_idea_change_review_content','Email content','','textarea-advanced','Hi [Voter First Name], an idea you voted on: [Idea Title] has now reached [Vote Count] votes and is now being reviewed. Thank you',$values,'','email-content');  
}



//voter approved
function idea_push_notification_voter_idea_change_approved_enable_render() {  
    
    idea_push_settings_code_generator('idea_push_notification_voter_idea_change_approved_enable','Voter notification when status changed to approved','','checkbox','','','','enable-email-notification-checkbox');   
}


function idea_push_notification_voter_idea_change_approved_subject_render() { 
    
    $values = array('Idea Title','Voter First Name','Voter Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_voter_idea_change_approved_subject','Email subject','','shortcode','An idea you voted on is now approved',$values,'','email-subject');  
}

function idea_push_notification_voter_idea_change_approved_content_render() { 
    
    $values = array('Idea Title','Idea Content','Idea Link','Voter First Name','Voter Last Name','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_voter_idea_change_approved_content','Email content','','textarea-advanced','Hi [Voter First Name], an idea you voted on: [Idea Title] is now approved. Thank you',$values,'','email-content');  
}





//voter declined
function idea_push_notification_voter_idea_change_declined_enable_render() {  
    
    idea_push_settings_code_generator('idea_push_notification_voter_idea_change_declined_enable','Voter notification when status changed to declined','','checkbox','','','','enable-email-notification-checkbox');   
}


function idea_push_notification_voter_idea_change_declined_subject_render() { 
    
    $values = array('Idea Title','Voter First Name','Voter Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_voter_idea_change_declined_subject','Email subject','','shortcode','An idea you voted on has been declined',$values,'','email-subject');  
}

function idea_push_notification_voter_idea_change_declined_content_render() { 
    
    $values = array('Idea Title','Idea Content','Idea Link','Voter First Name','Voter Last Name','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_voter_idea_change_declined_content','Email content','','textarea-advanced','Hi [Voter First Name], an idea you voted on: [Idea Title] has been declined. Thank you',$values,'','email-content');  
}


//voter inprogress
function idea_push_notification_voter_idea_change_in_progress_enable_render() {  
    
    idea_push_settings_code_generator('idea_push_notification_voter_idea_change_in_progress_enable','Voter notification when status changed to in progress','','checkbox','','','','enable-email-notification-checkbox');   
}


function idea_push_notification_voter_idea_change_in_progress_subject_render() { 
    
    $values = array('Idea Title','Voter First Name','Voter Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_voter_idea_change_in_progress_subject','Email subject','','shortcode','An idea you voted on is now being worked on',$values,'','email-subject');  
}

function idea_push_notification_voter_idea_change_in_progress_content_render() { 
    
    $values = array('Idea Title','Idea Content','Idea Link','Voter First Name','Voter Last Name','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_voter_idea_change_in_progress_content','Email content','','textarea-advanced','Hi [Voter First Name], an idea you voted on: [Idea Title] is now being worked on. Thank you',$values,'','email-content');  
}



//voter completed
function idea_push_notification_voter_idea_change_completed_enable_render() {  
    
    idea_push_settings_code_generator('idea_push_notification_voter_idea_change_completed_enable','Voter notification when status changed to completed','','checkbox','','','','enable-email-notification-checkbox');   
}


function idea_push_notification_voter_idea_change_completed_subject_render() { 
    
    $values = array('Idea Title','Voter First Name','Voter Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_voter_idea_change_completed_subject','Email subject','','shortcode','An idea you voted on has now been completed',$values,'','email-subject');  
}

function idea_push_notification_voter_idea_change_completed_content_render() { 
    
    $values = array('Idea Title','Idea Content','Idea Link','Voter First Name','Voter Last Name','Author First Name','Author Last Name','Board Name');
    
    idea_push_settings_code_generator('idea_push_notification_voter_idea_change_completed_content','Email content','','textarea-advanced','Hi [Voter First Name], an idea you voted on: [Idea Title] has now been completed. Thank you',$values,'','email-content');  
}





//status settings
function idea_push_change_open_status_render() { 
    idea_push_settings_code_generator('idea_push_change_open_status','Change Open Status Name','If you leave this blank the default "Open" status will be used.','text','','','','');  
}

function idea_push_change_reviewed_status_render() { 
    idea_push_settings_code_generator('idea_push_change_reviewed_status','Change Reviewed Status Name','If you leave this blank the default "Reviewed" status will be used.','text','','','','');  
}

function idea_push_change_approved_status_render() { 
    idea_push_settings_code_generator('idea_push_change_approved_status','Change Approved Status Name','If you leave this blank the default "Approved" status will be used.','text','','','','');  
}

function idea_push_change_declined_status_render() { 
    idea_push_settings_code_generator('idea_push_change_declined_status','Change Declined Status Name','If you leave this blank the default "Declined" status will be used.','text','','','','');  
}

function idea_push_change_in_progress_status_render() { 
    idea_push_settings_code_generator('idea_push_change_in_progress_status','Change In Progress Status Name','If you leave this blank the default "In Progress" status will be used.','text','','','','');  
}

function idea_push_change_completed_status_render() { 
    idea_push_settings_code_generator('idea_push_change_completed_status','Change Completed Status Name','If you leave this blank the default "Completed" status will be used.','text','','','','');  
}

function idea_push_change_all_statuses_status_render() { 
    idea_push_settings_code_generator('idea_push_change_all_statuses_status','Change All Statuses Name','If you leave this blank the default "All Statuses" status will be used.','text','','','','');  
}


//design settings
function idea_push_primary_link_colour_render() {                                     idea_push_settings_code_generator('idea_push_primary_link_colour','Primary Colour of Links','It is advised not to pick white as otherwise certain user interface elements will be hidden!','color','#dd3333','','','tooltipcolors');   
}


function idea_push_custom_css_render() {     
    
    $values = array(array('Remove hand from idea submit buttom','.submit-new-idea i {display: none !important;}'),array('Hide empty related images','.no-related-image {display: none !important;}'),array('Hide breadcrumbs on single idea page','.idea-item-breadcrumbs {display: none !important;}'),array('Prevent growing search bar','.ideapush-search-input {width: 125px !important;}'),array('Remove search bar','.ideapush-idea-search {display: none !important;}'));
    
    idea_push_settings_code_generator('idea_push_custom_css','Custom CSS','Click on shortcodes or enter your custom CSS to change the look of the plugin.','shortcode-advanced','',$values,'','');   
    
}



//idea form settings

function idea_push_form_title_render() { 
    idea_push_settings_code_generator('idea_push_form_title','Form Title','Change the text which appears at the top of the form. If left blank this will be "Push your idea".','text','','','','hidden-row');  
}

function idea_push_idea_title_render() { 
    idea_push_settings_code_generator('idea_push_idea_title','Idea Title','Change the placeholder text of the idea title field. If left blank this will be "Idea title".','text','','','','hidden-row');  
}

function idea_push_idea_description_render() { 
    idea_push_settings_code_generator('idea_push_idea_description','Idea Description','Change the placeholder text of the idea description field. If left blank this will be "Add additional details".','text','','','','hidden-row');  
}

function idea_push_idea_tags_render() { 
    idea_push_settings_code_generator('idea_push_idea_tags','Tags Text','Change the placeholder text of the tags field. If left blank this will be "Tags".','text','','','','hidden-row');  
}

function idea_push_attachment_text_render() { 
    idea_push_settings_code_generator('idea_push_attachment_text','Idea Attachment Text','If left blank this will be "Attach image".','text','','','','hidden-row');  
}

function idea_push_allowed_file_types_render() { 
    idea_push_settings_code_generator('idea_push_allowed_file_types','Allowed File Types','Please enter file types separated by comma.','text','jpg,png','','','');  
}

function idea_push_submit_button_render() { 
    idea_push_settings_code_generator('idea_push_submit_button','Submit Button','If left blank this will be "Push".','text','','','','hidden-row');  
}

function idea_push_submit_idea_button_render() { 
    idea_push_settings_code_generator('idea_push_submit_idea_button','Submit Idea Button','This button appears on the mobile display and when clicked it displays the new idea form. If left blank this will be "Submit new idea".','text','','','','hidden-row');  
}

function idea_push_recaptcha_site_key_render() { 
    idea_push_settings_code_generator('idea_push_recaptcha_site_key','reCAPTCHA Site Key','If you would like to enable Google reCAPTCHA on the registration form please enter in your reCAPTCHA Site Key in this setting. You can get your reCAPTCHA V2 key from <a target="_blank" href="https://www.google.com/recaptcha/admin#list">here</a>. If left blank no reCAPTCHA will be used.','text','','','','');  
}

function idea_push_form_settings_render() { 

    //get options
    $options = get_option('idea_push_settings');

    //get current option
    $currentOption = $options['idea_push_form_settings'];

    // print_r($currentOption);

    //creat container
    $html = '<tr class="ideapush_settings_row" valign="top"><td scope="row" colspan="2">';
    $html .= '<ul id="form-settings-container">';



    function idea_push_form_setting_builder($currentOption){

        $html = '';

        //get the options and split it into chunks
        if(strpos($currentOption, '^^^^') !== false){
            $explodedOptions = explode('^^^^',$currentOption);
        } else {
            $explodedOptions = explode('||||',$currentOption);   
        }

        
        


        //if the values are blank actually make blank
        function idea_push_replace_blank_value($input){
            if($input == ' '){
                return '';    
            } else {
                return $input;  
            }
        }


        foreach($explodedOptions as $formSetting){

            $explodedSubOptions = explode('|||',$formSetting);

            $settingName = $explodedSubOptions[0];

            // print_r($explodedSubOptions);
            

            if(strlen($settingName)>0){

                if($settingName == 'Default'){
                    $formSettingClass = 'default-form-setting';
                } else {
                    $formSettingClass = '';    
                }

                $html .= '<li class="form-setting '.$formSettingClass.'">';
                    $html .= '<div class="form-setting-inner">';

                        if($settingName == 'Default'){
                            $formSettingNameClass = 'readonly';
                        } else {
                            $formSettingNameClass = '';    
                        }

                        $html .= '<input class="form-setting-name" type="text" value="'.$settingName.'" '.$formSettingNameClass.'>';

                        $html .= '<div class="form-setting-tools">';
                            $html .= '<i name="Edit Form Setting" class="fa fa-pencil-square-o edit-form-settings" aria-hidden="true"></i>';

                            global $ideapush_is_pro;

                            if($ideapush_is_pro == "YES"){
                                $html .= '<i name="Duplicate Form Setting" class="fa fa-clone duplicate-form-settings" aria-hidden="true"></i>';
                            }    
                            
                            $html .= '<i name="Delete Form Setting" class="fa fa-trash-o delete-form-settings" aria-hidden="true"></i>';
                            


                        $html .= '</div>';

                $html .= '</div>';
                $html .= '<div class="form-setting-inner form-setting-inner-expanded-setting">';

                    //standard options
                    $standardOptions = $explodedSubOptions[1];
                    $standardOptionsExploded = explode('||',$standardOptions);

                    

                    
                    $html .= '<strong>Standard Field Labels</strong>';

                    $html .= '<table>';

                        //form title
                        $html .= '<tr><td>';
                            $html .= '<label>'.__( 'Form Title', 'ideapush' );
                            $html .= ' <i class="fa fa-info-circle" aria-hidden="true"></i>';
                            $html .= '<p class="hidden"><em>'.__( 'Change the text which appears at the top of the form. If left blank this will be "Push your idea".', 'ideapush' ).'</em></p>';
                            $html .= '</label>';
                        $html .= '</td>';

                        $html .= '<td>';
                            $html .= '<input class="form-title" type="text" value="'.idea_push_replace_blank_value($standardOptionsExploded[0]).'">';  
                        $html .= '</td></tr>';


                        //idea title
                        $html .= '<tr><td>';
                            $html .= '<label>'.__( 'Idea Title', 'ideapush' );
                            $html .= ' <i class="fa fa-info-circle" aria-hidden="true"></i>';
                            $html .= '<p class="hidden"><em>'.__( 'Change the placeholder text of the idea title field. If left blank this will be "Idea title".', 'ideapush' ).'</em></p>';
                            $html .= '</label>';
                        $html .= '</td>';

                        $html .= '<td>';
                            $html .= '<input class="idea-title" type="text" value="'.idea_push_replace_blank_value($standardOptionsExploded[1]).'">';  
                        $html .= '</td></tr>';



                        //idea description
                        $html .= '<tr><td>';
                            $html .= '<label>'.__( 'Idea Description', 'ideapush' );
                            $html .= ' <i class="fa fa-info-circle" aria-hidden="true"></i>';
                            $html .= '<p class="hidden"><em>'.__( 'Change the placeholder text of the idea description field. If left blank this will be "Add additional details".', 'ideapush' ).'</em></p>';
                            $html .= '</label>';
                        $html .= '</td>';

                        $html .= '<td>';
                            $html .= '<input class="idea-description" type="text" value="'.idea_push_replace_blank_value($standardOptionsExploded[2]).'">';  
                        $html .= '</td></tr>';

                        //idea tags
                        $html .= '<tr><td>';
                            $html .= '<label>'.__( 'Tags Text', 'ideapush' );
                            $html .= ' <i class="fa fa-info-circle" aria-hidden="true"></i>';
                            $html .= '<p class="hidden"><em>'.__( 'Change the placeholder text of the tags field. If left blank this will be "Tags".', 'ideapush' ).'</em></p>';
                            $html .= '</label>';
                        $html .= '</td>';

                        $html .= '<td>';
                            $html .= '<input class="idea-tags" type="text" value="'.idea_push_replace_blank_value($standardOptionsExploded[3]).'">';  
                        $html .= '</td></tr>';

                        //idea attachment text
                        $html .= '<tr><td>';
                            $html .= '<label>'.__( 'Idea Attachment Text', 'ideapush' );
                            $html .= ' <i class="fa fa-info-circle" aria-hidden="true"></i>';
                            $html .= '<p class="hidden"><em>'.__( 'If left blank this will be "Attach image".', 'ideapush' ).'</em></p>';
                            $html .= '</label>';
                        $html .= '</td>';

                        $html .= '<td>';
                            $html .= '<input class="idea-attachment" type="text" value="'.idea_push_replace_blank_value($standardOptionsExploded[4]).'">';  
                        $html .= '</td></tr>';

                        //submit button
                        $html .= '<tr><td>';
                            $html .= '<label>'.__( 'Submit Button', 'ideapush' );
                            $html .= ' <i class="fa fa-info-circle" aria-hidden="true"></i>';
                            $html .= '<p class="hidden"><em>'.__( 'If left blank this will be "Push".', 'ideapush' ).'</em></p>';
                            $html .= '</label>';
                        $html .= '</td>';

                        $html .= '<td>';
                            $html .= '<input class="submit-button" type="text" value="'.idea_push_replace_blank_value($standardOptionsExploded[5]).'">';  
                        $html .= '</td></tr>';

                        //submit idea button
                        $html .= '<tr><td>';
                            $html .= '<label>'.__( 'Submit Idea Button', 'ideapush' );
                            $html .= ' <i class="fa fa-info-circle" aria-hidden="true"></i>';
                            $html .= '<p class="hidden"><em>'.__( 'This button appears on the mobile display and when clicked it displays the new idea form. If left blank this will be "Submit new idea".', 'ideapush' ).'</em></p>';
                            $html .= '</label>';
                        $html .= '</td>';

                        $html .= '<td>';
                            $html .= '<input class="submit-idea-button" type="text" value="'.idea_push_replace_blank_value($standardOptionsExploded[6]).'">';  
                        $html .= '</td></tr>';



                    $html .= '</table>';
                            

                $html .= '</div>';

                //pro options
                global $ideapush_is_pro;

                if($ideapush_is_pro == "YES"){

                    $proOptions = $explodedSubOptions[2];

                    $html .= '<div class="form-setting-inner form-setting-inner-expanded-setting">';
                        $html .= '<strong>Custom Fields</strong>';
                        $html .= '<ul class="form-setting-pro-options">';
                           $html .= idea_push_form_settings_pro_options($proOptions);
                        $html .= '</ul>';
                    $html .= '</div>';
                }
                
            $html .= '</li>';

            }

        }

        return $html;
    }


    //here we run check whether setting exists or not, if it does use the option and send to function, otherwise create a new string using the existing settings
    if(isset($currentOption) && strlen($currentOption)>0){
        $html .= idea_push_form_setting_builder($currentOption);
    } elseif(isset($options['idea_push_form_title'])) {
        //build the option from existing settings
        $oldSettings = '||||Default|||'.$options['idea_push_form_title'].'||'.$options['idea_push_idea_title'].'||'.$options['idea_push_idea_description'].'||'.$options['idea_push_idea_tags'].'||'.$options['idea_push_attachment_text'].'||'.$options['idea_push_submit_button'].'||'.$options['idea_push_submit_idea_button'].'||';
        
        $html .= idea_push_form_setting_builder($oldSettings);

    } else {
        $noSettings = '||||Default||| || || || || || || ||';
        
        $html .= idea_push_form_setting_builder($noSettings);
    }

    



    $html .= '</ul>';
    $html .= '</td></tr>';

    echo $html;

    idea_push_settings_code_generator('idea_push_form_settings','Form Settings','','text','','','','hidden-row');  
}

function idea_push_enable_bot_protection_render() { 
    idea_push_settings_code_generator('idea_push_enable_bot_protection','Enable Bot Protection','By checking this option we will add a math problem and honeypot to the form to reduce spam.','checkbox','','','','');  
}









//board settings
function idea_push_board_configuration_render(){         
    idea_push_settings_code_generator('idea_push_board_configuration','Board Configuration','','text','','','','hidden-row'); 
    
}


//hide admin notice
function idea_push_hide_admin_notice_render() {     
    idea_push_settings_code_generator('idea_push_hide_admin_notice','Hide admin notice','','checkbox','','','','hidden-row');   
}




function idea_push_disable_approved_status_render() {                                     
    idea_push_settings_code_generator('idea_push_disable_approved_status','Disable the approved status','','checkbox','','','','');   
}

function idea_push_disable_declined_status_render() {                                     
    idea_push_settings_code_generator('idea_push_disable_declined_status','Disable the declined status','','checkbox','','','','');   
}

function idea_push_disable_in_progress_status_render() {                                     
    idea_push_settings_code_generator('idea_push_disable_in_progress_status','Disable the in progress status','','checkbox','','','','');   
}

function idea_push_disable_completed_status_render() {                                     
    idea_push_settings_code_generator('idea_push_disable_completed_status','Disable the completed status','','checkbox','','','','');   
}

function idea_push_disable_all_statuses_status_render() {                                     
    idea_push_settings_code_generator('idea_push_disable_all_statuses_status','Disable the all statuses status','','checkbox','','','','');   
}












//function to generate settings rows
function idea_push_settings_code_generator($id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass) {
    
    //get options
    $options = get_option('idea_push_settings');
    

    //if it is a checkbox we need to slightly different value logic
    if($type == 'checkbox'){
        if(isset($options[$id])){  
            $value = intval($options[$id]);    
        } else {
            $value = 0;
        }
    } else {
        //value
        if(isset($options[$id])){  
            $value = $options[$id];    
        } elseif(strlen($default)>0) {
            $value = $default;   
        } else {
            $value = '';
        }
    }

    
    
    
    //the label
    echo '<tr class="ideapush_settings_row '.$rowClass.'" valign="top">';
    echo '<td scope="row">';
    echo '<label for="'.$id.'">'.$label;
    if(strlen($description)>0){
        echo ' <i class="fa fa-info-circle" aria-hidden="true"></i>';
        echo '<p class="hidden"><em>'.$description.'</em></p>';
    }
    if(strlen($importantNote)>0){
        echo '</br><span style="color: #CC0000;">';
        echo $importantNote;
        echo '</span>';
    } 
    echo '</label>';
    
    
    
    if($type == 'shortcode') {
        echo '</br>';
        
        foreach($parameter as $shortcodevalue){
            echo '<a value="['.$shortcodevalue.']" class="ideapush_append_buttons">['.$shortcodevalue.']</a>';
        }       
    }
    
    if($type == 'textarea-advanced') {
        echo '</br>';
        
        foreach($parameter as $shortcodevalue){
            echo '<a value="['.$shortcodevalue.']" data="'.$id.'" class="ideapush_append_buttons_advanced">['.$shortcodevalue.']</a>';
        }       
    }
    
    
    if($type == 'shortcode-advanced') {
        echo '</br>';
        
        foreach($parameter as $shortcodevalue){
            echo '<a value="'.$shortcodevalue[1].'" class="ideapush_append_buttons">'.$shortcodevalue[0].'</a>';
        }       
    }
    
    

    //the setting    
    echo '</td><td>';
    
    //text
    if($type == "text"){
        echo '<input type="text" class="regular-text" name="idea_push_settings['.$id.']" id="'.$id.'" value="'.$value.'">';     
    }
    
    //select
    if($type == "select"){
        echo '<select name="idea_push_settings['.$id.']" id="'.$id.'">';
        
        foreach($parameter as $x => $xvalue){
            echo '<option value="'.$x.'" ';
            if($x == $value) {
                echo 'selected="selected"';    
            }
            echo '>'.$xvalue.'</option>';
        }
        echo '</select>';
    }
    
    
    //checkbox
    if($type == "checkbox"){
        echo '<label class="switch">';
        echo '<input type="checkbox" id="'.$id.'" name="idea_push_settings['.$id.']" ';
        echo checked($value,1,false);
        echo 'value="1">';
        echo '<span class="slider round"></span></label>';
    }
        
    //color
    if($type == "color"){ 
        echo '<input name="idea_push_settings['.$id.']" id="'.$id.'" type="text" value="'.$value.'" class="my-color-field" data-default-color="'.$default.'"/>';    
    }
    
    //page
    if($type == "page"){
        $args = array(
            'echo' => 0,
            'selected' => $value,
            'name' => 'idea_push_settings['.$id.']',
            'id' => $id,
            'show_option_none' => $default,
            'option_none_value' => "default",
            'sort_column'  => 'post_title',
            );
        
            echo wp_dropdown_pages($args);     
    }
    
    //textarea
    if($type == "textarea" || $type == "shortcode" || $type == "shortcode-advanced"){
        echo '<textarea cols="46" rows="3" name="idea_push_settings['.$id.']" id="'.$id.'">'.$value.'</textarea>';
    }
    
    
    //textarea-advanced
//    if($type == "textarea-advanced"){
//        wp_editor(html_entity_decode(stripslashes($value)), $id, $settings = array(
//            'textarea_name' => 'idea_push_settings['.$id.']',
//            'drag_drop_upload' => true,
//            'textarea_rows' => 7,  
//            )
//        );
//    }  
    
    
    if($type == "textarea-advanced"){
        if(isset($value)){    
            wp_editor(html_entity_decode(stripslashes($value)), $id, $settings = array(
            'wpautop' => false,    
            'textarea_name' => 'idea_push_settings['.$id.']',
            'drag_drop_upload' => true,
            'textarea_rows' => 7, 
            ));    
        } else {
            wp_editor("", $id, $settings = array(
            'wpautop' => false,    
            'textarea_name' => 'idea_push_settings['.$id.']',
            'drag_drop_upload' => true,
            'textarea_rows' => 7,
            ));         
        }
    }
    
    //number
    if($type == "number"){
        echo '<input type="number" class="regular-text" name="idea_push_settings['.$id.']" id="'.$id.'" value="'.$value.'">';     
    }

    echo '</td></tr>';

}

?>