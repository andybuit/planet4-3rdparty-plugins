<?php

$legend = null;
$legendStyle = null;
extract($chart);

if ($chart["chart_max_width"] > 0){
    $width = $chart["chart_max_width"] . "px";

    if ($chart["chart_type"] != 5 || $chart["chart_type"] != 6)
        $height = $chart["chart_max_width"] / 2 . "px;";
}
else {
    $width = "100%";
    $height = "";
}

if ($chart["chart_type"] == 2 || $chart["chart_type"] == 3 || $chart["chart_type"] == 6){

    $legendStyle = "style='font-style:{$chart_legend_font_style}; color:{$chart_legend_font_colour}; '";

    if ($chart["chart_legend"])
        $legend .= "<ul {$legendStyle} data-font-size='{$chart_legend_font_size}' id='legend-{$id}' class='weblator-chart-legend {$chart_legend_position}'></ul>";
}

$var = "<div class='weblator-chart-container' data-random-id='" . uniqid() . "' data-chart-id='{$id}' data-chart-loaded='0' style='width:{$width}; height:{$height}'>";

if (substr($chart["chart_legend_position"], 0, 1) == "t")
    $var .= $legend;

$var .= "<canvas id='weblator-charts-chart-{$id}' class='weblator-chart' width='{$width}' height='{$height}'></canvas>";

if (substr($chart["chart_legend_position"], 0, 1) == "b")
    $var .= $legend;

$var .= '</div>';
