<?php

class Weblator_Charts_Public_Ajax {

    public static function getChartData(){

        global $wpdb;

        $chart_id = $_POST["id"];

        $chart_type = $wpdb->get_var( $wpdb->prepare("SELECT chart_type FROM " . WEBLATOR_CHARTS_PREFIX . "charts WHERE id = %d", $chart_id) );

        $colour_options = array();

        if ($chart_type == 1)

            $colour_options[] = array(
                "fillColor" => $wpdb->get_var( $wpdb->prepare("SELECT style_value FROM " . WEBLATOR_CHARTS_PREFIX . "charts_style_value WHERE chart_id = %d AND style_id = 1", $chart_id) ),
                "strokeColor" => $wpdb->get_var( $wpdb->prepare("SELECT style_value FROM " . WEBLATOR_CHARTS_PREFIX . "charts_style_value WHERE chart_id = %d AND style_id = 2", $chart_id) )
            );

        else if($chart_type == 4 || $chart_type == 5)

            $colour_options[] = array(
                "fillColor" => $wpdb->get_var( $wpdb->prepare("SELECT style_value FROM " . WEBLATOR_CHARTS_PREFIX . "charts_style_value WHERE chart_id = %d AND style_id = 1", $chart_id) ),
                "strokeColor" => $wpdb->get_var( $wpdb->prepare("SELECT style_value FROM " . WEBLATOR_CHARTS_PREFIX . "charts_style_value WHERE chart_id = %d AND style_id = 2", $chart_id) ),
                "pointColor" => $wpdb->get_var( $wpdb->prepare("SELECT style_value FROM " . WEBLATOR_CHARTS_PREFIX . "charts_style_value WHERE chart_id = %d AND style_id = 3", $chart_id) ),
                "pointStrokeColor" => $wpdb->get_var( $wpdb->prepare("SELECT style_value FROM " . WEBLATOR_CHARTS_PREFIX . "charts_style_value WHERE chart_id = %d AND style_id = 4", $chart_id) )
            );

        $results =
            $wpdb->get_results(
                $wpdb->prepare("
                    SELECT
                      " . WEBLATOR_CHARTS_PREFIX . "chart_options.id,
                      " . WEBLATOR_CHARTS_PREFIX . "chart_options.option_name AS option_value,
                      " . WEBLATOR_CHARTS_PREFIX . "chart_options.option_colour,
                      " . WEBLATOR_CHARTS_PREFIX . "chart_options.option_value AS total
                      FROM " . WEBLATOR_CHARTS_PREFIX . "chart_options WHERE chart_id = %d AND option_deleted_date IS NULL ORDER BY option_order ASC", $chart_id), ARRAY_A);

        $labels = array_column($results, 'option_value');

        for($i=0; $i < count($labels); $i++){
            $labels[$i] = stripslashes($labels[$i]);
        }

        $totals = array_column($results, 'total');
        $colours = array_column($results, 'option_colour');

        $maxWidth = $wpdb->get_var( $wpdb->prepare("SELECT chart_max_width FROM " . WEBLATOR_CHARTS_PREFIX . "charts WHERE id = %d", $chart_id) );
        $legend = $wpdb->get_var( $wpdb->prepare("SELECT chart_legend FROM " . WEBLATOR_CHARTS_PREFIX . "charts WHERE id = %d", $chart_id) );
        $percentage = $wpdb->get_var( $wpdb->prepare("SELECT chart_percentage_values FROM " . WEBLATOR_CHARTS_PREFIX . "charts WHERE id = %d", $chart_id) );

        $main_data_set_title = $wpdb->get_var( $wpdb->prepare("SELECT main_data_set_title FROM " . WEBLATOR_CHARTS_PREFIX . "charts WHERE id = %d", $chart_id) );
        $scale_label_append = $wpdb->get_var( $wpdb->prepare("SELECT scale_label_append FROM " . WEBLATOR_CHARTS_PREFIX . "charts WHERE id = %d", $chart_id) );
        $scale_label_prepend = $wpdb->get_var( $wpdb->prepare("SELECT scale_label_prepend FROM " . WEBLATOR_CHARTS_PREFIX . "charts WHERE id = %d", $chart_id) );


        $options = $wpdb->get_results(
            $wpdb->prepare("
                SELECT
                    " . WEBLATOR_CHARTS_PREFIX . "style_options.style_key,
                    " . WEBLATOR_CHARTS_PREFIX . "charts_style_value.style_value
                FROM
                      " . WEBLATOR_CHARTS_PREFIX . "charts_style_value,
                    " . WEBLATOR_CHARTS_PREFIX . "style_chart_link,
                    " . WEBLATOR_CHARTS_PREFIX . "style_options
                WHERE
                    " . WEBLATOR_CHARTS_PREFIX . "charts_style_value.chart_id = %d
                    AND " . WEBLATOR_CHARTS_PREFIX . "style_chart_link.chart_id = %d
                    AND " . WEBLATOR_CHARTS_PREFIX . "style_chart_link.style_id = " . WEBLATOR_CHARTS_PREFIX . "charts_style_value.style_id
                    AND " . WEBLATOR_CHARTS_PREFIX . "style_options.id = " . WEBLATOR_CHARTS_PREFIX . "charts_style_value.style_id
                    AND " . WEBLATOR_CHARTS_PREFIX . "style_options.style_key IS NOT NULL
            ", $chart_id, $chart_type)
        );

        $option_key = array();
        $option_value = array();
        foreach($options as $option){

            $option_key[] = $option->style_key;
            $option_value[] = (is_numeric($option->style_value) ? (int)$option->style_value : $option->style_value);

        }

        $data_sets = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM ". WEBLATOR_CHARTS_PREFIX ."chart_options WHERE chart_id = %d AND option_deleted_date IS NULL GROUP BY data_set_id", $chart_id
            )
        );

        $data = array();
        foreach($data_sets as $d_sets){

            $data[] = array(
                "data" => $wpdb->get_results(
                    $wpdb->prepare(
                        "SELECT id, chart_id, data_set_id, option_name, option_value AS optionValue, option_order, option_colour, option_deleted_date FROM ". WEBLATOR_CHARTS_PREFIX ."chart_options WHERE data_set_id = %d AND chart_id = %d AND option_deleted_date IS NULL", $d_sets->data_set_id, $chart_id
                    )
                ),
                "style" => $wpdb->get_results(
                    $wpdb->prepare(
                        "SELECT fill_color AS fillColor, stroke_color AS strokeColor, point_color AS pointColor, point_stroke_color AS pointStrokeColor, title FROM ". WEBLATOR_CHARTS_PREFIX ."data_sets WHERE id = %d AND deleted_date IS NULL", $d_sets->data_set_id
                    )
                )
            );

        }

        $data_labels = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DISTINCT option_name FROM ". WEBLATOR_CHARTS_PREFIX ."chart_options WHERE chart_id = %d AND option_deleted_date IS NULL", $chart_id
            )
        );

        $d_labels = array();
        foreach($data_labels as $key => $lab){

            $d_labels[] = $lab->option_name;
        }

        echo json_encode(array("scale_label_append" => $scale_label_append, "scale_label_prepend" => $scale_label_prepend, "datasets" => $data, "dataLabels" => $d_labels, "labels" => $labels, "mainDataSetTitle" => $main_data_set_title, "options" => array_combine($option_key, $option_value), "percentage" => $percentage, "maxWidth" => $maxWidth, "showLegend" => $legend, "totals" => $totals, "optionColors" => $colours, "styles" => $colour_options, "chartType" => $chart_type));
        //echo json_encode(array("datasets" => $data, "data_labels" => $d_labels, "labels" => $labels, "options" => array_combine($option_key, $option_value), "percentage" => $percentage, "maxWidth" => $maxWidth, "showLegend" => $legend, "totals" => $totals, "option_colours" => $colours, "styles" => $colour_options, "chart_type" => $chart_type));
        die();

    }

}
