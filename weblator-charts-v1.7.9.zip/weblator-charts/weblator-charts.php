<?php
/**
 * @package   Weblator Charts
 * @author    Weblator <daniel.prior@weblator.com>
 * @license   GPL-2.0+
 * @link      http://plugins.weblator.com/responsive-charts
 * @copyright 2014 Weblator
 *
 * @wordpress-plugin
 * Plugin Name:       Responsive Charts
 * Plugin URI:        http://plugins.weblator.com/responsive-charts
 * Description:       ‘Responsive Charts’ allows you to create HTML5 animated charts easily in WordPress
 * Version:           1.7.9
 * Author:            Weblator
 * Author URI:        http://plugins.weblator.com/responsive-charts
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

function add_meta_tags_chart() {
    echo '<meta http-equiv="X-UA-Compatible" content="IE=Edge" />';
}

add_action('wp_head', 'add_meta_tags_chart', 1);

global $wpdb;

define('WEBLATOR_CHARTS_PREFIX', $wpdb->prefix . "weblator_charts_");


/*----------------------------------------------------------------------------*
 * Public-Facing Functionality
 *----------------------------------------------------------------------------*/

require_once( plugin_dir_path( __FILE__ ) . 'public/class-weblator-charts.php' );
register_activation_hook( __FILE__, array( 'Weblator_Charts', 'activate' ) );

add_action( 'plugins_loaded', array( 'Weblator_Charts', 'get_instance' ) );


/*----------------------------------------------------------------------------*
 * Dashboard and Administrative Functionality
 *----------------------------------------------------------------------------*/

if ( is_admin() && ( ! defined( 'DOING_AJAX' ) || ! DOING_AJAX ) ) {

    if(!class_exists('WP_List_Table')) :
        require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
    endif;

    require_once( plugin_dir_path( __FILE__ ) . 'admin/includes/class-weblator-charts-table.php' );

    require_once( plugin_dir_path( __FILE__ ) . 'admin/class-weblator-charts-admin.php' );

    add_action( 'plugins_loaded', array( 'Weblator_Charts_Admin', 'get_instance' ) );

}



require_once( plugin_dir_path( __FILE__ ) . 'admin/includes/class-weblator-charts-ajax.php' );
add_action( 'wp_ajax_loadStyleSettings', array('Weblator_Charts_Ajax','loadStyleSettings') );
add_action( 'wp_ajax_update_chart', array('Weblator_Charts_Ajax','updateChart') );
add_action( 'wp_ajax_save_chart', array('Weblator_Charts_Ajax','saveChart') );
add_action( 'wp_ajax_delete_chart', array('Weblator_Charts_Ajax','deleteChart') );
add_action( 'wp_ajax_importCSV', array('Weblator_Charts_Ajax','importCSV') );
add_action( 'wp_ajax_duplicate', array('Weblator_Charts_Ajax','duplicate') );

require_once( plugin_dir_path( __FILE__ ) . 'public/class-weblator-charts-ajax.php' );
add_action( 'wp_ajax_chart_data_chart', array( 'Weblator_Charts_Public_Ajax', 'getChartData' ) );
add_action( 'wp_ajax_nopriv_chart_data_chart', array( 'Weblator_Charts_Public_Ajax', 'getChartData' ) );

function weblator_chart_app_output_buffer() {
    ob_start();
}
add_action('init', 'weblator_chart_app_output_buffer');

if (!function_exists('array_column')) {
    function array_column($input, $column_key, $index_key = null)
    {
        if ($index_key !== null) {
            // Collect the keys
            $keys = array();
            $i = 0; // Counter for numerical keys when key does not exist

            foreach ($input as $row) {
                if (array_key_exists($index_key, $row)) {
                    // Update counter for numerical keys
                    if (is_numeric($row[$index_key]) || is_bool($row[$index_key])) {
                        $i = max($i, (int) $row[$index_key] + 1);
                    }

                    // Get the key from a single column of the array
                    $keys[] = $row[$index_key];
                } else {
                    // The key does not exist, use numerical indexing
                    $keys[] = $i++;
                }
            }
        }

        if ($column_key !== null) {
            // Collect the values
            $values = array();
            $i = 0; // Counter for removing keys

            foreach ($input as $row) {
                if (array_key_exists($column_key, $row)) {
                    // Get the values from a single column of the input array
                    $values[] = $row[$column_key];
                    $i++;
                } elseif (isset($keys)) {
                    // Values does not exist, also drop the key for it
                    array_splice($keys, $i, 1);
                }
            }
        } else {
            // Get the full arrays
            $values = array_values($input);
        }

        if ($index_key !== null) {
            return array_combine($keys, $values);
        }

        return $values;
    }

}
