<?php

class Weblator_Charts_Tables extends WP_List_Table {

    public $items;

    function __construct(){

        parent::__construct( array(
            'singular'  => __( 'chart', 'chartstable' ),     //singular name of the listed records
            'plural'    => __( 'charts', 'chartstable' ),   //plural name of the listed records
            'ajax'      => false        //does this table support ajax?

        ) );

    }

    function get_table_classes(){

        return array("widefat", "fixed", "polls", "weblator_table", "striped");
    }

    function no_items() {
        _e( 'No polls found.' );
    }

    function column_default( $item, $column_name ) {

        switch( $column_name ) {
            case 'id':
            case 'name':
                return $item[ $column_name ];
                break;

            default:
                return print_r( $item, true ) ; //Show the whole array for troubleshooting purposes
        }
    }

    function get_sortable_columns() {
        $sortable_columns = array(
            'id' => array('id', false),
            'name'  => array('name',false),

        );
        return $sortable_columns;
    }

    function get_columns(){
        $columns = array(
            'cb'        => '<input type="checkbox" />',
            'id' => __( 'ID', 'chartstable'),
            'name'    => __( 'Chart Name', 'chartstable' ),
            'chart_type'    => __( 'Chart Type', 'chartstable' ),
            'shortcode'    => __( 'Shortcode', 'chartstable' ),
            'created'    => __( 'Created', 'chartstable' ),
        );
        return $columns;
    }

    function usort_reorder( $a, $b ) {

        $orderby = ( ! empty( $_GET['orderby'] ) ) ? $_GET['orderby'] : 'poll_name';
        $order = ( ! empty($_GET['order'] ) ) ? $_GET['order'] : 'asc';
        $result = strcmp( $a[$orderby], $b[$orderby] );

        return ( $order === 'asc' ) ? $result : -$result;
    }

    function column_name($item){
        $actions = array(
            'edit'      => sprintf('<a href="?page=%s&action=%s&edit_chart=%s">Edit</a>',$_REQUEST['page'],'edit',$item['id']),
            'duplicate'      => sprintf('<a data-id="%d" data-_wpnonce="%s" href="?page=%s&action=%s&edit_chart=%s">Duplicate</a>',$item['id'], wp_create_nonce("weblator_chart_duplicate_{$item["id"]}"),  $_REQUEST['page'],'duplicate',$item['id']),
            'delete'    => sprintf('<a data-id="%d" data-_wpnonce="%s" href="?page=%s&action=%s&delete_chart=%s" class="delete_chart" data-chart-id="%s">Delete</a>',$item['id'], wp_create_nonce("weblator_chart_delete_{$item["id"]}"), $_REQUEST['page'],'delete',$item['id'], $item['id']),
        );

        return sprintf('%1$s %2$s', stripslashes($item['name']), $this->row_actions($actions) );
    }

    function get_bulk_actions() {
        $actions = array(
            'delete' => __( 'Delete' , 'polltable')
        );
        return $actions;
    }

    function process_bulk_action() {

        $entry_id = ( is_array( $_REQUEST['chart_check'] ) ) ? $_REQUEST['chart_check'] : array( $_REQUEST['chart_check'] );

        if ( 'delete' === $this->current_action() ) {

            $c = new Weblator_Charts_Ajax;

            foreach ( $entry_id as $id ) {
                $c->deleteChart($id);
            }

            wp_redirect( admin_url() . 'admin.php?page=charts', 301 );
            exit();
        }
    }

    function column_cb($item) {
        return sprintf(
            '<input type="checkbox" name="chart_check[]" value="%s" />', $item['id']
        );
    }

    function column_shortcode($item) {
        return sprintf(
            '<code>[chart id="%s"]</code>', $item['id']
        );
    }

    function column_chart_type($item) {

        global $wpdb;

        $type = $wpdb->get_var(
            $wpdb->prepare("SELECT chart_type FROM {$wpdb->prefix}weblator_charts_chart_type WHERE id = (SELECT chart_type FROM {$wpdb->prefix}weblator_charts_charts WHERE id = %d)", $item["id"])
        );

        return sprintf(
            '%s', $type
        );

    }

    function column_created($item) {

        global $wpdb;

        $time = $wpdb->get_var(
            $wpdb->prepare("SELECT created_date FROM {$wpdb->prefix}weblator_charts_charts WHERE id = %d", $item["id"])
        );

        return sprintf(
            '<span data-livestamp="%s"></span>', date("c", strtotime($time))
        );

    }

    function prepare_items() {

        global $wpdb;

        $query = "SELECT id, chart_name AS name FROM " . WEBLATOR_CHARTS_PREFIX . "charts WHERE deleted_date IS NULL";

        if (isset($_POST["s"]))
            $query .= " HAVING name LIKE '%" . $wpdb->_real_escape($_POST["s"]). "%'";


        $orderby = !empty($_GET["orderby"]) ? $wpdb->_real_escape($_GET["orderby"]) : 'ASC';
        $order = !empty($_GET["order"]) ? $wpdb->_real_escape($_GET["order"]) : '';

        if(!empty($orderby) & !empty($order))
            $query.=' ORDER BY '.$orderby.' '.$order;
        else
            $query.=' ORDER BY ' . WEBLATOR_CHARTS_PREFIX . 'charts.created_date DESC';

        $totalitems = $wpdb->query($query); //return the total number of affected rows

        $perpage = 20;
        $paged = !empty($_GET["paged"]) ? $wpdb->_real_escape( $_GET["paged"]) : '';
        if(empty($paged) || !is_numeric($paged) || $paged<=0 ){ $paged=1; }
        $totalpages = ceil($totalitems/$perpage);
        if(!empty($paged) && !empty($perpage)){
            $offset=($paged-1)*$perpage;
            $query.=' LIMIT '.(int)$offset.','.(int)$perpage;
        }

        $this->set_pagination_args( array(
            "total_items" => $totalitems,
            "total_pages" => $totalpages,
            "per_page" => $perpage,
        ) );

        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = array($columns, $hidden, $sortable);

        $this->items = $wpdb->get_results($query, ARRAY_A);



        if (isset($_POST["chart_check"]))
            $this->process_bulk_action();
    }

}
