<?php

class Weblator_Charts_Ajax {

    public static function loadStyleSettings()
    {

        global $wpdb;

        $chartTypeID = $_POST["chartTypeID"];

        if (isset($_POST["chartID"]) && $_POST["chartID"] != "")
        {

            $query = $wpdb->get_results(

                $wpdb->prepare(

                    "SELECT
                        " . WEBLATOR_CHARTS_PREFIX . "style_options.id,
                        " . WEBLATOR_CHARTS_PREFIX . "style_options.style_option,
                        " . WEBLATOR_CHARTS_PREFIX . "style_options.style_order,
                        CASE WHEN " . WEBLATOR_CHARTS_PREFIX . "style_options.style_bool = 1 THEN 'true' ELSE 'false' END AS style_bool,
                        CASE WHEN " . WEBLATOR_CHARTS_PREFIX . "style_options.style_colorpicker = 1 THEN 'true' ELSE 'false' END as style_colorpicker,
                        CASE WHEN " . WEBLATOR_CHARTS_PREFIX . "style_options.style_dropdown = 1 THEN 'true' ELSE 'false' END as style_dropdown,
                        CASE WHEN " . WEBLATOR_CHARTS_PREFIX . "style_options.style_dropdown = 1 THEN (SELECT group_concat(dropdown_nicename, '||', dropdown_value separator ':: ') FROM " . WEBLATOR_CHARTS_PREFIX . "style_dropdowns WHERE style_id = " . WEBLATOR_CHARTS_PREFIX . "style_options.id LIMIT 1) ELSE NULL END as dropdown_options,
                        " . WEBLATOR_CHARTS_PREFIX . "style_options.style_label,
                        " . WEBLATOR_CHARTS_PREFIX . "style_options.style_description,
                        (SELECT " . WEBLATOR_CHARTS_PREFIX . "charts_style_value.style_value
                            FROM " . WEBLATOR_CHARTS_PREFIX . "charts_style_value
                            WHERE " . WEBLATOR_CHARTS_PREFIX . "charts_style_value.style_id = " . WEBLATOR_CHARTS_PREFIX . "style_options.id
                            AND " . WEBLATOR_CHARTS_PREFIX . "charts_style_value.chart_id = %d) AS style_default
                    FROM " . WEBLATOR_CHARTS_PREFIX . "style_chart_link, " . WEBLATOR_CHARTS_PREFIX . "style_options
                    WHERE " . WEBLATOR_CHARTS_PREFIX . "style_chart_link.chart_id = %d
                    AND " . WEBLATOR_CHARTS_PREFIX . "style_options.id = " . WEBLATOR_CHARTS_PREFIX . "style_chart_link.style_id
                    ",

                    $_POST["chartID"], $chartTypeID
                ), ARRAY_A

            );


        }
        else {

            $query = $wpdb->get_results(
                $wpdb->prepare(

                "SELECT
                        " . WEBLATOR_CHARTS_PREFIX . "style_options.id,
                    " . WEBLATOR_CHARTS_PREFIX . "style_options.style_option,
                    " . WEBLATOR_CHARTS_PREFIX . "style_options.style_order,
                CASE
                    WHEN " . WEBLATOR_CHARTS_PREFIX . "style_options.style_bool = 1 THEN 'true'
                    ELSE 'false' END AS style_bool,
                    " . WEBLATOR_CHARTS_PREFIX . "style_options.style_default,
                    " . WEBLATOR_CHARTS_PREFIX . "style_options.style_label,
                    " . WEBLATOR_CHARTS_PREFIX . "style_options.style_description,
                CASE
                    WHEN " . WEBLATOR_CHARTS_PREFIX . "style_options.style_colorpicker = 1 THEN 'true'
                    ELSE 'false' END AS style_colorpicker,
                CASE WHEN " . WEBLATOR_CHARTS_PREFIX . "style_options.style_dropdown = 1 THEN 'true' ELSE 'false' END as style_dropdown,
                CASE WHEN " . WEBLATOR_CHARTS_PREFIX . "style_options.style_dropdown = 1 THEN (SELECT group_concat(dropdown_nicename, '||', dropdown_value separator ':: ') FROM " . WEBLATOR_CHARTS_PREFIX . "style_dropdowns WHERE style_id = " . WEBLATOR_CHARTS_PREFIX . "style_options.id LIMIT 1) ELSE NULL END as dropdown_options
                FROM
                    " . WEBLATOR_CHARTS_PREFIX . "style_chart_link,
                    " . WEBLATOR_CHARTS_PREFIX . "style_options
                WHERE
                    " . WEBLATOR_CHARTS_PREFIX . "style_chart_link.chart_id = %d
                AND
                    " . WEBLATOR_CHARTS_PREFIX . "style_options.id = " . WEBLATOR_CHARTS_PREFIX . "style_chart_link.style_id
                ", $_POST["chartTypeID"]), ARRAY_A
            );



        }

        for ($i = 0; $i < count($query); $i++){

            $query[$i]["style_bool"] = ($query[$i]["style_bool"] == "true" ? true : false);
            $query[$i]["style_colorpicker"] = ($query[$i]["style_colorpicker"] == "true" ? true : false);
            $query[$i]["style_dropdown"] = ($query[$i]["style_dropdown"] == "true" ? true : false);

            if ($query[$i]["style_bool"] && $query[$i]["style_default"] == "0")
                $query[$i]["style_default"] = false;
            else if ($query[$i]["style_bool"] && $query[$i]["style_default"] == "1")
                $query[$i]["style_default"] = true;

            if ($query[$i]["dropdown_options"] != NULL){

                $dropdownOptions = array();

                $options = explode("::", $query[$i]["dropdown_options"]);

                if ( $query[$i]["style_option"] == "tooltip_font_family" )
                    sort($options, SORT_STRING);

                foreach($options as $option){

                    $kv = explode("||", $option);
                    $dropdownOptions[] = array("key" => $kv[0], "value" => $kv[1], "selected" => ($kv[1] == $query[$i]["style_default"] ? true : false));
                }

                $query[$i]["dropdown_options"] = $dropdownOptions;

            }
        }



        echo json_encode($query);
        die();
    }

    public static function updateChart()
    {
        if(isset($_REQUEST['_wpnonce']) && wp_verify_nonce($_REQUEST['_wpnonce'], "weblator_chart_edit_".intval($_POST["chart_id"])))
        {

            global $wpdb;

            $wpdb->query(
                $wpdb->prepare("

                    UPDATE " . WEBLATOR_CHARTS_PREFIX . "charts SET
                        chart_name = '%s',
                        chart_type = %d,
                        chart_is_live = %d,
                        chart_max_width = %d,
                        chart_legend = %d,
                        chart_legend_position = '%s',
                        chart_legend_font_size = '%s',
                        chart_legend_font_style = '%s',
                        chart_legend_font_colour = '%s',
                        chart_percentage_values = '%d',
                        main_data_set_title = '%s',
                        scale_label_append = '%s',
                        scale_label_prepend = '%s'
                    WHERE id = %d

                ", sanitize_text_field($_POST["name"]), sanitize_text_field($_POST["chart"]), sanitize_text_field($_POST["is_live"]), sanitize_text_field($_POST["maxWidth"]), sanitize_text_field($_POST["legend"]), sanitize_text_field($_POST["legend_position"]), sanitize_text_field($_POST["legend_font_size"]), sanitize_text_field($_POST["legend_font_style"]), sanitize_text_field($_POST["legend_font_colour"]), sanitize_key($_POST["chart_percentage_values"]), sanitize_text_field($_POST["main_data_set_title"]), sanitize_text_field($_POST["scale_label_append"]), sanitize_text_field($_POST["scale_label_prepend"]), sanitize_text_field($_POST["chart_id"]) )
            );

            $wpdb->query(
                $wpdb->prepare("

                    UPDATE " . WEBLATOR_CHARTS_PREFIX . "chart_options SET `option_deleted_date` = NOW() WHERE `chart_id` = %d AND `option_deleted_date` IS NULL

                    ", $_POST["chart_id"]
                )
            );

            $wpdb->query(
                $wpdb->prepare("UPDATE " .WEBLATOR_CHARTS_PREFIX . "data_sets SET deleted_date = NOW() WHERE chart_id = %d", $_POST["chart_id"])
            );

            foreach($_POST["options"] as $k =>$options)
            {

                $data_id = 0;


                if ($k > 0){

                    $styles = $_POST["over_style"][$k-1];

                    $wpdb->query(
                        $wpdb->prepare("
                                INSERT INTO " .WEBLATOR_CHARTS_PREFIX . "data_sets (chart_id, fill_color, stroke_color, point_color, point_stroke_color, title) VALUES ('%d', '%s','%s','%s','%s', '%s')
                            ",$_POST["chart_id"], sanitize_text_field($styles[0]), sanitize_text_field($styles[1]), sanitize_text_field($styles[2]), sanitize_text_field($styles[3]), sanitize_text_field($styles[4]))
                    );

                    $data_id = $wpdb->insert_id;

                }

                foreach($options as $key=> $option){


                    $wpdb->query(
                        $wpdb->prepare(

                            "INSERT INTO " . WEBLATOR_CHARTS_PREFIX . "chart_options (chart_id, data_set_id, option_name, option_value, option_order, option_colour) VALUES('%d', '%d', '%s','%s','%d','%s')",

                            $_POST["chart_id"], $data_id, sanitize_text_field($option[1]), sanitize_text_field($option[4]), sanitize_text_field($option[0]), sanitize_text_field($option[3])
                        )
                    );

                }


            }

            foreach($_POST["styles"] as $style)
            {

                $value = sanitize_text_field($style["value"]);
                $style_id = $style["id"];

                $id = $wpdb->get_var(
                    $wpdb->prepare(

                        "SELECT id FROM " . WEBLATOR_CHARTS_PREFIX . "charts_style_value WHERE chart_id = %d AND style_id = %d",

                        $_POST["chart_id"], $style_id
                    )
                );

                if ($id)
                {

                    $wpdb->query(

                        $wpdb->prepare("

                            UPDATE " . WEBLATOR_CHARTS_PREFIX . "charts_style_value SET style_value = %s WHERE chart_id = %d AND style_id = %d",

                            sanitize_text_field($value), $_POST["chart_id"], $style_id

                        )
                    );

                }
                else
                {

                    $wpdb->query(

                        $wpdb->prepare("

                            INSERT INTO " . WEBLATOR_CHARTS_PREFIX . "charts_style_value (chart_id, style_id, style_value) VALUE('%d','%d','%s')",

                            $_POST["chart_id"], $style_id, sanitize_text_field($value)

                        )

                    );
                }



            }

            echo 1;
        }
        die();

    }

    public static function saveChart()
    {
        if(isset($_REQUEST['_wpnonce']) && wp_verify_nonce($_REQUEST['_wpnonce'], "weblator_chart_add"))
        {

            global $wpdb;

            $q = $wpdb->query(
            $wpdb->prepare(
                   "INSERT INTO " . WEBLATOR_CHARTS_PREFIX . "charts
                 (chart_name,
                 chart_type,
                 chart_is_live,
                 chart_max_width,
                 chart_legend,
                 chart_legend_position,
                 chart_legend_font_size,
                 chart_legend_font_style,
                 chart_legend_font_colour,
                 chart_percentage_values,
                 main_data_set_title,
                 scale_label_append,
                 scale_label_prepend,
                 created_date)

                 VALUES('%s','%d','%d','%d','%s','%s','%s','%s','%s', '%s', '%s', '%s', '%s', NOW())",

                   sanitize_text_field($_POST["name"]),
                   sanitize_text_field($_POST["chart"]),
                   sanitize_text_field($_POST["is_live"]),
                   sanitize_text_field($_POST["maxWidth"]),
                   sanitize_text_field($_POST["legend"]),
                   sanitize_text_field($_POST["legend_position"]),
                   sanitize_text_field($_POST["legend_font_size"]),
                   sanitize_text_field($_POST["legend_font_style"]),
                   sanitize_text_field($_POST["legend_font_colour"]),
                   sanitize_key($_POST["chart_percentage_values"]),
                   sanitize_text_field($_POST["main_data_set_title"]),
                   sanitize_text_field($_POST["scale_label_append"]),
                   sanitize_text_field($_POST["scale_label_prepend"])
               )
           );


            if (!$q){
                echo 0;
                die();
            }

            $last_id = $wpdb->insert_id;

            foreach($_POST["options"] as $k =>$options){

                $data_id = 0;

                if ($k > 0){

                    $styles = $_POST["over_style"][$k-1];

                    $wpdb->query(
                        $wpdb->prepare("
                                INSERT INTO " .WEBLATOR_CHARTS_PREFIX . "data_sets (chart_id, fill_color, stroke_color, point_color, point_stroke_color, title) VALUES ('%d', '%s','%s','%s','%s', '%s')
                            ",$last_id, sanitize_text_field($styles[0]), sanitize_text_field($styles[1]), sanitize_text_field($styles[2]), sanitize_text_field($styles[3]), sanitize_text_field($styles[4]))
                    );

                    $data_id = $wpdb->insert_id;

                }

                foreach($options as $key=> $option){


                    $wpdb->query(
                        $wpdb->prepare(

                            "INSERT INTO " . WEBLATOR_CHARTS_PREFIX . "chart_options (chart_id, data_set_id, option_name, option_value, option_order, option_colour) VALUES('%d', '%d', '%s','%s','%d','%s')",

                            $last_id, $data_id, sanitize_text_field($option[1]), sanitize_text_field($option[4]), sanitize_text_field($option[0]), sanitize_text_field($option[3])
                        )
                    );

                }


            }

            $results = $wpdb->get_results("SELECT * FROM " . WEBLATOR_CHARTS_PREFIX . "style_options");

            foreach($results as $result){

                $wpdb->query( $wpdb->prepare("INSERT INTO " . WEBLATOR_CHARTS_PREFIX . "charts_style_value (chart_id, style_id, style_value) VALUES (%d, %d, %s)", $last_id, $result->id, sanitize_text_field($result->style_default)));

            }

            foreach($_POST["styles"] as $style){

                $value = sanitize_text_field($style["value"]);
                $style_id = $style["id"];

                $wpdb->query( $wpdb->prepare("
                    UPDATE " .WEBLATOR_CHARTS_PREFIX . "charts_style_value SET style_value = %s WHERE chart_id = %d AND style_id = %d
                ", sanitize_text_field($value), $last_id, $style_id) );


            }


            echo $last_id;
        }
        die();
    }

    public static function deleteChart($id = 0)
    {
        global $wpdb;

        if ($id == 0)
            $id = $_POST["id"];

        if(isset($_REQUEST['_wpnonce']) && wp_verify_nonce($_REQUEST['_wpnonce'], "weblator_chart_delete_".intval($id)))
        {

            $wpdb->query(
                $wpdb->prepare(
                "UPDATE " . WEBLATOR_CHARTS_PREFIX . "charts SET deleted_date = NOW() WHERE id = %d", intval($id)
                )
            );
        }

    }

    public static function importCSV() {


        $csv_mimetypes = array(
            'text/csv',
            'text/plain',
            'application/csv',
            'text/comma-separated-values',
            'application/excel',
            'application/vnd.ms-excel',
            'application/vnd.msexcel',
            'text/anytext',
            'application/octet-stream',
            'application/txt',
            'application/vnd.google-apps.spreadsheet'
        );

        foreach ( $_FILES as $file ) {

            if (in_array($file['type'], $csv_mimetypes)) {

                require_once( plugin_dir_path( __FILE__ ) . "/parseCSV.php" );
                $csv = new parseCSV();

                if ( $_POST["first_row"] == "false" )
                    $csv->heading = false;

                $csv->parse($file['tmp_name']);
                echo json_encode($csv->data);

            }else {

                echo json_encode(array("error" => "File Must be a CSV"));

            }

            die();

        }



    }

    public static function duplicate()
    {
        global $wpdb;

        if(isset($_REQUEST['_wpnonce']) && wp_verify_nonce($_REQUEST['_wpnonce'], "weblator_chart_duplicate_".intval($_POST["id"])))
        {
            // Create a tempory table and insert the chart that will be duplicated into it
            $wpdb->query($wpdb->prepare("CREATE TEMPORARY TABLE tmptable_1 SELECT * FROM {$wpdb->prefix}weblator_charts_charts WHERE id = %d", $_POST["id"]));

            //Update the id of the temp table to null
            $wpdb->query("UPDATE tmptable_1 SET id = NULL");

            //Copy the data from the temp table to the charts table
            $wpdb->query("INSERT INTO {$wpdb->prefix}weblator_charts_charts SELECT * FROM tmptable_1");

            //Get the last insert id
            $last = $wpdb->insert_id;

            //Drop the tempory table
            $wpdb->query("DROP TEMPORARY TABLE IF EXISTS tmptable_1");

            //Update the duplicated charts table to include a duplicate tag on the title and change the created date
            $wpdb->query("UPDATE {$wpdb->prefix}weblator_charts_charts SET chart_name = CONCAT(chart_name, ' - Duplicate'), created_date = NOW() WHERE id = {$last}");

            //Get all the dataset data for the chart that will be duplicated
            $dataSets = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}weblator_charts_data_sets WHERE deleted_date IS NULL AND chart_id = %d", $_POST["id"]), ARRAY_A);
            //   printf("SELECT * FROM {$wpdb->prefix}weblator_charts_data_sets WHERE deleted_date IS NULL AND chart_id = %d", $_POST["id"]);
            foreach($dataSets as $set) {
            // echo "Here";
            //Insert new data set row
            $wpdb->query(
                $wpdb->prepare("INSERT INTO {$wpdb->prefix}weblator_charts_data_sets (chart_id, fill_color, stroke_color, point_color, point_stroke_color, title) VALUES(%d, '%s', '%s', '%s', '%s', '%s')",
                $last, $set["fill_color"], $set["stroke_color"], $set["point_color"], $set["point_stroke_color"], $set["title"])
            );

            //Record the last insert id
            $ds_last = $wpdb->insert_id;

            //Get the chart options
            $ds_options = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}weblator_charts_chart_options WHERE chart_id = %d AND data_set_id = %d AND option_deleted_date IS NULL",$_POST["id"], $set["id"]), ARRAY_A);

            //Loop through and duplicate the data set options
            foreach ($ds_options as $option) {
              $wpdb->query(
                $wpdb->prepare("INSERT INTO {$wpdb->prefix}weblator_charts_chart_options (chart_id, data_set_id, option_name, option_value, option_order, option_colour)
                  VALUES(%d, %d, '%s', '%s', %d, %s)", $last, $ds_last, $option["option_name"], $option["option_value"], $option["option_order"], $option["option_colour"])
              );
            }

            }

            //Duplicate the default dataset
            $default_ds = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}weblator_charts_chart_options WHERE data_set_id = 0 AND chart_id = %d AND option_deleted_date IS NULL", $_POST["id"]), ARRAY_A);

            foreach($default_ds as $set)
            {
                $wpdb->query(
                  $wpdb->prepare("INSERT INTO {$wpdb->prefix}weblator_charts_chart_options (chart_id, data_set_id, option_name, option_value, option_order, option_colour)
                  VALUES(%d, 0, '%s', '%s', %d, %s)", $last, $set["option_name"], $set["option_value"], $set["option_order"], $set["option_colour"])
                );
            }

            //Get the chart styles
            $styles = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}weblator_charts_charts_style_value WHERE chart_id = %d", $_POST["id"]), ARRAY_A);

            //Loop through the styles and insert new record with the new chart id
            foreach($styles as $style)
            {
                $wpdb->query(
                  $wpdb->prepare("INSERT INTO {$wpdb->prefix}weblator_charts_charts_style_value (chart_id, style_id, style_value) VALUES (%d, %d, '%s')", $last, $style['style_id'], $style['style_value'])
                );
            }
        }

        die();
    }
}
