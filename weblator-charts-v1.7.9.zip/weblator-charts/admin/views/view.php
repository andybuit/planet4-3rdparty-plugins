<div class="wrap new-chart">
    <h2><?php echo (isset($poll->chart_name) ? "Update Chart" : "New Chart"); ?></h2>

    <?php if (isset($poll->id)): ?>
        <div class="shortcodes">
            Shortcode example: <code>[chart id="<?php echo intval($poll->id); ?>"]</code> or <code>[weblator_chart id="<?php echo intval($poll->id); ?>"]</code><br>
            Template files usage example: <code><?php echo htmlentities("<?php echo do_shortcode(\"[chart id="); echo intval($poll->id);  echo htmlentities("]\"); ?>"); ?></code> or <code><?php echo htmlentities("<?php echo do_shortcode(\"[weblator_chart id="); echo intval($poll->id);  echo htmlentities("]\"); ?>"); ?></code><br>
            Display a random chart: <code>[chart random]</code> or <code>[weblator_chart random]</code><br>
        </div>
    <?php endif; ?>

    <div id="message" class="updated below-h2" style="display: none;"><p>Chart updated.</p></div>
    <div id="poststuff">

        <?php
        if($_GET["action"] == "edit" && $_GET["edit_chart"] > 0)
        {
            wp_nonce_field("weblator_chart_edit_".intval($_GET["edit_chart"]));
        }
        elseif($_GET["action"] == "add")
        {
            wp_nonce_field("weblator_chart_add");
        }
        ?>

        <div id="post-body" class="metabox-holder columns-2">
            <div id="post-body-content" class="edit-form-section">
                <div id="namediv" class="stuffbox">
                    <h3><label for="name">Chart Settings</label></h3>

                    <div class="inside">
                        <table class="form-table editcomment poll-settings">
                            <tbody>
                            <tr valign="top">
                                <td class="first">Title:</td>
                                <td><input type="text" name="weblator_chart_name" size="30" id="name" value="<?php echo (isset($poll->chart_name) ? $this->prepare_data_for_output($poll->chart_name) : ""); ?>"></td>
                            </tr>

                            <tr valign="top" class="option_hide">
                                <td class="first">Chart Type:</td>
                                <td>
                                    <select name="weblator_charts_chart_type" id="weblator_charts_chart_type">
                                        <?php $charts = $wpdb->get_results("SELECT * FROM " . WEBLATOR_CHARTS_PREFIX . "chart_type ORDER by `order` ASC "); ?>

                                        <?php foreach($charts as $chart): ?>
                                            <?php if (isset($poll->chart_type)): ?>
                                                <option value="<?php echo $chart->id; ?>" <?php echo ($poll->chart_type == $chart->id) ? "selected='selected'" : ""; ?>><?php echo $chart->chart_type; ?></option>
                                            <?php else: ?>
                                            <option value="<?php echo $chart->id; ?>"><?php echo $chart->chart_type; ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>

                            <tr valign="top" class="option_hide">
                                <td class="first">Chart Max Width:</td>
                                <td class="">
                                    <input type="text" name="chart_max_width" size="30" id="chart_max_width" value="<?php echo (isset($poll->chart_max_width) ? $this->prepare_data_for_output($poll->chart_max_width) : "500"); ?>">
                                    <p class="description">This sets the maximum width of the chart in pixels. The chart will not get any bigger than the value set here. However, the chart will scale down responsively.
                                        If this field is left blank (or set to 0) the chart will be 100% width and will be fully responsive</p>
                                </td>
                            </tr>

                            <tr valign="top" class="option_hide scale_label">
                                <td class="first">Value Prepend:</td>
                                <td class="">
                                    <input type="text" name="scale_label_prepend" size="30" id="scale_label_prepend" value="<?php echo (isset($poll->scale_label_prepend) ? $this->prepare_data_for_output($poll->scale_label_prepend) : ""); ?>">
                                    <p class="description">This will prepend a value onto the values on the Y Axis and on the tooltips</p>
                                </td>
                            </tr>

                            <tr valign="top" class="option_hide scale_label">
                                <td class="first">Value Append:</td>
                                <td class="">
                                    <input type="text" name="scale_label_append" size="30" id="scale_label_append" value="<?php echo (isset($poll->scale_label_append) ? $this->prepare_data_for_output($poll->scale_label_append) : ""); ?>">
                                    <p class="description">This will append a value onto the values on the Y Axis and on the tooltips</p>
                                </td>
                            </tr>



                            <tr valign="top" class="option_hide legend-option">
                                <td class="first">Show Legend:</td>
                                <td class="">
                                    <?php if (isset($poll->chart_legend)): ?>
                                        <input type="checkbox" name="chart_legend" id="chart_legend" value="<?php echo ($poll->chart_legend ? 1 : 0); ?>" <?php echo ($poll->chart_legend ? "checked='checked'" : ""); ?> >
                                    <?php else: ?>
                                        <input type="checkbox" name="chart_legend" id="chart_legend" value="0">
                                    <?php endif; ?>


                                </td>
                            </tr>

                            <tr valign="top" class="option_hide legend-option-secondary">
                                <td class="first">Legend Position:</td>
                                <td>
                                    <select name="weblator_charts_legend_position" id="weblator_charts_legend_position">
                                        <option value="tl" <?php echo (isset($poll->chart_legend_position) && $poll->chart_legend_position == "tl") ? "selected='selected'" : ""; ?>>Top Left</option>
                                        <option value="tm" <?php echo (isset($poll->chart_legend_position) && $poll->chart_legend_position == "tm") ? "selected='selected'" : ""; ?>>Top Middle Inline</option>
                                        <option value="tr" <?php echo (isset($poll->chart_legend_position) && $poll->chart_legend_position == "tr") ? "selected='selected'" : ""; ?>>Top Right</option>
                                        <option value="bl" <?php echo (isset($poll->chart_legend_position) && $poll->chart_legend_position == "bl") ? "selected='selected'" : ""; ?>>Bottom Left</option>
                                        <option value="bm" <?php echo (isset($poll->chart_legend_position) && $poll->chart_legend_position == "bm") ? "selected='selected'" : ""; ?>>Bottom Middle Inline</option>
                                        <option value="br" <?php echo (isset($poll->chart_legend_position) && $poll->chart_legend_position == "br") ? "selected='selected'" : ""; ?>>Bottom Right</option>
                                    </select>
                                </td>
                            </tr>

                            <tr valign="top" class="option_hide legend-option-secondary">
                                <td class="first">Legend Font Size:</td>
                                <td>
                                    <select name="weblator_charts_legend_font_size" id="weblator_charts_legend_font_size">
                                        <?php for ($i=8; $i < 29; $i++): ?>
                                            <?php if (isset($poll->chart_legend_font_size) && $poll->chart_legend_font_size) : ?>
                                                <option value="<?php echo $i;?>" <?php echo (isset($poll->chart_legend_font_size) && $poll->chart_legend_font_size == $i) ? "selected='selected'" : ""; ?>><?php echo $i; ?>px</option>
                                            <?php else: ?>
                                                <option value="<?php echo $i;?>" <?php echo ($i == 12) ? "selected='selected'" : ""; ?>><?php echo $i; ?>px</option>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </select>
                                </td>
                            </tr>


                            <tr valign="top" class="option_hide legend-option-secondary">
                                <td class="first">Legend Font Style:</td>
                                <td>
                                    <select name="weblator_charts_chart_legend_font_style" id="weblator_charts_chart_legend_font_style">
                                        <option value="normal" <?php echo (isset($poll->chart_legend_font_style) && $poll->chart_legend_font_style == "normal") ? "selected='selected'" : ""; ?>>normal</option>
                                        <option value="italic" <?php echo (isset($poll->chart_legend_font_style) && $poll->chart_legend_font_style == "italic") ? "selected='selected'" : ""; ?>>italic</option>
                                        <option value="oblique" <?php echo (isset($poll->chart_legend_font_style) && $poll->chart_legend_font_style == "oblique") ? "selected='selected'" : ""; ?>>oblique</option>
                                    </select>
                                </td>
                            </tr>

                            <tr valign="top" class="option_hide legend-option-secondary">
                                <td class="first">Legend Font Colour:</td>

                                <td class="fill colour-option">
                                    <div style="position: relative;">
                                        <input type="text"name="chart_legend_font_colour" class="poll-colour" size="30" value="<?php echo (isset($poll->chart_legend_font_colour)) ? $this->prepare_data_for_output($poll->chart_legend_font_colour) : "rgb(102, 102, 102)"; ?>">
                                    </div>
                                </td>

                            </tr>

                            <tr valign="top" class="option_hide percentage-options">
                                <td class="first">Percentage Values:</td>

                                <td class=" colour-option">
                                    <div style="position: relative;">
                                        <?php if (isset($poll->chart_percentage_values)): ?>
                                            <input type="checkbox" name="chart_percentage_values" id="chart_percentage_values" value="<?php echo ($poll->chart_percentage_values ? 1 : 0); ?>" <?php echo ($poll->chart_percentage_values ? "checked='checked'" : ""); ?> >
                                        <?php else: ?>
                                            <input type="checkbox" name="chart_percentage_values" id="chart_percentage_values" value="0">
                                        <?php endif; ?>
                                        <p class="description">This option sets the width of the bootstrap progress bars to represent 100%. Your option value will need to be an integer between 0 and 100. A percentage symbol will be automatically appended to your value</p>

                                    </div>
                                </td>

                            </tr>


                            </tbody>
                        </table>
                        <br>
                    </div>
                </div>

                <div id="namediv" class="stuffbox style-settings">
                    <h3><label for="name">Style Settings</label></h3>

                    <div class="inside">
                        <table class="form-table editcomment chart-settings">
                            <tbody>

                            </tbody>
                        </table>
                        <br>
                    </div>
                </div>

                <div id="namediv" class="stuffbox csv-import-container">
                    <h3><label for="name">Import Data</label></h3>

                    <div class="inside">

                        <p class="description">Data sets can be easily imported from a CSV spreadsheet file to populate the chart 'Option Names' and 'Option Values'. The CSV file must be formatted in a specific way, so please download and use our CSV Template via the link below. <br><br> Please note: Only 'Bar Charts', 'Line Chars' and 'Radar charts' are compatible with multiple data sets.</p>

                        <div class="">
                            <p><a href="#" class="download-csv">Download CSV Template</a></p>
                        </div>

                        <div class="file-select-first-row" id="firstRow">
                            <input type="checkbox" id="first-row" checked value="1">
                            <label for="first-row">Use the first row from CSV spreadsheet as the 'Data Set Titles'</label>
                        </div>

                        <div class="file-upload">
                            <div class="file-select">
                                <form action="#" method="post" enctype="multipart/form-data" id="csv-upload">
                                <div class="file-select-button" id="fileName">Choose File</div>
                                <div class="file-select-name" id="noFile">No file chosen...</div>

                                <input type="file" name="chooseFile" id="chooseFile">
                                <div class="import-progress-bar">
                                    <div class="bg-color"></div>
                                </div>
                            </form>

                            </div>

                        </div>

                    </div>
                </div>

                <div id="namediv" class="stuffbox response-settings main-data-set">
                    <h3><label for="name">Main Data Set:
                    </label> <input type="text" value="<?php echo (isset($poll->main_data_set_title)) ? $this->prepare_data_for_output($poll->main_data_set_title) : ""; ?>" placeholder="Main Data Set Title" class="data-set-title main_data_set_title" style="max-width:200px; float:right;"/><button class="button import-button">Import Data From CSV</button></h3>

                    <div class="inside">

                        <table class="form-table editcomment chart-options">
                            <tbody>

                            <?php if (isset($options["main"])): ?>

                                <?php foreach($options["main"] as $key => $option): ?>
                                    <tr valign="top" data-order="<?php echo $key; ?>" data-sort-id="<?php echo rand(11111, 99999); ?>" >
                                        <td class="first">
                                            Option:
                                        </td>
                                        <td>
                                            <input type="text" name="chart_option" class="poll-option" size="30" placeholder="Option Name" value="<?php echo $this->prepare_data_for_output($option->option_name); ?>">
                                        </td>
                                        <td>
                                            <input type="text" name="chart_value" size="30" placeholder="Option Value" value="<?php echo $this->prepare_data_for_output($option->option_value); ?>"/>
                                        </td>
                                        <td class="fill colour-option">
                                            <div style="position:relative">
                                                <input type="text"name="chart_colour" class="poll-colour" size="30" value="<?php echo $this->prepare_data_for_output($option->option_colour); ?>">
                                            </div>
                                        </td>
                                        <td class="remove-option">
                                            <button class="button poll-option-remove"><i class="icon-minus-squared"></i> Remove Option</button>
                                        </td>
                                        <td class="drag">
                                            <i class="fa fa-bars"></i>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>

                            <?php else: ?>

                            <tr valign="top" data-order="1" data-sort-id="<?php echo rand(11111, 99999); ?>">
                                <td class="first">
                                    Option:
                                </td>
                                <td>
                                    <input type="text" name="chart_option" class="poll-option" size="30" placeholder="Option Name">
                                </td>
                                <td>
                                    <input type="text" name="chart_value" size="30" placeholder="Option Value"/>
                                </td>
                                <td class="fill colour-option">
                                    <div style="position:relative">
                                        <input type="text"name="chart_colour" class="poll-colour" size="30" value="rgba(151,187,205,0.5)">
                                    </div>
                                </td>
                                <td class="remove-option">
                                    <button class="button poll-option-remove"><i class="fa fa-minus-square"></i> Remove Option</button>
                                </td>
                                <td class="drag">
                                    <i class="fa fa-bars"></i>
                                </td>
                            </tr>

                            <?php endif; ?>


                            </tbody>
                        </table>
                        <button class="button add-option"><i class="fa fa-plus-square"></i> Add Option</button>
                    </div>


                </div>

                <?php if (isset($options["additional"])): ?>
                    <?php foreach($options["additional"] as $additional): ?>
                        <div id="namediv" class="stuffbox response-settings hide-data-set">
                            <h3><label for="name">Data Set:</label> <div class="pull-right"><i class="fa fa-times close-data-set"></i></div> <input type="text" class="data-set-title" value="<?= $this->prepare_data_for_output($additional["style"][0]->title); ?>" placeholder="Data Set Title" style="max-width:200px; float:right; margin-right:5px;"/></h3>
                            <div class="inside">

                                <table class="form-table override-styles">
                                    <thead>
                                    <th>Fill Colour</th>
                                    <th>Stroke Colour</th>
                                    <th>Point Colour</th>
                                    <th>Point Stroke Colour</th>
                                    </thead>
                                    <tr>
                                        <td class="fill colour-option">
                                            <div style="position:relative">
                                                <input type="text" name="fill-color" class="poll-colour" size="30" value="<?= $this->prepare_data_for_output($additional["style"][0]->fill_color); ?>">
                                            </div>
                                        </td>
                                        <td class="fill colour-option">
                                            <div style="position:relative">
                                                <input type="text" name="stroke-color" class="poll-colour" size="30" value="<?= $this->prepare_data_for_output($additional["style"][0]->stroke_color); ?>">
                                            </div>
                                        </td>
                                        <td class="fill colour-option">
                                            <div style="position:relative">
                                                <input type="text" name="point-color" class="poll-colour" size="30" value="<?= $this->prepare_data_for_output($additional["style"][0]->point_color); ?>">
                                            </div>
                                        </td>
                                        <td class="fill colour-option">
                                            <div style="position:relative">
                                                <input type="text" name="point-stroke-color" class="poll-colour" size="30" value="<?= $this->prepare_data_for_output($additional["style"][0]->point_stroke_color); ?>">
                                            </div>
                                        </td>
                                    </tr>


                                </table>
                                <table class="form-table editcomment chart-options">
                                    <tbody>
                                    <?php foreach($additional["options"] as $option): ?>
                                        <tr valign="top" data-sort-id="{{sort}}">
                                            <td class="first">Option:</td>
                                            <td><input type="text" name="chart_option" class="poll-option" size="30" placeholder="Option Name" value="<?= $this->prepare_data_for_output($option->option_name); ?>" disabled></td>
                                            <td><input type="text" name="chart_value" size="30" placeholder="Option Value" value="<?= $this->prepare_data_for_output($option->option_value); ?>"/></td>
                                            <td class="remove-option"><button class="button poll-option-remove" disabled><i class="icon-minus-squared"></i> Remove Option</button></td>
                                            <td class="draged"><i class="fa fa-bars"></i></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>

                <button class="button add-data-set"><i class="fa fa-plus-square"></i> Add Data Set</button>


            </div><!-- /post-body-content -->

            <div id="postbox-container-1" class="postbox-container">
                <div id="submitdiv" class="stuffbox">
                    <h3><span class="hndle">Status</span></h3>
                    <div class="inside">
                        <div class="submitbox" id="submitcomment">
                            <div id="minor-publishing">


                                <div id="misc-publishing-actions">

                                    <div class="misc-pub-section misc-pub-comment-status" id="comment-status-radio">
                                        <?php if (isset($poll->chart_is_live)): ?>

                                            <label class="approved"><input type="radio" <?php echo ($poll->chart_is_live) ? "checked='checked'" : ""; ?> name="poll_status" value="1">Approved</label><br>
                                            <label class="spam"><input type="radio" <?php echo (!$poll->chart_is_live) ? "checked='checked'" : ""; ?> name="poll_status" value="0">Hidden</label>

                                        <?php else: ?>

                                            <label class="approved"><input type="radio" checked="checked" name="poll_status" value="1">Approved</label><br>
                                            <label class="spam"><input type="radio" name="poll_status" value="0">Hidden</label>

                                        <?php endif; ?>

                                    </div>


                                    <div class="misc-pub-section curtime misc-pub-curtime">
                                        <!--<span id="timestamp">Created on: <b>Jan 14, 2014 @ 9:33</b></span>-->
                                    </div>
                                </div> <!-- misc actions -->
                                <div class="clear"></div>
                            </div>

                            <div id="major-publishing-actions">

                                <div id="delete-action" class="delete-action">
                                    <span class="spinner"></span>
                                </div>

                                <div id="publishing-action">
                                    <input type="submit" name="save" id="save" class="button button-primary save-button <?php echo (isset($_GET["edit_chart"]) ? 'edit' : ''); ?>" data-chart-id="<?php echo (isset($poll->id) ? intval($poll->id) : ''); ?>" value="Update">
                                </div>
                                <div class="clear"></div>
                            </div>
                        </div>
                    </div>
                </div><!-- /submitdiv -->
            </div>

            <div id="postbox-container-2" class="postbox-container">
                <div id="normal-sortables" class="meta-box-sortables ui-sortable"></div></div>

        </div><!-- /post-body -->


    </div>
</div>

<div class="weblator-modal">

    <h2>Warning!</h2>
    <p>This import will override any data you have alreay added</p>

    <button class="continue">Continue Import</button>
    <button class="cancel">Cancel Import</button>

</div>
<div class="weblator-modal-bg"></div>

<script id="optionTmpl" type="text/template">
    <tr valign="top" data-order="">
        <td class="first">
            Option:
        </td>
        <td>
            <input type="text" name="chart_option" data-id="0" class="poll-option" size="30" placeholder="Option Name">
        </td>
        <td>
            <input type="text" name="chart_value" size="30" placeholder="Option Value"/>
        </td>
        <td class="fill colour-option">
            <div style="position: relative;">
                <input type="text"name="chart_colour" class="poll-colour" size="30" value="rgba(151,187,205,0.5)">
            </div>
        </td>
        <td class="remove-option-remove">
            <button class="button poll-option-remove"><i class="icon-minus-squared"></i> Remove Option</button>
        </td>
        <td class="drag">
            <i class="fa fa-bars"></i>
        </td>
    </tr>
</script>


<script id="optionRow" type="text/template">

    <tr valign="top" class="style-options">
        <td class="first">{{style_label}}</td>
        <td class="{{#style_colorpicker}}fill{{/style_colorpicker}}">
            <div style="position:relative">
                {{#style_bool}}
                <input type="checkbox" {{#style_default}}checked="checked"{{/style_default}} data-style-id="{{ id }}" name="{{style_option}}" size="30" id="{{style_option}}" {{#style_default}}value="1"{{/style_default}}{{^style_default}}value="0"{{/style_default}}>
                {{/style_bool}}
                {{^style_bool}}
                    {{#style_dropdown}}
                        <select name="{{style_option}}" id="{{style_option}}" data-style-id="{{ id }}">
                            {{#each dropdown_options}}
                                <option value="{{value}}" {{#if selected}} selected="selected" {{/if}}>{{key}}</option>
                            {{/each}}
                        </select>
                    {{/style_dropdown}}
                    {{^style_dropdown}}
                        <input type="text" data-style-id="{{ id }}" name="{{style_option}}" size="30" id="{{style_option}}" value="{{style_default}}">
                    {{/style_dropdown}}
                {{/style_bool}}
                <p class="description">{{style_description}}</p>
            </div>
        </td>
    </tr>

</script>

<script id="dataSet" type="text/x-handlebars-template">
    <div id="namediv" class="stuffbox response-settings hide-data-set">
        <h3><label for="name">Data Set:</label> <div class="pull-right"><i class="fa fa-times close-data-set"></i></div> <input type="text" class="data-set-title" value="" placeholder="Data Set Title" style="max-width:200px; float:right; margin-right:5px;"/></h3>
        <div class="inside">

            <table class="form-table override-styles">
                <thead>
                <th>Fill Colour</th>
                <th>Stroke Colour</th>
                <th>Point Colour</th>
                <th>Point Stroke Colour</th>
                </thead>
                <tr>
                    <td class="fill colour-option">
                        <div style="position:relative">
                            <input type="text" name="fill-color" class="poll-colour" size="30" value="rgba(220,220,220,0.5)">
                        </div>
                    </td>
                    <td class="fill colour-option">
                        <div style="position:relative">
                            <input type="text" name="stroke-color" class="poll-colour" size="30" value="rgba(220,220,220,1)">
                        </div>
                    </td>
                    <td class="fill colour-option">
                        <div style="position:relative">
                            <input type="text" name="point-color" class="poll-colour" size="30" value="rgba(220,220,220,1)">
                        </div>
                    </td>
                    <td class="fill colour-option">
                        <div style="position:relative">
                            <input type="text" name="point-stroke-color" class="poll-colour" size="30" value="rgba(255,255,255,1)">
                        </div>
                    </td>
                </tr>


            </table>
            <table class="form-table editcomment chart-options">
                <tbody>
                {{#each this}}
                <tr valign="top" data-sort-id="{{sort}}">
                    <td class="first">Option:</td>
                    <td><input type="text" name="chart_option" class="poll-option" size="30" placeholder="Option Name" value="{{option}}" disabled></td>
                    <td><input type="text" name="chart_value" size="30" placeholder="Option Value" value=""/></td>
                    <td class="remove-option"><button class="button poll-option-remove" disabled><i class="icon-minus-squared"></i> Remove Option</button></td>
                    <td class="draged"><i class="fa fa-bars"></i></td>
                </tr>
                {{/each}}
                </tbody>
            </table>

        </div>
    </div>
</script>
