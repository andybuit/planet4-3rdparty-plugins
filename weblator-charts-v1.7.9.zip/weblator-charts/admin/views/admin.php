<div class="wrap">

    <h2><?php echo esc_html( get_admin_page_title() ); ?> <?php echo sprintf('<a href="?page=%s&action=%s" class="add-new-h2">Add New</a>',$_REQUEST['page'],'add'); ?></h2>

    <?php $w_table = new Weblator_Charts_Tables; $w_table->prepare_items(); ?>

    <form method="post">
        <?php $w_table->search_box( 'search', 'search_id' ); $w_table->display(); ?>
    </form>

    <p class="message">If you have any questions regarding the Responsive Chart plugin please contact us via <strong><a href="mailto:plugin-charts@weblator.com">plugin-charts@weblator.com</a></strong></p>
    
 
</div>
