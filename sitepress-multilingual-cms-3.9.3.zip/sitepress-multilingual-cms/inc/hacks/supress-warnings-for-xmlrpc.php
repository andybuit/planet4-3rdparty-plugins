<?php  
/*  
    $_pingback_url_parts = parse_url(get_bloginfo('pingback_url'));
    if($_SERVER['REQUEST_URI'] == $_pingback_url_parts['path']){
        function __icl_void_error_handler($errno, $errstr, $errfile, $errline){
            throw new Exception ($errstr . ' [' . $errno . '] in '. $errfile . ':' . $errline);
        }        
        set_error_handler('__icl_void_error_handler',E_ALL);        
    }    
*/
?>
