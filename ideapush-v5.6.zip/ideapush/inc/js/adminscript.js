jQuery(document).ready(function ($) {
    
    
    
    //make cloning remember select values
    (function (original) {
        jQuery.fn.clone = function () {
          var result           = original.apply(this, arguments),
              my_textareas     = this.find('textarea').add(this.filter('textarea')),
              result_textareas = result.find('textarea').add(result.filter('textarea')),
              my_selects       = this.find('select').add(this.filter('select')),
              result_selects   = result.find('select').add(result.filter('select'));
      
          for (var i = 0, l = my_textareas.length; i < l; ++i) $(result_textareas[i]).val($(my_textareas[i]).val());
          for (var i = 0, l = my_selects.length;   i < l; ++i) {
            for (var j = 0, m = my_selects[i].options.length; j < m; ++j) {
              if (my_selects[i].options[j].selected === true) {
                result_selects[i].options[j].selected = true;
              }
            }
          }
          return result;
        };
      }) (jQuery.fn.clone);


    
    
    //selectively hide and show integrations depending on selection
     $('#idea_push_integration_service :selected').each(function () {
        var selectValue = $(this).val();
        $("#integrations .integration-setting").hide();
        $("."+selectValue).show();
    });
    
    
    $('#idea_push_integration_service').change(function () {
        var selectValue = $(this).val();
        $("#integrations .integration-setting").hide();
        $("."+selectValue).show();  
    });
    
    
    

    
    

    
    
    
    
    
    
    
    //make tabs tabs
    $( "#tabs" ).tabs();
    
    
    //make the accordion an accordion
    $("#accordion").accordion({
        collapsible: true,
        autoHeight: false,
        heightStyle: "content",
        active: false,
        speed: "fast"
    });
    
    
    //make links go to particular tabs
    $('.wrap').on("click",".open-tab", function(){
        var tab = $(this).attr('href');
        var index = $(tab).index()-1;        
        $('#tabs').tabs({active: index});
        $('#idea_push_tab_memory').val(tab);
    });
    
    
    // //add link to hidden link setting when a tab is clicked
    // $('.wrap').on("click", ".nav-tab", function () {
    //     var tab = $(this).attr('href');
    //     $('#idea_push_tab_memory').val(tab);
    // });
    
    
    
    //load previous tab when opening settings page
    if($('#ideapush_settings_form').length) {

        //get tab memory
        var tab = $('#ideapush_settings_form').attr('data-tab-memory');

        if(tab.length > 1) {

        var index = $(tab).index() - 1;
        $('#tabs').tabs({
            active: index
        });
        }
    }

    //save tab memory via ajax
    $('.wrap').on("click", ".nav-tab", function () {

        var tab = $(this).attr('href');

        var data = {
            'action': 'save_tab_memory',
            'tab': tab,
        };

        jQuery.post(ajaxurl, data, function (response) {
            console.log(response);
        });

    });


    
    
    //makes shortcode buttons push values over
    $('.ideapush_append_buttons').click(function() { 
        $(this).parent().next().children().val($(this).parent().next().children().val() + $(this).attr("value")); 
        $(this).parent().next().children().focus();      
    });
    
    
    //make subject and email dissapear on change
    $( '.wrap' ).on( 'change' ,'.enable-email-notification-checkbox input' ,function () {
        
        if(this.checked){            
            $(this).parent().parent().parent().next().next().show();
            $(this).parent().parent().parent().next().next().next().next().show();
        } else {            
            $(this).parent().parent().parent().next().next().hide();
            $(this).parent().parent().parent().next().next().next().next().hide();   
        } 
    });
    
    
    //make subject and email dissapear on initial load
    $( ".enable-email-notification-checkbox input" ).each(function( index ) {
        
        if(this.checked){            
            $(this).parent().parent().parent().next().next().show();
            $(this).parent().parent().parent().next().next().next().next().show();
        } else {            
            $(this).parent().parent().parent().next().next().hide();
            $(this).parent().parent().parent().next().next().next().next().hide();   
        } 
    });
    
    

    //hides and then shows on click help tooltips
    $(".hidden").hide();
    
    
    $('#ideapush_settings_form').on("click", ".ideapush_settings_row i", function (event) {
//        console.log('I was clicked');        
        event.preventDefault();
        $(this).next(".hidden").slideToggle();
    });

    //instantiates the Wordpress colour picker
    $('.my-color-field').wpColorPicker();

    
    

    //save settings using ajax    
    $('#ideapush_settings_form').submit(function(event) {
        
        event.preventDefault();
        //we need to check whether the boards tab is active and if it is we are going to do some magic first
        
        var activeTab = $('.ui-tabs-active a').text();
        
        if(activeTab == "Boards "){
            runBoardSaveRoutine();
        }

        if(activeTab == "Idea Form "){

            //first lets check if all the names are unique before we do anything
            //lets store an array which contains all the titles
            var allTitles = [];
            var duplicateFound = false;

            $('#form-settings-container > li').each(function () {
                //get title
                var title = $(this).find('.form-setting-name').val();
                // console.log(title);

                if($.inArray(title, allTitles) !== -1 ){
                    duplicateFound = true; 
                    return false;  
                } else {
                    allTitles.push(title);
                }

            }); 
            
            if(duplicateFound == true){

                //hide existing dialog
                alertify.alert($('#dialog-duplicate-form-setting-found').attr('data'));
                return false; 

            } else {
                runFormSaveRoutine();    
            }

 
        }
          
        
        $('<div class="notice notice-warning is-dismissible settings-loading-message"><p><i class="fa fa-spinner" aria-hidden="true"></i> Please wait while we save the settings...</p></div>').insertAfter('.ideapush-save-all-settings-button');

        tinyMCE.triggerSave();

        //delete plugin update transient
        deletepluginupdatetransient();

        $(this).ajaxSubmit({
            success: function(){

                $('.settings-loading-message').remove();

                $('<div class="notice notice-success is-dismissible settings-saved-message"><p>The settings have been saved.</p></div>').insertAfter('.ideapush-save-all-settings-button');

                setTimeout(function() {
                    $('.settings-saved-message').slideUp();
                }, 3000);
                
                //if the page is the integrations tab refresh the page so that we can see the connector finalisation button
                if(activeTab == "Integrations " || activeTab == "Idea Form "){
                    location.reload();
                }

                

            }
        });

        return false; 

        $('.settings-loading-message').remove();

    });

    
    
    //creates taxonomy item when add button is clicked
    
    $("#idea_push_create_board_button").click(function (event) {
        event.preventDefault();
        
        var boardName = $('#idea_push_create_board').val();
        
        if(boardName.length>0){
        
            var data = {
                'action': 'add_taxonomy_item',
                'boardName': boardName,
            };

            jQuery.post(ajaxurl, data, function (response) {
                
//                console.log(response);
                
                if(response == "TERM-EXISTS") {
                    
                    $('<div class="notice notice-error"><p>The board name already exists, please enter a unique value.</p></div>').insertAfter('#idea_push_create_board_button');

                    setTimeout(function() {
                        $('.notice-error').slideUp();
                    }, 3000);
                    
                } else if(response == "NOT-PRO"){
                    
                    $('<div class="notice notice-warning"><p>Please upgrade to <a href="https://northernbeacheswebsites.com.au/ideapush" target="_blank">Pro</a> to create multiple boards. If you have already purchased the pro version, please activate the plugin by entering your details in the <a class="open-tab" href="#ideapush_pro">Licence Activation</a> tab.</p></div>').insertAfter('#idea_push_create_board_button');
                    
                    
                    
                    
                    setTimeout(function() {
                        $('.notice-warning').slideUp();
                    }, 7000);
                    
                } else {
                
                    $('<div class="notice notice-success"><p>The board has been created. Please feel free to change the settings of the board below and then click the save settings button.</p></div>').insertAfter('#idea_push_create_board_button');

                    setTimeout(function() {
                        $('.notice-success').slideUp();
                    }, 7000);
                    
                    $('#idea_push_create_board').val('');
                    
                    //get todays date in YYYY-MM-DD
                    var currentDate = new Date().toISOString().slice(0,10);
                    var currentTime = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                    
                    //console.log(currentTime);
                    
                    
                    //lets push the line item into the ul
                    $( "#board-settings" ).append( createBoardSettingLineItem(response,boardName,100,'Yes','Yes','Yes','Yes','Yes','Yes','No','No','-1','-1','No','Everyone','-1','No','Most Votes',currentDate,currentTime,'Create as many ideas by [expiry] ([expiry-countdown]) and win.','The winner is [winner-name] with [win-number]','Global','Default','Board','No','No','No'));
                    
                    //hide and show challenge fields
                    hideAndShowChallengeFields();
                    
                    //run the presave routine
                    runBoardSaveRoutine();


                    //lets also save the settings
                    $('#ideapush_settings_form').ajaxSubmit({
                        success: function(){

                            $('.settings-loading-message').remove();

                            $('<div class="notice notice-success is-dismissible settings-saved-message"><p>The settings have been saved.</p></div>').insertAfter('.ideapush-save-all-settings-button');

                            setTimeout(function() {
                                $('.settings-saved-message').slideUp();
                            }, 3000);

                        }
                    });

                    return false; 
                    
                    
         
                    
                    
                    
                }
                
            });
 
        }
    });
 
    
    
    
    
    
    
    
    
    
    
    
    
    function createBoardSettingLineItem(termId,boardName,voteThreshold,holdIdeas,comments,tags,attachments,boardTitle,voteTarget,guestAccess,downVoting,maxVotes,maxIdeas,hideFromSearch,showTo,pagination,enableChallenge,challengeVictory,challengeDate,challengeTime,challengeMessage,challengeVictoryMessage,tagScope,fieldSettings,ideaScope,userIdeaEditDelete,hideLeaderboard,enableMultiIp){
        
        function selectElement(defaultValue,selectClass,values){
            
            var selectOption = '<td><select class="'+selectClass+'" style="width:150px;">';
            
            
            //cycle through provided options
            
            for(i=0; i<values.length; i++){

                if(defaultValue == values[i]){
                    selectOption += '<option value="'+values[i]+'" selected="selected">'+values[i]+'</option>';      
                } else {
                    selectOption += '<option value="'+values[i]+'">'+values[i]+'</option>';      
                }
                   
            }
            

            selectOption += '</select></td>';
            
            return selectOption  
        }
        
        
        var listItem = '<li data="'+termId+'">';
        
            listItem += '<table>';    
        
        
                //board name
                listItem += '<tr class="board-name">';
                listItem += '<td><label>Board Name</label></td>';
                listItem += '<td><input type="text" class="regular-text board-name-input" style="width: 150px;" value="'+boardName+'"></td>';
                listItem += '</tr>';

                //vote threshold
                listItem += '<tr class="vote-threshold">';
                listItem += '<td><label>Vote Threshold</label></td>';    
                listItem += '<td><input type="number" min="0" class="regular-text vote-threshold-input" style="width: 150px;" value="'+voteThreshold+'"></td>';
                listItem += '</tr>';    

                //hold ideas
                listItem += '<tr class="hold-ideas">';
                listItem += '<td><label>Hold Ideas</label></td>';
                listItem += selectElement(holdIdeas,'hold-ideas-select',['Yes','No']);    
                listItem += '</tr>';    

                //comments
                listItem += '<tr class="comments">';
                listItem += '<td><label>Show Comments</label></td>';
                listItem += selectElement(comments,'comments-select',['Yes','No']);
                listItem += '</tr>';

                //tags
                listItem += '<tr class="tags">';
                listItem += '<td><label>Show Tags</label></td>';
                listItem += selectElement(tags,'tags-select',['Yes','No']);
                listItem += '</tr>';

                //attachments
                listItem += '<tr class="attachments">';
                listItem += '<td><label>Show Attachments</label></td>';
                listItem += selectElement(attachments,'attachments-select',['Yes','No']);
                listItem += '</tr>';

                //show board title
                listItem += '<tr class="board-title">';
                listItem += '<td><label>Show Board Title</label></td>';
                listItem += selectElement(boardTitle,'board-title-select',['Yes','No']);
                listItem += '</tr>';
        
                //show vote target
                listItem += '<tr class="vote-target">';
                listItem += '<td><label>Show Vote Target</label></td>';
                listItem += selectElement(voteTarget,'vote-target-select',['Yes','No']);
                listItem += '</tr>';
        
                //enable guess access
                listItem += '<tr class="guest-access">';
                listItem += '<td><label>Guest Votes/Ideas</label></td>';
                listItem += selectElement(guestAccess,'guest-access-select',['Yes','No']);
                listItem += '</tr>';
        
                //enable down voting
                listItem += '<tr class="down-voting">';
                listItem += '<td><label>Enable Down Voting</label></td>';
                listItem += selectElement(downVoting,'down-voting-select',['Yes','No']);
                listItem += '</tr>';
        
                //max votes per a day
                listItem += '<tr class="max-votes">';
                listItem += '<td><label>Max Votes Per Day</label></td>';    
                listItem += '<td><input type="number" min="-1" class="regular-text max-votes-input" style="width: 150px;" value="'+maxVotes+'"></td>';
                listItem += '</tr>'; 
        
                //max ideas per a day
                listItem += '<tr class="max-ideas">';
                listItem += '<td><label>Max Ideas Per Day</label></td>';    
                listItem += '<td><input type="number" min="-1" class="regular-text max-ideas-input" style="width: 150px;" value="'+maxIdeas+'"></td>';
                listItem += '</tr>'; 
                
                //sitewide search
                listItem += '<tr class="hide-from-search">';
                listItem += '<td><label>Hide From Search</label></td>';
                listItem += selectElement(hideFromSearch,'hide-from-search-select',['Yes','No']);
                listItem += '</tr>';
                
                //showTo
                //show only to   
                //get user roles
                var userRoles = $('#idea-push-user-roles').attr('data');
        
                var userRolesToArray = userRoles.split('||');
        
                
                
                listItem += '<tr class="show-board-to">';
                listItem += '<td><label>Show Board To</label></td>';
                listItem += '<td><select style="width:150px;" class="show-board-to-select">';
        
                if(showTo == 'Everyone'){
                    listItem += '<option value="Everyone" selected="selected">Everyone</option>';    
                } else {
                    listItem += '<option value="Everyone">Everyone</option>';       
                }
                        
        
                for (var i = 0; i < userRolesToArray.length; i++) {
                    
                    
                    var userRoleArray = userRolesToArray[i];
                    var userRoleArrayFurtherSplit = userRoleArray.split('|');
                    
                    if(userRoleArray.length > 0){
                        
                        if(showTo == userRoleArrayFurtherSplit[0]){
                            listItem += '<option value="'+userRoleArrayFurtherSplit[0]+'" selected="selected">'+userRoleArrayFurtherSplit[1]+'</option>';    
                        } else {
                            listItem += '<option value="'+userRoleArrayFurtherSplit[0]+'">'+userRoleArrayFurtherSplit[1]+'</option>';    
                        }
                            
                            
                    }
 
                }
        
                listItem += '</select></td>';
                listItem += '</tr>';
                
        
        
        
                //pagination
                listItem += '<tr class="pagination">';
                listItem += '<td><label>Pagination Number</label></td>'; 
        
                //set initial value if unset
                if(pagination == null){ 
                    pagination = -1;    
                }
        
                listItem += '<td><input type="number" min="-1" max="200" class="regular-text pagination-input" style="width: 150px;" value="'+pagination+'"></td>';
                listItem += '</tr>'; 
            

               
                if($('#is-pro-check').hasClass('fa-unlock')){
                    
                    //enable challenge
                    listItem += '<tr class="enable-challenge">';
                    listItem += '<td><label>Enable Challenge</label></td>';
                    listItem += selectElement(enableChallenge,'enable-challenge-select',['No','Yes']);
                    listItem += '</tr>';


                    //challenge victory
                    listItem += '<tr class="challenge-victory challenge-field">';
                    listItem += '<td><label>Challenge Victory</label></td>';
                    listItem += selectElement(challengeVictory,'challenge-victory-select',['Most Votes','Most Ideas','Popular Idea']);
                    listItem += '</tr>';


                    //challenge date
                    listItem += '<tr class="challenge-date challenge-field">';
                    listItem += '<td><label>Challenge Date</label></td>';
                    listItem += '<td><input type="date" class="regular-text challenge-date-input" style="width: 150px;" value="'+challengeDate+'"></td>';
                    listItem += '</tr>';

                    //challenge time
                    listItem += '<tr class="challenge-time challenge-field">';
                    listItem += '<td><label>Challenge Time</label></td>';
                    listItem += '<td><input type="time" class="regular-text challenge-time-input" style="width: 150px;" value="'+challengeTime+'"></td>';
                    listItem += '</tr>';  
                    
                    
                    //challenge message
                    listItem += '<tr class="challenge-message challenge-field">';
                    listItem += '<td><label>Challenge Message</label></td>';
                    listItem += '<td><textarea class="regular-text challenge-message-input" style="width: 150px;">'+challengeMessage+'</textarea></td>';
                    listItem += '</tr>';
                    
                    //challenge victory message
                    listItem += '<tr class="challenge-victory-message challenge-field">';
                    listItem += '<td><label>Challenge Vic. Message</label></td>';
                    listItem += '<td><textarea class="regular-text challenge-victory-message-input" style="width: 150px;">'+challengeVictoryMessage+'</textarea></td>';
                    listItem += '</tr>';

                    //tag scope
                    listItem += '<tr class="tag-scope">';
                    listItem += '<td><label>Tag Scope</label></td>';
                    listItem += selectElement(tagScope,'tag-scope-select',['Global','Board']);
                    listItem += '</tr>';

                    //field settings
                    var fieldSettingsData = $('#idea-push-form-settings').attr('data');
                    var fieldSettingsDataToArray = fieldSettingsData.split('|');

                    fieldSettingsDataToArray = fieldSettingsDataToArray.filter(function(e){return e}); 

                    listItem += '<tr class="field-settings">';
                    listItem += '<td><label>Field Setting</label></td>';
                    listItem += selectElement(fieldSettings,'field-settings-select',fieldSettingsDataToArray);
                    listItem += '</tr>';

                    //tag scope
                    listItem += '<tr class="idea-scope">';
                    listItem += '<td><label>Idea Scope</label></td>';
                    listItem += selectElement(ideaScope,'idea-scope-select',['Global','Board']);
                    listItem += '</tr>';

                    //user edit/delete idea
                    listItem += '<tr class="user-idea-edit-delete">';
                    listItem += '<td><label>User Idea Edit/Delete</label></td>';
                    listItem += selectElement(userIdeaEditDelete,'user-idea-edit-delete-select',['Yes','No']);
                    listItem += '</tr>';

                    //hide leaderboard
                    listItem += '<tr class="hide-leaderboard">';
                    listItem += '<td><label>Hide Leaderboard</label></td>';
                    listItem += selectElement(hideLeaderboard,'hide-leaderboard-select',['Yes','No']);
                    listItem += '</tr>';

                    //multiple IP
                    listItem += '<tr class="enable-multi-ips">';
                    listItem += '<td><label>Enable Multi IP\'s</label></td>';
                    listItem += selectElement(enableMultiIp,'enable-multi-ips-select',['No','Yes']);
                    listItem += '</tr>';
                    
                }

                
                    
        
        
                //copy shortcode and delete board
                listItem += '<tr class="board-action-buttons">';
                listItem += '<td colspan="2"><button style="margin-right:6px;" class="copy-board-shortcode button-secondary" data-clipboard-text="[ideapush board=&quot;'+termId+'&quot;]" data="'+termId+'">Copy Shortcode</button><button class="delete-board button-secondary-red" data="'+termId+'">Delete Board</button></td>';
                listItem += '</tr>';
        
        
                
        
        
            listItem += '</table>'; 
        listItem += '</li>';
        
        return listItem;
        
        
    }
    

    
    //deletes a board
    $('.wrap').on("click",".delete-board",function(event) {
        event.preventDefault();
        
        var deleteBoardButton = $(this);

        alertify
        .okBtn("Yes")
        .cancelBtn("No")
        .confirm($('#dialog-delete-board-confirmation').attr('data'), function (ev) {
            deleteBoardButton.parent().parent().parent().parent().parent().remove();
        }, function(ev) {


        });

    });
    
    
    
    
    
    //clipboard function
    new ClipboardJS('.copy-board-shortcode');
    $('.wrap').on("click",".copy-board-shortcode",function(event) {
        event.preventDefault(); 
        
        var shortcodeData = $(this).attr('data-clipboard-text');
 
        alertify.alert('The shortcode has now been copied to your clipboard. Or you can copy the following shortcode: <code style="font-weight: bold;">'+shortcodeData+'</code>. Now just put this shortcode onto any post or page (page recommended). It is recommended that you put this onto a page which is full width and doesn\'t have a sidebar.');

    });

    
    
    
    
    function runBoardSaveRoutine(){
        
        var data = '';
        var comparisonData = '';
        //we need to cycle through each list item
        
        //we need to get the respective values and separate by | and separate the arrays by ||
        
        $('#board-settings li').each(function () {
            
            var boardId = $(this).attr('data');
            var boardName = $(this).find('.board-name-input').val();
            var voteThreshold = $(this).find('.vote-threshold-input').val();
            var holdIdeas = $(this).find('.hold-ideas-select option:selected').text();
            var showComments = $(this).find('.comments-select option:selected').text();
            var showTags = $(this).find('.tags-select option:selected').text();
            var showAttachments = $(this).find('.attachments-select option:selected').text();
            var showBoardTitle = $(this).find('.board-title-select option:selected').text();
            var showVoteTarget = $(this).find('.vote-target-select option:selected').text();
            var guestAccess = $(this).find('.guest-access-select option:selected').text();
            var downVoting = $(this).find('.down-voting-select option:selected').text();
            var maxVotes = $(this).find('.max-votes-input').val();
            var maxIdeas = $(this).find('.max-ideas-input').val();
            var hideFromSearch = $(this).find('.hide-from-search-select option:selected').text();
            var showTo = $(this).find('.show-board-to-select').val();
            var pagination = $(this).find('.pagination-input').val();            
            var enableChallenge = $(this).find('.enable-challenge-select option:selected').text();
            var challengeVictory = $(this).find('.challenge-victory-select option:selected').text();
            var challengeDate = $(this).find('.challenge-date-input').val();
            var challengeTime = $(this).find('.challenge-time-input').val();
            var challengeMessage = $(this).find('.challenge-message-input').val();
            var challengeVictoryMessage = $(this).find('.challenge-victory-message-input').val();
            var tagScope = $(this).find('.tag-scope-select option:selected').text();
            var fieldSettings = $(this).find('.field-settings-select option:selected').text();
            var ideaScope = $(this).find('.idea-scope-select option:selected').text();
            var userIdeaEditDelete = $(this).find('.user-idea-edit-delete-select option:selected').text();
            var hideLeaderboard = $(this).find('.hide-leaderboard-select option:selected').text();
            var enableMultiIp = $(this).find('.enable-multi-ips-select option:selected').text();
            
            

            //get current date
            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth()+1; 
            var yyyy = today.getFullYear();

            if(dd<10) 
            {
                dd='0'+dd;
            } 

            if(mm<10) 
            {
                mm='0'+mm;
            } 

            //get current time
            var currentTime = new Date().toLocaleTimeString('en-US', { hour12: false, hour: "numeric", minute: "numeric"});

            //add default values if no values
            if(challengeDate == ''){
                challengeDate = yyyy+'-'+mm+'-'+dd;    
            }

            if(challengeTime == ''){
                challengeTime = currentTime;    
            }
            
            
            
            var singleBoardSetting = boardId+'|'+boardName+'|'+voteThreshold+'|'+holdIdeas+'|'+showComments+'|'+showTags+'|'+showAttachments+'|'+showBoardTitle+'|'+showVoteTarget+'|'+guestAccess+'|'+downVoting+'|'+maxVotes+'|'+maxIdeas+'|'+hideFromSearch+'|'+showTo+'|'+pagination+'|'+enableChallenge +'|'+challengeVictory+'|'+challengeDate +'|'+challengeTime+'|'+challengeMessage+'|'+challengeVictoryMessage+'|'+tagScope+'|'+fieldSettings+'|'+ideaScope+'|'+userIdeaEditDelete+'|'+hideLeaderboard+'|'+enableMultiIp+ '^^^';

            // console.log(singleBoardSetting);

            
            data += singleBoardSetting;
            
            var singleComparisonData = boardId+'|'+boardName+'^^^';
            
            comparisonData += singleComparisonData;
            
        });
        
        $('#idea_push_board_configuration').val(data);  
        
        //lets send off the comparison data to see if we need to delete any existing terms or rename them
        var data = {
            'action': 'taxonomy_save_routine',
            'comparisonData': comparisonData,
        };

        jQuery.post(ajaxurl, data, function (response) {
            //there's no need to do anything in the response
//            console.log(response);
        });
          
    }



    function runFormSaveRoutine(){

        //console.log('the save routine was ran');

        //store the setting in this variable
        var data = '';

        $('#form-settings-container > li').each(function () {

            //console.log('I was ran');

            //get the name
            var name = $(this).find('.form-setting-name').val();

            //get the standard settings
            var formTitle = $(this).find('.form-title').val();
            var ideaTitle = $(this).find('.idea-title').val();
            var ideaDescription = $(this).find('.idea-description').val();
            var ideaTags = $(this).find('.idea-tags').val();
            var ideaAttachment = $(this).find('.idea-attachment').val();
            var submitButton = $(this).find('.submit-button').val();
            var submitIdeaButton = $(this).find('.submit-idea-button').val();

            //remove any pipes from values
            formTitle.replace('|','');
            ideaTitle.replace('|','');
            ideaDescription.replace('|','');
            ideaTags.replace('|','');
            ideaAttachment.replace('|','');
            submitButton.replace('|','');
            submitIdeaButton.replace('|','');

            if(formTitle.length == 0){
                formTitle = ' ';
            }
            if(ideaTitle.length == 0){
                ideaTitle = ' ';
            }
            if(ideaDescription.length == 0){
                ideaDescription = ' ';
            }
            if(ideaTags.length == 0){
                ideaTags = ' ';
            }
            if(ideaAttachment.length == 0){
                ideaAttachment = ' ';
            }
            if(submitButton.length == 0){
                submitButton = ' ';
            }
            if(submitIdeaButton.length == 0){
                submitIdeaButton = ' ';
            }

            
            //create output
            data += '^^^^'+name;
            data += '|||';
            data += formTitle + '||';
            data += ideaTitle + '||';
            data += ideaDescription + '||';
            data += ideaTags + '||';
            data += ideaAttachment + '||';
            data += submitButton + '||';
            data += submitIdeaButton;
            data += '|||';

            //only do if pro options found
            if($(this).find('.form-setting-pro-options').length){

                var amountOfRows = $(this).find('.form-setting-pro-options li').length;

                //get custom settings
                $(this).find('.form-setting-pro-options li').each(function (index,element) {

                    var fieldType = $(this).find('.custom-field-type').val();
                    var fieldName = $(this).find('.custom-field-name').val();
                    var fieldOptions = $(this).find('.custom-field-options').val();
                    var fieldRequired = $(this).find('.custom-field-required').val();

                    //remove any pipes in options        
                    fieldName.replace('|','');
                    fieldOptions.replace('|','');


                    
                    var errors = false;

                    if(fieldName.length < 1){
                        errors = true;
                    }

                    if(  (fieldType == 'select' || fieldType == 'radio' || fieldType == 'checkbox') && fieldOptions.length < 1 ){
                        errors = true;
                    }
                    

                    if(fieldOptions.length < 1){
                        fieldOptions = ' ';
                    }

                    //console.log(errors);


                    if(errors == false){
                        
                        if(index === (amountOfRows - 1)){
                            // console.log('last row found');
                            data += fieldType+'|'+fieldName+'|'+fieldOptions+'|'+fieldRequired;
                        } else {
                            data += fieldType+'|'+fieldName+'|'+fieldOptions+'|'+fieldRequired+'||';
                        }


                    }


                    

                }); 

                
            } else {
                data += ' ';    
            }
 
        });    

        // console.log(data);

        //if string contain 6 pipes make it 4
        //data = data.replace("||||||","||||");

        $('#idea_push_form_settings').val(data);

  
    }




    
    
    
    
    function turnSettingIntoListItems(){
        
        var boardConfiguration = $('#idea_push_board_configuration').val();
        
        var dataToAppend = '';
        
        //turn the value into array
        //if the board configuration contains ^^^ split by that value, otherwise split by the legacy ||
        if( boardConfiguration.indexOf('^^^') !== -1 ){
            var boardConfigurationArray = boardConfiguration.split('^^^');
        } else {
            var boardConfigurationArray = boardConfiguration.split('||');
        }
        
        
        //loop through array
        for(var i =0; i<boardConfigurationArray.length;i++){
            
            //turn this value into array
            var furtherSplit = boardConfigurationArray[i].split('|');
            
            //only append the data if the board has a name
            
            if(furtherSplit[0].length > 0){
            
                dataToAppend += createBoardSettingLineItem(furtherSplit[0],furtherSplit[1],furtherSplit[2],furtherSplit[3],furtherSplit[4],furtherSplit[5],furtherSplit[6],furtherSplit[7],furtherSplit[8],furtherSplit[9],furtherSplit[10],furtherSplit[11],furtherSplit[12],furtherSplit[13],furtherSplit[14],furtherSplit[15],furtherSplit[16],furtherSplit[17],furtherSplit[18],furtherSplit[19],furtherSplit[20],furtherSplit[21],furtherSplit[22],furtherSplit[23],furtherSplit[24],furtherSplit[25],furtherSplit[26],furtherSplit[27]);
            }
            
        }
        
        //append data
        $( "#board-settings" ).append(dataToAppend);
        
    }
    //run on load
    if($('#idea_push_board_configuration').length){
        turnSettingIntoListItems();    
    }
    
    
    
    
    
    
    //adds shortcode button text to tinymce area  
    $('.ideapush_append_buttons_advanced').click(function () {
        
        var attributeValue = $(this).attr('value');
                
        var id = $(this).attr('data');
        
        var attributeValueWrapped = '<p>'+attributeValue+'</p>';
        
        $('#'+id+'_ifr').contents().find("#tinymce p").html( $('#'+id+'_ifr').contents().find("#tinymce p").html() + attributeValueWrapped);
        
        $('#'+id+'-editor-container').find("textarea").html( $('#'+id+'-editor-container').find("textarea").html() + attributeValueWrapped);
        

        
    });
    
    
    if($('.datepicker').length){    
        $('.datepicker').datepicker({  
        dateFormat:"yy-mm-dd",    
        });   
    }

    
    
    //get reports
    $('.wrap').on("click","#get-ideapush-reports",function(event) {
        event.preventDefault();
        
        
        $('.report-body').hide();
        
        //user table needs the following:
        
        //1. user name (first and last presented as a link to their userprofile), 2. the users role 3. the amount of ideas created 4. the amount of upvotes, 5. the amount of downvotes
        
        //note we will show all users
        
        var startDate = $('#idea_push_start_date').val();
        var endDate = $('#idea_push_end_date').val();
        
        
        var data = {
                'action': 'get_user_table',
                'startDate': startDate,
                'endDate': endDate,
            };

        jQuery.post(ajaxurl, data, function (response) {
            
            console.log(response);
            
            //split string into array
            
            var separaterDataIntoTableAndChart = response.split('$$$');
            
            var separateUsers = separaterDataIntoTableAndChart[0].split('||');
            
            var holdingArray = [];
            
            for (var i = 0; i < separateUsers.length; i++) {
                
                var separateData = separateUsers[i].split('|');
                
                if(separateData.length>4){
                    
                    var arrayToPush = [separateData[0],separateData[1],parseInt(separateData[2]),parseInt(separateData[3]),parseInt(separateData[4])];
                    
                    holdingArray.push(arrayToPush);    
                }
  
            }
            
            google.charts.load('current', {'packages':['table']});
            google.charts.setOnLoadCallback(drawTable);

            function drawTable() {
                var data = new google.visualization.DataTable();
                data.addColumn('string', 'Name');
                data.addColumn('string', 'Role');
                data.addColumn('number', 'Ideas Created');
                data.addColumn('number', 'Up Votes');
                data.addColumn('number', 'Down Votes');
                data.addRows(
                    holdingArray     
            );

            var table = new google.visualization.Table(document.getElementById('user-table'));

            table.draw(data, {showRowNumber: false, width: '100%', height: '100%'});
            }
            
            
            
         
            
            
            
            
            
            
            
            
            
            //what we want to do is show a line graph showing ideas, upvotes and downvotes over time
        
     
              var separateDates = separaterDataIntoTableAndChart[1].split('||'); 
            
                
                var lineHoldingArray = [];

                for (var i = 0; i < separateDates.length; i++) {

                    var separateData = separateDates[i].split('|');

                    if(separateData.length>3){
                        
                        var date = new Date(separateData[0].replace('-',','));
                        
                        var arrayToPush = [date,parseInt(separateData[1]),parseInt(separateData[2]),parseInt(separateData[3])];

                        lineHoldingArray.push(arrayToPush);    
                    }

                }

            
            

                console.log(separateDates);

              google.charts.load('current', {'packages':['line']});
              google.charts.setOnLoadCallback(drawChart);

              function drawChart() {

                  var data = new google.visualization.DataTable();

                  data.addColumn('date', 'Date');
                  data.addColumn('number', 'Ideas Created');
                  data.addColumn('number', 'Up Votes');
                  data.addColumn('number', 'Down Votes');


//                data.addRows([
//                  [new Date(2000,8,5),  1000,      400,      400],
//                  [new Date(2000,8,6),  1170,      460,      500],
//                  [new Date(2000,8,7),  660,       1120,      100],
//                  [new Date(2000,9,2),  1030,      540,      900],
//                  [new Date(2000,9,6),  1030,      540,      900]
//                ]);
                  
                  data.addRows(lineHoldingArray);





                var pageWidth = $('.report-header').width();  

                var options = {
        //          title: 'Company Performance',
        //          curveType: 'function',
                    width: pageWidth,
                    height: 700,
                  legend: { position: 'bottom' },
                    lineWidth: 10,
                    series: {
                    0: { color: '#4eb5e1',lineWidth: 10 },
                    1: { color: '#5eb46a',lineWidth: 10 },
                    2: { color: '#f05d55',lineWidth: 10 },
                  },
                    backgroundColor: 'transparent',

                };

        //        var chart = new google.visualization.LineChart(document.getElementById('activity-line-graph'));
        //
        //        chart.draw(data, options);

                  var chart = new google.charts.Line(document.getElementById('activity-line-graph'));

                  chart.draw(data, google.charts.Line.convertOptions(options));

              } //end line graph



              $('.report-body').show();      
            
      

        }); //end response of ajax
        
        
        
    }); //end get reports
    
    
    
    
    
    
    
    //permanently hide notice
    $('.wrap').on("click",".ideapush-welcome .notice-dismiss", function(event){
        
        event.preventDefault();
        
        
        //check the checkbox
        $('#idea_push_hide_admin_notice').prop('checked',true);
        
        //save the settings
        $('#ideapush_settings_form').ajaxSubmit({
            success: function(){
                console.log('Settings saved');
            }
        });
        
        
        
    });
    
    
    
   
    $('.wrap').on("click",".zendesk-finalisation",function(event) {
        event.preventDefault();
        
        
        $('<div class="notice notice-warning is-dismissible zendesk-loading-message"><p><i class="fa fa-spinner" aria-hidden="true"></i> Please wait while we carry out these actions on your Zendesk account...</p></div>').insertAfter('.zendesk-finalisation');
        
        var data = {
            'action': 'zendesk_finalisation',

        };

        jQuery.post(ajaxurl, data, function (response) {

            console.log(response);
  
            $('.zendesk-loading-message').remove();

            $('<div class="notice notice-success is-dismissible zendesk-saved-message"><p>The actions on your Zendesk account have been completed. There is no need to save the settings.</p></div>').insertAfter('.zendesk-finalisation');

            setTimeout(function() {
                $('.zendesk-saved-message').slideUp();
            }, 5000);
            

        }); //end jquery post

        
        
    
    }); //end zendesk finalisation


    $('.wrap').on("click",".jira-finalisation",function(event) {
        event.preventDefault();
        
        
        $('<div class="notice notice-warning is-dismissible jira-loading-message"><p><i class="fa fa-spinner" aria-hidden="true"></i> Please wait while we carry out these actions on your Jira account...</p></div>').insertAfter('.jira-finalisation');
        
        var data = {
            'action': 'jira_finalisation',

        };

        jQuery.post(ajaxurl, data, function (response) {

            console.log(response);
  
            $('.jira-loading-message').remove();

            $('<div class="notice notice-success is-dismissible jira-saved-message"><p>The actions on your Jira account have been completed. There is no need to save the settings.</p></div>').insertAfter('.jira-finalisation');

            setTimeout(function() {
                $('.jira-saved-message').slideUp();
            }, 5000);
            

        }); //end jquery post

        
        
    
    }); //end zendesk finalisation

    
    
    
    //this checks to make sure the unique phrase is unique
    $('body').on('keyup', '#idea_push_zendesk_unique_phrase',function(){
        
        var inputValue = $(this).val();
        var hasNumber = /\d/;
        var specialCharacters = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
        
        
        if(inputValue.length < 8 || inputValue.indexOf(' ') >= 0 || hasNumber.test(inputValue) == false || /[a-z]/i.test(inputValue) == false || specialCharacters.test(inputValue) == false){
            
            $('.unique-phrase-message').remove();
            
            $('<div class="notice notice-error is-dismissible unique-phrase-message inline"><p>Please ensure you enter a phrase which has letters, numbers, special characters (like an underscore for example) and is at least 8 characters long and does not have spaces.</p></div>').insertAfter('#idea_push_zendesk_unique_phrase');    
            
        } else {
            $('.unique-phrase-message').slideUp();
            
        }
     
    });

    $('body').on('keyup', '#idea_push_jira_unique_phrase',function(){
        
        var inputValue = $(this).val();
        var hasNumber = /\d/;
        
        
        if(inputValue.length < 8 || inputValue.indexOf(' ') >= 0 || hasNumber.test(inputValue) == false || /[a-z]/i.test(inputValue) == false){
            
            $('.unique-phrase-message').remove();
            
            $('<div class="notice notice-error is-dismissible unique-phrase-message inline"><p>Please ensure you enter a phrase which has letters, numbers and is at least 8 characters long and does not have spaces.</p></div>').insertAfter('#idea_push_jira_unique_phrase');    
            
        } else {
            $('.unique-phrase-message').slideUp();
            
        }
     
    });
    
    
    $('#wpbody').on("change", ".enable-challenge-select", function () {
        
        var selectValue = $(this).val();
                
        var parentContainer = $(this).parent().parent().parent();
        
        
        if(selectValue == 'Yes'){
            
            parentContainer.find('.challenge-field').show(); 
            
        } else {
            parentContainer.find('.challenge-field').hide();   
        }
        
    });
    
    
    function hideAndShowChallengeFields(){
        $('.enable-challenge-select').each(function () {
            var selectValue = $(this).val();
            var parentContainer = $(this).parent().parent().parent();
            if(selectValue == 'Yes'){

                parentContainer.find('.challenge-field').show(); 

            } else {
                parentContainer.find('.challenge-field').hide();   
            }

        });    
        
    }
    hideAndShowChallengeFields();








    //on form settings delete, delete the list item
    $('.wrap').on("click",".delete-form-settings",function(event) {
        event.preventDefault();

        var deleteFormSetting = $(this);
        
        //hide existing dialog
        alertify
        .okBtn("Yes")
        .cancelBtn("No")
        .confirm($('#dialog-delete-form-setting-confirmation').attr('data'), function (ev) {

            deleteFormSetting.parent().parent().parent().remove();

        }, function(ev) {

        });




    }); 
    
    //on form settings edit, toggle the form setting options
    $('.wrap').on("click",".edit-form-settings",function(event) {
        event.preventDefault();

        $(this).parent().parent().parent().find('.form-setting-inner-expanded-setting').slideToggle();

    });     
    
    
    //on form settings duplicate, duplicate the form setting option
    $('.wrap').on("click",".duplicate-form-settings",function(event) {
        event.preventDefault();

        var thisListItem = $(this).parent().parent().parent();

        var thisListItemName = thisListItem.find('.form-setting-name').val();

        thisListItem.clone().insertAfter(thisListItem);

        thisListItem.next().find('.form-setting-name').val(thisListItemName+' (copy)');
        thisListItem.next().find('.form-setting-name').prop('readOnly',false);
        thisListItem.next().removeClass('default-form-setting');

        //make custom fields sortable
        $( ".form-setting-pro-options" ).sortable();

    }); 


    //on form settings duplicate, duplicate the form setting option
    $('.wrap').on("click",".add-custom-field",function(event) {
       
        event.preventDefault();

        var thisListItem = $(this).parent().parent();

        thisListItem.clone().insertAfter(thisListItem);

        thisListItem.next().find('.custom-field-type').val('text');
        thisListItem.next().find('.custom-field-name').val('');
        thisListItem.next().find('.custom-field-options').val('');
        thisListItem.next().find('.custom-field-type').val('no');

    }); 


    //on form settings duplicate, duplicate the form setting option
    $('.wrap').on("click",".delete-custom-field",function(event) {
       
        event.preventDefault();

        $(this).parent().parent().remove();

    }); 

    //make custom fields sortable
    $( ".form-setting-pro-options" ).sortable();

    //selectively hide and show custom field options
    function hideAndShowCustomFieldOptions(){

        $('.form-setting-pro-options li').each(function () {
            
            if( $(this).find('.custom-field-type').val() == 'text' || $(this).find('.custom-field-type').val() == 'textarea'   || $(this).find('.custom-field-type').val() == 'video'     ){
                $(this).find('.custom-field-options-container').hide();
                $(this).find('.custom-field-required-container').show();
            } else if($(this).find('.custom-field-type').val() == 'checkbox' || $(this).find('.custom-field-type').val() == 'radio') {
                $(this).find('.custom-field-options-container').show();
                $(this).find('.custom-field-required-container').show();
            } else {
                $(this).find('.custom-field-options-container').show();
                $(this).find('.custom-field-required-container').hide();
            }
            
        });


    }
    hideAndShowCustomFieldOptions();

    $( '.wrap' ).on( 'change' ,'.custom-field-type' ,function () {
        hideAndShowCustomFieldOptions();
    });   
    
    


    function deletepluginupdatetransient(){
        //_site_transient_update_plugins

        var data = {
            'action': 'idea_push_delete_plugin_updates_transient',
        };

        jQuery.post(ajaxurl, data, function (response) {
            // console.log('HELLO WORLD');
        });    
    }



    
    







});