<?php
/**
 * The template for displaying ip-tag archive pages
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<?php
					the_archive_title( '<h1 class="page-title">', '</h1>' );
					the_archive_description( '<div class="taxonomy-description">', '</div>' );
				?>
			</header><!-- .page-header -->
            
            
            
            

			<?php
            
            //get options
            $options = get_option('idea_push_settings');            
            
            $primaryColor = esc_html($options['idea_push_primary_link_colour']);
            
            //lets output some css
            echo '<style>
            
                .ideapush-container i, .ideapush-container a, .ideapush-container .idea-item-tag:hover, .ideapush-container .idea-item-file:hover, .ideapush-dialog .close-button, .ideapush-dialog-image .close-button, .idea-page-number.active,.idea-page-number:hover
                {color: '.$primaryColor.';}


                .submit-new-idea,.submit-new-idea:hover,.submit-new-idea:focus, .ideapush-dialog .ui-button,.ideapush-dialog .ui-button:hover,.ideapush-dialog .ui-button:focus, .admin-star-outer,.admin-star-outer-large
                {background: '.$primaryColor.';}
                    
                .ideapush-container .idea-item-tag:hover, .ideapush-container .idea-item-file:hover, .ideapush-dialog .ui-button,.ideapush-dialog .ui-button:hover,.ideapush-dialog .ui-button:focus, .ideapush-dialog .close-button, .ideapush-dialog-image .close-button, .idea-page-number.active,.idea-page-number:hover
                {border-color: '.$primaryColor.';}

                .alertify .cancel
                {color: '.$primaryColor.' !important;}

                .alertify .ok, .alertify .cancel
                {border-color: '.$primaryColor.' !important;}

                .alertify .ok
                {background-color: '.$primaryColor.' !important;}

            </style>';
            
            
            
            $currentUserId = idea_push_check_if_non_logged_in_user_is_guest();
            $currentUserObject = get_user_by( 'id', $currentUserId);
            $currentUserRole = $currentUserObject->roles;
            
            $boardSettings = idea_push_get_board_settings(idea_push_get_board_id_from_post_id($ideaPost->ID));
            
            $paginationNumber = $boardSettings[15];
        
            //this is used for pagination
            $ideaNumber = 1;

            //check if pagination required
            if(isset($paginationNumber) && $paginationNumber>0){
                $paginationEnabled = true;
            } else {
                $paginationEnabled = false;    
            }

            
            
            echo '<div class="ideapush-container">';
//            echo '<div class="ideapush-container-ideas">';
            echo '<ul class="dynamic-idea-listing">';
            
			// Start the Loop.
			while ( have_posts() ) : the_post();

                $ideaPost = get_post();
            
            
            
                $getTerms = get_the_terms($ideaPost->ID, 'status' );  
          
                foreach($getTerms as $term) {
                    $status = $term->name;    
                } 
                $status = strtolower(str_replace(" ","-",$status));
                
 
                
                
                $showBoardTo = $boardSettings[14];
            
                
                if(in_array($showBoardTo, $currentUserRole) || $showBoardTo == "Everyone"){ 
            
            
                    if($paginationEnabled){
                        $html = '<li data-page="'.ceil($ideaNumber/$paginationNumber).'" class="idea-item idea-item-'.$ideaPost->ID.'" hidden-idea">';    
                    } else {
                        $html = '<li class="idea-item idea-item-'.$ideaPost->ID.'"">';    
                    }   

                    //left side
                    $html .= '<div class="idea-item-left">';

                        $html .= idea_push_vote_part($ideaPost->ID,$status,$boardSettings);

                    $html .= '</div>'; //end left side


                    //right side
                    $html .= '<div class="idea-item-right">';

                        $html .= '<div class="idea-item-right-inner">';

                            //title
                            //if pro option is set
                            if(!isset($options['idea_push_disable_single_idea_page']) || $options['idea_push_disable_single_idea_page'] !== "1"){
                                $html .= '<a href="'.esc_url(get_post_permalink($ideaPost->ID)).'" class="idea-title">';
                            } else {
                                 $html .= '<a class="idea-title">';    
                            }

                            $html .= esc_html($ideaPost->post_title);
                            $html .= '</a>'; 


                            //get the meta
                            $html .= idea_push_get_idea_meta($ideaPost,$status,$boardSettings);



                            //get the content
                            $html .= '<div class="idea-item-content-container">';

                            if(!isset($options['idea_push_disable_single_idea_page']) || $options['idea_push_disable_single_idea_page'] !== "1"){

                                if(strlen($ideaPost->post_content)>200){
                                    $readMore = '... <a class="idea-read-more" href="'.esc_url(get_post_permalink($ideaPost->ID)).'">'.__('Read more','ideapush').'...</a>';
                                } else {
                                    $readMore = '';   
                                }

                                $html .= '<span class="idea-item-content">'.substr(strip_tags($ideaPost->post_content),0,200).'</span>'.$readMore;     
                            } else {

                                $html .= '<div id="ideaReadMoreText" style="display: none;">'.__('Read more','ideapush').'</div>';

                                $html .= '<div id="ideaReadLessText" style="display: none;">'.__('Read less','ideapush').'</div>';

                                $html .= '<span class="idea-item-content idea-item-content-read-more">'.strip_tags($ideaPost->post_content).'</span>';    

                            }


                            $html .= '</div>';



                            //get attachment and tags
                            $html .=  idea_push_get_tags_and_attachments($ideaPost->ID);

                        $html .= '</div>';
                    $html .= '</div>';

                $html .= '</li>'; 
                
                $ideaNumber++;    
                    
                echo $html;    
            }
            
            
            
            
            
            
            
			// End the loop.
			endwhile;
            
            
            //do pagination
            if($paginationEnabled){

                $amountOfPages = ceil(($ideaNumber-1)/$paginationNumber);

                $html = '<li class="idea-pagination">';

                    $html .= '<ul class="idea-pagination-listing">';

                        for($i=1;$i<=$amountOfPages;$i++){

                            if($i == 1){

                                $html .= '<li class="idea-page-number active idea-page-'.$i.'">'.$i.'</li>';    
                            } else {

                                $html .= '<li class="idea-page-number idea-page-'.$i.'">'.$i.'</li>';    
                            }



                        }

                    $html .= '</ul>';

                $html .= '</li>'; 

                echo $html;    

            }
            
            
            
            echo '</ul></div>';

            //edit idea popup heading
            echo '<div style="display: none;" id="dialog-edit-idea-heading" data="'.__( 'Edit Idea', 'ideapush' ).'"></div>';

            //edit idea popup heading
            echo '<div style="display: none;" id="dialog-idea-edited" data="'.__( 'The idea has been updated.', 'ideapush' ).'"></div>';

            //user delete idea dialog
            echo '<div style="display: none;" id="dialog-idea-delete" data="'.__( 'Are you sure you want to delete this idea?', 'ideapush' ).'"></div>';

            //user idea deleted dialog
            echo '<div style="display: none;" id="dialog-idea-deleted" data="'.__( 'The idea has been deleted.', 'ideapush' ).'"></div>';
            
            
			// Previous/next page navigation.
			the_posts_pagination( array(
				'prev_text'          => __( 'Previous page', 'ideapush' ),
				'next_text'          => __( 'Next page', 'ideapush' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'ideapush' ) . ' </span>',
			) );

		// If no content, include the "No posts found" template.
		else :
			echo '<div>'.__( 'There are no ideas found for this tag.', 'ideapush' ).'</div>';
		endif;
		?>

		</main><!-- .site-main -->
	</div><!-- .content-area -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
