<?php

function idea_push_header_render_output($boardNumber,$showing){
    
    global $ideapush_is_pro;
    
    $individualBoardSetting = idea_push_get_board_settings($boardNumber);
    
    //declare standard variables
    $boardId = $individualBoardSetting[0];
    $boardName = $individualBoardSetting[1];
    $voteThreshold = $individualBoardSetting[2];
    $holdIdeas = $individualBoardSetting[3];
    $showComments = $individualBoardSetting[4];
    $showTags = $individualBoardSetting[5];
    $showAttachments = $individualBoardSetting[6];
    $showBoardTitle = $individualBoardSetting[7];
    $showVoteTarget = $individualBoardSetting[8];
    $guestAccess = $individualBoardSetting[9];
    $downVoting = $individualBoardSetting[10];
    
    
    $currentUserId = idea_push_check_if_non_logged_in_user_is_guest();
    
    //get options
    $options = get_option('idea_push_settings');
    
    //get query strings
    //showing
    $defaultShowing = $showing;   
        
    if(isset($_GET['status'])){
        $defaultStatus = sanitize_text_field($_GET['status']);
    } else {
        $defaultStatus = 'open';    
    }
    
    if(isset($_GET['tag'])){

        $defaultTag = sanitize_text_field($_GET['tag']);

        if($defaultTag == 'All'){
            $defaultTag = 'all'; 
        } else {
            if(get_term_by( 'name', $defaultTag, 'tags') == false){
                $defaultTag = get_term_by( 'name', 'BoardTag-'.$boardNumber.'-'.$defaultTag, 'tags');
            } else {
                $defaultTag = get_term_by( 'name', $defaultTag, 'tags');
            }
            $defaultTag = $defaultTag->term_id;
        }

    } else {
        $defaultTag = 'all';    
    }
    
    
    
    $html = '';
    
    //filter
    $html .= '<div class="ideapush-idea-filter">';

        $html .= '<span class="showing-text">'.__( 'Showing', 'ideapush' ).'</span>';
        $html .= '<select data-user-id="'.$currentUserId.'" class="ideapush-sort">';

        

            $html .= '<option value="popular" '.idea_push_check_default_showing('popular',$defaultShowing).'>'.__( 'Popular', 'ideapush' ).'</option>';
            $html .= '<option value="recent" '.idea_push_check_default_showing('recent',$defaultShowing).'>'.__( 'Recent', 'ideapush' ).'</option>';
            $html .= '<option value="trending" '.idea_push_check_default_showing('trending',$defaultShowing).'>'.__( 'Trending', 'ideapush' ).'</option>';

            //only show this option if logged in
            if($currentUserId !== false){
                $html .= '<option value="'.$currentUserId.'" '.idea_push_check_default_showing($currentUserId,$defaultShowing).'>'.__( 'My', 'ideapush' ).'</option>';
                
                $html .= '<option value="my-voted" '.idea_push_check_default_showing('my-voted',$defaultShowing).'>'.__( 'My Voted', 'ideapush' ).'</option>';
            }



        $html .= '</select>';
        













        $html .= ' <span class="ideas-that-are-text">'.__( 'ideas that are', 'ideapush' ).'</span>';
        $html .= '<select class="ideapush-status-filter">';

    
            //declare the standard statuses    
            $statusOptions = array('open','reviewed','approved','declined','in-progress','completed','all-statuses');
     
            foreach($statusOptions as $statusOption){

                //replace the dash for the underscore for the settings lookup
                $statusOptionSetting = str_replace('-','_',$statusOption);

                //lets get the translated name of the status
                $translatedStatusName = $options['idea_push_change_'.$statusOptionSetting.'_status'];

                if(isset($translatedStatusName) && strlen($translatedStatusName) > 0){
                    $translatedStatusName = $translatedStatusName;   
                } else {
                    //replace dashes with spaces
                    $translatedStatusName = str_replace('-',' ',$statusOption);
                    $translatedStatusName = ucwords($translatedStatusName);
                }

                //check if disabled
                if(!isset($options['idea_push_disable_'.$statusOptionSetting.'_status'])){
                    //check if the item is selected
                    if($statusOption == $defaultStatus){
                        $html .= '<option value="'.$statusOption.'" selected="selected">'.esc_html($translatedStatusName).'</option>';
                    } else {
                        $html .= '<option value="'.$statusOption.'">'.esc_html($translatedStatusName).'</option>'; 
                    }
                }
    
            }
          
        $html .= '</select>';








    

        //now conditionally show the tags
        if($showTags == 'Yes'){


            function idea_push_get_tags($boardId){

                $args = array(
                    'post_type' => 'idea',
                    'post_status' => 'publish',
                    'posts_per_page' => -1,
                    'tax_query' => array(
//                                            "relation" => "AND", // important apparently
                        array(
                            'taxonomy' => 'boards',
                            'field'    => 'term_id',
                            'terms'    => array($boardId)
                        ),
                        //if you want to get posts that below to a particular staus we could do that as well by uncommenting below and also adding the status parameter into this function
//                                            array(
//                                                'taxonomy' => 'status',
//                                                'field'    => 'slug',
//                                                'terms'    => array($status)
//                                            ),
                    )
                );

                $ideaPosts = get_posts($args);

                $ideaPostsIds = wp_list_pluck($ideaPosts,'ID');

                $ideaPostsFilter = wp_get_object_terms($ideaPostsIds, 'tags');

                return $ideaPostsFilter;
            }




            $html .= ' <span class="with-tags-text">'.__( 'with tags', 'ideapush' ).'</span>'; 
            $html .= '<select class="ideapush-tags-filter">';



                $html .= '<option value="all">All</option>';

                $tagTerms = idea_push_get_tags($boardId);

                //lets sort these tags alphabetically
                $tagTermsArray = array();

                foreach($tagTerms as $tagTerm){

                    //if tag contains BoardTag, remove it from the tag name
                    if(strpos($tagTerm->name, 'BoardTag-') !== false){

                        $positionOfSecondHyphen = strpos($tagTerm->name, '-', strpos($tagTerm->name, '-') + 1);

                        $tagName = substr($tagTerm->name,$positionOfSecondHyphen+1,strlen($tagTerm->name)-$positionOfSecondHyphen);

                    } else {
                        $tagName = $tagTerm->name;
                    }

                    $tagTermsArray[$tagTerm->term_id] = $tagName; 


                }    

                //sort the array by value
                natcasesort($tagTermsArray);

                //lets only grab the top 15 tags otherwise the dropdown will become too big
                foreach($tagTermsArray as $tagId => $tagName){

                    if($tagId == $defaultTag){

                        $html .= '<option value="'.esc_attr($tagId).'" selected="selected">'.esc_html($tagName).'</option>';

                        // $tagMatch = $tagTerm->term_id;

                    } else {
                        $html .= '<option value="'.esc_attr($tagId).'">'.esc_html($tagName).'</option>';    

                    }
                }    

            $html .= '</select>';
    
        }

    $html .= '</div>';

    //search
    $html .= '<div class="ideapush-idea-search">';
        $html .= '<input class="ideapush-search-input" placeholder="Search"><i class="fa fa-search search-icon" aria-hidden="true"></i></input>';
    $html .= '</div>';




    //output suggested tags for pro users
    //we are going to output this here as that way when new ideas are created those tags can be used in new ideas created
    //because when we publish an idea we rerender the header
    //here is where we will output tags
    if($ideapush_is_pro == 'YES'){

        //we need to get the actual existings tags    
        $tagScope = $individualBoardSetting[22]; //can be either Board or Global

        if(!isset($tagScope)){
            $tagScope = 'Global';
        }
        
        //output suggested tags
        $html .= idea_push_output_suggested_tags($tagScope,$boardId);

        //output suggested tags
        //temporarily lets make the ideascope 'Board'
        $ideaScope = $individualBoardSetting[24];
        if(!isset($ideaScope)){
            $ideaScope = 'Board';
        }

        //we want to output this anyway even if suggested ideas are disabled because we can use this for the duplicate idea feature
        $html .= idea_push_output_suggested_ideas($ideaScope,$boardId);

    }
    
    return $html;
    
}



?>