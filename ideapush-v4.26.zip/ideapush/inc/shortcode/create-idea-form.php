<?php

function idea_push_form_render_output($boardNumber){
    
    $individualBoardSetting = idea_push_get_board_settings($boardNumber);
    
    //declare standard variables
    $boardId = $individualBoardSetting[0];
    $boardName = $individualBoardSetting[1];
    $voteThreshold = $individualBoardSetting[2];
    $holdIdeas = $individualBoardSetting[3];
    $showComments = $individualBoardSetting[4];
    $showTags = $individualBoardSetting[5];
    $showAttachments = $individualBoardSetting[6];
    $showBoardTitle = $individualBoardSetting[7];
    $showVoteTarget = $individualBoardSetting[8];
    $guestAccess = $individualBoardSetting[9];
    $downVoting = $individualBoardSetting[10];
    $formSettings = $individualBoardSetting[23];
    $multiIp = $individualBoardSetting[27];
        
    if(!isset($multiIp)){
        $multiIp = 'No';
    }

    $currentUserId = idea_push_check_if_non_logged_in_user_is_guest($multiIp);
    

    //if not pro set the form settings to the default Default value
    global $ideapush_is_pro;

    if($ideapush_is_pro !== 'YES'){
        $formSettings = 'Default';       
    }


    //get options
    $options = get_option('idea_push_settings');

    $currentOption = $options['idea_push_form_settings'];

    if(strpos($currentOption, '^^^^') !== false){
        $explodedOptions = explode('^^^^',$currentOption);
    } else {
        $explodedOptions = explode('||||',$currentOption);   
    }


    foreach($explodedOptions as $formSetting){

        $explodedSubOptions = explode('|||',$formSetting);

        $settingName = $explodedSubOptions[0];

        if($settingName == $formSettings){

            $standardFormLabels = $explodedSubOptions[1];
            $customFields = $explodedSubOptions[2];

        }

    }  




    
    $html = '';

    $html .= '<div class="ideapush-form-inner">';

    //lets get the users info if they exist


        if($currentUserId !== false){

            $userObject = get_user_by('id',$currentUserId);

            $html .= '<div class="user-profile-container">';


                $html .= '<div class="user-profile-image-container">';
                    $html .= '<img class="user-profile-image" src="'.esc_url(idea_push_get_user_avatar($currentUserId)).'" />';

                    //do admin star            
                    if(idea_push_is_user_admin($currentUserId)){
                        $html .= '<span class="admin-star-outer-large"><i class="fa fa-star admin-star-icon-large" aria-hidden="true"></i></span>';    
                    }
                
                $html .= '</div>';
            
                $html .= '<div class="user-profile-detail">';
                
                    $html .= '<a class="user-profile-name" href="'.esc_url(idea_push_get_user_author_page($currentUserId)).'">'.esc_html(idea_push_get_user_name($currentUserId)).'</a>'; 


                    //only show edit link if user profile editing enabled
                    $disableUserProfileEditing = $options['idea_push_disable_profile_edit'];

                    if(!isset($disableUserProfileEditing)){
                        //edit link
                        $html .= '<a class="user-profile-edit" href="#">'.__( 'Edit', 'ideapush' ).'</a>'; 
                    }

                    if(!isset($disableUserProfileEditing) && $multiIp == 'Yes'){
                        $html .= '<span class="link-separator">|</span>';    
                    }

                    global $wp;
                    $currentPage = home_url($wp->request);

                    //show login
                    if($multiIp == 'Yes'){
                        $html .= '<a href="'.wp_logout_url($currentPage).'" class="ideapush-logout-link">'.__( 'Logout', 'ideapush' ).'</a>';
                    }

                     

                    
            
                $html .= '</div>';
            
                if(!isset($disableUserProfileEditing)){
                    $html .= '<div class="user-profile-edit-form">';
                        //first name
                        $html .= '<input type="text" class="ideapush-form-first-name-edit" value="'.esc_html($userObject->first_name).'" maxlength="100" required>';     

                        //last name
                        $html .= '<input type="text" class="ideapush-form-last-name-edit"  maxlength="100" value="'.esc_html($userObject->last_name).'" required>'; 

                        //email
                        $html .= '<input type="email" class="ideapush-form-email-edit" value="'.esc_html($userObject->user_email).'" maxlength="150" required>'; 
                
                        //image
                        $html .= '<input class="ideapush-user-profile-attachment" type="file" name="fileToUpload" id="userProfileImage" accept=".jpg, .jpeg, .png, .gif">';
                
                        $html .= '<label class="ideapush-user-profile-attachment-label" for="userProfileImage"><i class="fa fa-picture-o" aria-hidden="true"></i> Update image</label>';
                
                        //submit
                        $html .= '<button class="update-user-profile">'.__( 'Update', 'ideapush' ).' <i class="fa fa-hand-o-right" aria-hidden="true"></i></button>';
                    $html .= '</div>';

                }    
            
            $html .= '</div>';

        }
    
                
        $standardFormLabelsExploded = explode('||',$standardFormLabels);
    
        //form title
        if(strlen($standardFormLabelsExploded[0])>1){
            $formTitle = $standardFormLabelsExploded[0];    
        } else {
            $formTitle = 'Push your idea';
        }
        $html .= '<span class="ideapush-form-title">'.esc_html($formTitle).'</span>';        

        //if guess access is enabled lets show the name and email field if the user isnt a known user
        if($guestAccess == 'Yes'){


            //check if person is a guest
            if($currentUserId == false){

                global $wp;
                $currentPage = home_url($wp->request);

                //show login
                $html .= '<a href="'.wp_login_url($currentPage).'" class="ideapush-login-link">'.__( 'Login', 'ideapush' ).'</a>'; 

                //first name
                $html .= '<input type="text" class="ideapush-form-first-name" placeholder="'.__( 'First name', 'ideapush' ).'" maxlength="100" required>';     

                //last name
                $html .= '<input type="text" class="ideapush-form-last-name" placeholder="'.__( 'Last name', 'ideapush' ).'" maxlength="100" required>'; 

                //email
                $html .= '<input type="email" class="ideapush-form-email" placeholder="'.__( 'Email', 'ideapush' ).'" maxlength="150" required>'; 
                
            }

        }


        //idea suggestion
        if(isset($options['idea_push_suggested_idea'])){
            $html .= '<div class="suggested-idea"></div>';    
        }

        //idea title
        if(strlen($standardFormLabelsExploded[1])>1){
            $ideaTitlePlaceholder = esc_html($standardFormLabelsExploded[1]);    
        } else {
            $ideaTitlePlaceholder = 'Idea title';
        }

        

        $html .= '<input type="text" class="ideapush-form-idea-title" placeholder="'.$ideaTitlePlaceholder.'" maxlength="250" required>'; 

        //idea description
        if(strlen($standardFormLabelsExploded[2])>1){
            $ideaDescriptionPlaceholder = esc_html($standardFormLabelsExploded[2]);    
        } else {
            $ideaDescriptionPlaceholder = 'Add additional details';
        }
        $html .= '<textarea class="ideapush-form-idea-description" placeholder="'.$ideaDescriptionPlaceholder.'" maxlength="2000" rows="8" required="required"></textarea>';

        //show character count here
        $html .= '<span class="ideapush-form-idea-description-counter"><span class="counter-number">0</span>/2000</span>';

    
        //idea tags
        if($showTags == 'Yes'){
            if(strlen($standardFormLabelsExploded[3])>1){
                $ideaTagsPlaceholder = esc_html($standardFormLabelsExploded[3]);    
            } else {
                $ideaTagsPlaceholder = 'Tags';
            }
    
            if(isset($options['idea_push_enable_tag_suggestion'])){
                $html .= '<div class="suggested-tags"></div>';    
            }

            
            
            $html .= '<div dataError="'.__( 'You can\'t enter custom tags', 'ideapush' ).'" dataDuplicateError="'.__( 'Enter a unique value', 'ideapush' ).'" class="ideapush-form-idea-tags" >';
            $html .= '<input placeholder="'.$ideaTagsPlaceholder.'" class="ideapush-form-idea-tags-input"></input>';
            $html .= '</div>';    
        }

    
    
    
    
    
    
    
        //idea attachment
        if($showAttachments == 'Yes'){
            
            if(strlen($standardFormLabelsExploded[4])>1){
                $attachmentText = esc_html($standardFormLabelsExploded[4]);    
            } else {
                $attachmentText = 'Attach image';
            }

            $html .= '<input class="ideapush-form-idea-attachment" type="file" name="fileToUpload" id="fileToUpload" accept=".jpg, .jpeg, .png, .gif">';
            
            $html .= '<label class="ideapush-form-idea-attachment-label" for="fileToUpload"><i class="fa fa-picture-o" aria-hidden="true"></i> '.$attachmentText.'</label>';

        }
    


        //do custom fields if pro
        global $ideapush_is_pro;

        if($ideapush_is_pro == "YES"){

            $html .= idea_push_create_custom_fields($customFields);

        }

    
    


        //button
        if(strlen($standardFormLabelsExploded[5])>1){
            $ideaButtonText = esc_html($standardFormLabelsExploded[5]);    
        } else {
            $ideaButtonText = 'Push';
        }
        
    
    
    
        //enhanced bot protection
        if(isset($options['idea_push_enable_bot_protection']) && $options['idea_push_enable_bot_protection'] == 1){
            
            
            function randonNumberBetweenOneAndTen(){
                return rand(1,10);     
            }
            
            function randomSigngenerator(){
                
                $randomNumber = rand(1,3);   
                
                if($randomNumber==1){
                    return "+"; 
                }
                
                if($randomNumber==2){
                    return "-"; 
                }
                
                if($randomNumber==3){
                    return "x"; 
                }
                
            }
            
            
            
            $firstNumber = randonNumberBetweenOneAndTen();
            $secondNumber = randonNumberBetweenOneAndTen();    
            $sign = randomSigngenerator();
            
            $html .= '<input data-number-one="'.$firstNumber.'" data-number-two="'.$secondNumber.'" data-sign="'.$sign.'" type="number" class="ideapush-form-math-problem" placeholder="'.$firstNumber.' '.$sign.' '.$secondNumber.'" required>';    
            
            //honeypot
            $html .= '<input type="text" class="ideapush-form-extended-description" placeholder="Please enter an extended description of the idea" required>'; 
        }
        
        
    
    
    
    
        $html .= '<button class="submit-new-idea">'.$ideaButtonText.' <i class="fa fa-hand-o-right" aria-hidden="true"></i></button>';
        
    
        //display loading
        $html .= '<span class="idea-publish-loading" style="display:none;">'.__( 'Hold on', 'ideapush' ).' <i class="fa fa-spinner idea-publish-loading-icon" aria-hidden="true"></i></span>';
    
    
    $html .= '</div>'; //end inner
    
    
    
    

    return $html;
    
}

?>