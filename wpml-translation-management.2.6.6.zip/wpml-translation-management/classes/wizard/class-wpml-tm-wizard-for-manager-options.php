<?php

class WPML_TM_Wizard_For_Manager_Options {
	const CURRENT_STEP = 'WPML_TM_Wizard_For_Manager_Current_Step';
	const WIZARD_COMPLETE = 'WPML_TM_Wizard_For_Manager_Complete';
}
