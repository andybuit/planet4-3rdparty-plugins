<?php

interface IWPML_ST_Rewrite_Rule_Filter {

	public function rewrite_rules_filter( $rules );

}
