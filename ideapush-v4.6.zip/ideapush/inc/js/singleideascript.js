jQuery(document).ready(function ($) {
   
  
    if($('#titlewrap input').val() == ''){
//        console.log('the page is empty'); 
        
        //make status open by default        
        $( "#statuschecklist li").each(function( index ) {
            
            var statusName = $(this).text();
            
            if(statusName == 'Open'){ 
                $(this).find('input').prop("checked", true);   
            }

        });
        
        
        //set board if theres one board
        if($("#boardschecklist li").length == 1){
            $(this).find('input').prop("checked", true);       
        }
        
        
        
        
        
    }
    
 
    
    
    
    
    
    
    

});